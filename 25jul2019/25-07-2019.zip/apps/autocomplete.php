<?php
include('connect.php');
$term = strtolower($_GET["term"]);
  //$term = "s";   

$querysearch = "SELECT * FROM user_signup WHERE user_username  LIKE '%".$term."%'";

$resultsearch = mysqli_query($con,$querysearch);
//print_r($resultsearch);

while($row = mysqli_fetch_assoc($resultsearch))
{
  $skillData[] = $row['user_username'];
 
}
 //array_push($skillData, $res);
//die("hi");
echo json_encode($skillData);
?>
