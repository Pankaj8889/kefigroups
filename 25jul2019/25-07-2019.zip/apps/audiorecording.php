
<!doctype html>
<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Audio Recorder</title>
	    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">

	<script src="js/audiodisplay.js"></script>
	<script src="js/recorderjs/recorder.js"></script>
	<script src="js/main.js"></script>

</head>
<body>
<?php include('header.php');?>
	<div class="container-fluid mt-5">
	<div class="row">
	<div class="col-md-3"></div>
	<div class="col-md-6">
		<div id="viz">
		<canvas id="analyser" width="1024" height="500"></canvas>
		<canvas id="wavedisplay" width="1024" height="500" style="display:none;"></canvas>
	</div>
	
		<div id="controls">
		<a href="#"><img id="record" src="https://webaudiodemos.appspot.com/AudioRecorder/img/mic128.png" onclick="toggleRecording(this);"></a>
		<a id="save" href="#"><img src="https://webaudiodemos.appspot.com/AudioRecorder/img/save.svg"></a>
	</div>
	</div>
	<div class="col-md-3">
	<div id="User_Click_Btn_bd2" class="User_Click_Btn_bd text-center mb-1 mt-2">
  
  <h5 class="title_top">Instructions to Upload Audio Recording</h5>
  <ul class="user-list-T">
      <li> 1. Click Mike instrument(on left side) to start recording.</li>
      <li> 2. After recorded audio, click Mike instrument again to stop recording.</li>
      <li> 3. Click DISK(on left side) button to download recorded audio.</li>
      <li> 4. Go to <a href ="index.php">Profile Page.</a></li>
      <li> 5. In  Profile page, click Upload media to uploading the downloaded audio.</li>
      <li> 6. After uploaded  audio, click Publish button to publish the post.</li>
      <li><a href=""></a></li>
  </ul>
  
 
  </div>
  </div>
	</div>
<!--<div class="User_Click_Btn_bd text-center">	<a href="index.php">CLick Here to upload a Audio </a></div>-->

	</div>
	 
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script> 
</body>
</html>