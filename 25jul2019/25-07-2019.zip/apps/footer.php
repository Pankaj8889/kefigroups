<?php
 include('config.php');
 session_start();
 $type =  $_SESSION['user_type'] ;

$useragent = $_SERVER['HTTP_USER_AGENT']; 
$iPod = stripos($useragent, "iPod"); 
$iPad = stripos($useragent, "iPad"); 
$iPhone = stripos($useragent, "iPhone");
$Android = stripos($useragent, "Android"); 
$iOS = stripos($useragent, "iOS");
//-- You can add billion devices 

$DEVICE = ($iPod||$iPad||$iPhone||$Android||$iOS);

if ($DEVICE) { ?>

<div class="user-Friend list-section">
                        <ul class="nav">
                            <li>
                                <a href="https://kefigroups.com/apps/User/watchmie/user_friends.php">Friends</a>
                            </li>

                            <li>
                              <a href="https://kefigroups.com/apps/index.php">Home</a>
                            </li>
                            
                             <li>
                               <a href="https://kefigroups.com/apps/User/watchmie/user_favourite.php">Favourite</a>
                            </li>                            
                             
                        </ul>
                        
                    </div>



<?php }


?>
 