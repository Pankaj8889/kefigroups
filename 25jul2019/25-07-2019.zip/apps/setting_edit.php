<?php
include('connect.php');
include('config.php');
session_start();
$uid = $_SESSION['userid'];
$query = "select * from user_signup where user_id = $uid";
$result = mysqli_query($con,$query);?>
<form method="post" action=""><?php
while($row = mysqli_fetch_array($result))
{
    ?>
    
        Username<input type = "text" name="uname" value="<?php echo $row['user_username']; ?>" /><br/><br/>
        Email<input type = "email" name="email" value="<?php echo $row['user_email']; ?>" /><br/><br/>
        Mobile number<input type = "text" name="mobile" /><br/><br/>
        
    
<?php
    }
?>
<input type="submit" value="submit" name="btnsubmit" />
</form>
<?php
if(isset($_POST['btnsubmit']))
{
    $uname = $_POST['uname'];
   
    $email = $_POST['email'];
    
    $mobile = $_POST['mobile'];
    $queryin = "update user_signup set user_username ='$uname',user_email ='$email',user_mobileno ='$mobile' where user_id =$uid";
    $resultin = mysqli_query($con,$queryin);
    if($resultin)
    {
		?>
		<script>
		window.location.href="setting.php";
		</script>
		<?php
       // header("Location:setting.php");
    }
}
?>