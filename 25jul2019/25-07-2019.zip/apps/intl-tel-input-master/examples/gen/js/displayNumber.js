var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1541153396801" // just for formatting/placeholders etc
});
