<?php
include('../connect.php');
include('../config.php');
session_start();
$uid = $_SESSION['userid'];
$query = "select * from merchant_products where merchant_id=$uid";
$result = mysqli_query($con,$query);


?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <!-- <link rel="stylesheet" href="../css/stylecomment.css">-->
    <link rel="stylesheet" href="../css/responsive.css">
    <title>View Product</title>
  </head>
  <?php include('../header.php'); ?>
  <body>
            <section id="view--product">
                <div class="container">
                    <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                            <li class="active"><a href="../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                            <li>Products</li>
                            
                        </ul>
                    </div>
                    <?php
                    while($rowdis = mysqli_fetch_array($result))
                    {
                    $image = $rowdis['product_image'];
                    ?>
                        
                    <div class="row">
            		<div class="col-md-4">
            		<div class="product-img-hd">
            		    <img class="" src="<?php echo "https://".$baseurl."productimages/".$image ;?>" />
                    </div>
                </div>
            
                <div class="col-md-8">
                    <div class="product_information_block">
                        <h2><?php echo $rowdis['product_title'] ;?></h2>
                        <div class="Price mb-3"><strong>Rs. <?php echo $rowdis['product_price'] ;?></strong></div>
                        <p><?php echo $rowdis['product_description'] ; ?></p>
                      
                    </div>
                </div>
                </div>
                <?php
                    }
                    ?>


                </div>
            </section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script> 
  </body>
</html>

