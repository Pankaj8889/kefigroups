
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Merchant Sign Up</title>
  </head>
  
<?php
require('../connect.php');
if(isset($_POST['btnsubmit']))
{
    $la=$_POST['geoData'];
//echo $la;
    $var1 = explode("/",$la);
    
	$category = $_POST['radio-stacked'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$userid =date("YmdHis");
	$hash = md5( rand(0,1000) );
	$query = "insert into user_signup(user_id,user_category,user_username,user_email,user_password,user_type,latitude,longitude,hash,active) values('$userid','$category','$username','$email','$password','merchant','$var1[0]','$var1[1]','$hash',0)";
	$res = mysqli_query($con,$query);
	if($res)
	{
	    //$msg = "You are registered successfully.";	
		?>		
		<script>		
		//window.location.href="https://<?php echo $baseurl; ?>User/user-sign-in.php";		
		</script>		
		<?php
	    //header('location:../User/thankuuser.php');
		//echo $email;
		echo "Success: Your account is created successfully, please check your email for verification link to activate your account.";
		$to = $email;
		$subject = "Signup | Verification";
		$txt = "Thanks for signing up!
			Your account has been created, you can login after you have activated your account by pressing the url below.
			Please click this link to activate your account:
			https://www.kefigroups.com/apps/User/emailverify.php?email=$email&hash=$hash";
		$headers = "From: kefi@example.com" ;


mail($to,$subject,$txt,$headers);
	}
	else
	{
	    $msg = "Email Already Exist.Please signup with another account";
	}
}
?>
  <body id="Sign-up_page">
    <section id="sign-up-page" class="sign-up-page">
    <div class="container">
        <div class="">
            <div class="">
                <div id="form_box_area" class="right-bar-Sec">
                    <div class="Same-style-form Sign-up">
					  <div class="logo-header">
                            <a href="javascript:void(0);"><img src="../images/logo.png"></a>
                        </div>
                       
						
                        <form class="needs-validation" novalidate name="merchantsignup" action="" method="post">
                            <div class="Category-box">
                                <?php  if (empty(!$msg)) {
                                ?>
                                <div class="alert alert-danger">
                                  <strong><?php echo $msg; ?></strong>
                                </div>
                                <?php
                                }
                                ?>
                            <div class="Category-title"><h3>Select  Category</h3></div>
						<ul class="nav">
						    <li>
                                <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation1" name="radio-stacked" required="" value="entertainment">
                                    <label class="custom-control-label" for="customControlValidation1">
                                        <i class="fa fa-music" aria-hidden="true"></i> 
                                </label>
                                </div>
							</li>
							 <li>
                                  <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked" required="" value="cutlery">
                                    <label class="custom-control-label" for="customControlValidation2">
                                       <img src="../images/icon4.png"> 
                                    </label>
                                  </div>
								   </li>
								    <li>
                                  <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation3" name="radio-stacked" required="" value="general">
                                    <label class="custom-control-label" for="customControlValidation3">
                                        <img src="../images/icon-4.jpg">  
                                    </label>
                                  </div>
								   </li>
								    <li>
                                  <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation4" name="radio-stacked" required="" value="accommodation">
                                    <label class="custom-control-label" for="customControlValidation4">
                                       <img src="../images/icon-7.png"></label>
                                  </div>
								   </li>
								    <li>
									
                                    <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation5" name="radio-stacked" required="" value="apparel">
                                    <label class="custom-control-label" for="customControlValidation5">
                                       <img src="../images/icon1.png">    
                                    </label>
                                  </div>
                                 </li>
								  <li>
                                  <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation6" name="radio-stacked" required="" value="e-commerce">
                                    <label class="custom-control-label" for="customControlValidation6">
                                       <img src="../images/icon-6.png">   
                                    </label>
                                  </div>
								   </li>
                                </div>
                      </ul>
                            <div class="form-group">
                               
                                <input type="text" class="form-control" id="validationCustom03" name="username" placeholder="User Name" required>
								<img src="../images/user-icon.svg">
                            </div>
                            <div class="form-group">
                              
                                <input type="email" class="form-control" id="validationCustom03" name="email" placeholder="Email" required>
								<img src="../images/email-icon-1.png">
                            </div>
                            <div class="form-group">
                               
                                <!--<input type="password" class="form-control" id="validationCustom03" name="password" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required >-->
                                <input type="password" class="form-control" id="validationCustom" name="password" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required >
								<img src="../images/lock.png">
                            </div>
                            <span id="pwderror" style="display:none;">Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters</span>
                            <div class="click-btn">
							  <div class="custom-control custom-checkbox Remember_me">
								<input type="checkbox" class="custom-control-input" id="customControlInline" required>
								<label class="custom-control-label" for="customControlInline">Agreed to KEFI's Disclaimer</label>
							  </div>
							  
							  <input name="geoData" id="inputId" required value="" hidden >
							<!--<button type="submit" class="btn btn-primary" name="btnsubmit">Sign Up</button><br>-->
						<div class="click-btn">							 					
							 <button type="submit" class="btn btn-primary secondary" name="btnsubmit" onclick="getLocation();">Sign Up</button>	
							
							</div>				
													
							</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script> 
	<script>

var x = document.getElementById("inputId");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.value = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.value = position.coords.latitude + 
    "/ " + position.coords.longitude;

}
</script>
<script>
  $(document).ready(function() {
 
  $('#validationCustom').on('keypress', function() {
    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/.test(this.value);
    if(!re) {
        $('#pwderror').show();
    } else {
        $('#pwderror').hide();
    }
})

});
</script>
  </body>
</html>
