<?php
include('../connect.php');
include('../config.php');
session_start();
 $uid = $_SESSION['userid'];
$querycat = "select * from user_signup where user_id = $uid";
//echo "select * from merchant_signup where merchant_id = $mid";
$resultcat = mysqli_query($con,$querycat);
$rowcat =mysqli_fetch_array($resultcat);
$category = $rowcat['user_category'];

if(isset($_POST['btnsubmit']))
{
    
    //echo "1";
    $type = $_FILES['picupload']['type'];
	 $path = $_FILES['picupload']['name']; 
	 $ext = pathinfo($path, PATHINFO_EXTENSION);
	 $logo = time().'.'.$ext;
	// $logo1 = "https://kefii-dev-pankajsaini8889.c9users.io/Kefi/productimages/$logo";
	 $_FILES['picupload']['size'];
	 $_FILES['picupload']['tmp_name'];
	 $imagepath = '../productimages/';
	 move_uploaded_file($_FILES['picupload']['tmp_name'],$imagepath.$logo);
	 
    $title =addslashes($_POST['protitle']);
    //$category = $_POST['procategory'];
    $description = addslashes($_POST['prodescription']);
    $price = $_POST['proprice'];
    $date = date("Y-m-d h:i:s");
    $query = "insert into merchant_products(merchant_id,product_category,product_title,product_price,product_image,product_description,date)values($uid,'$category','$title','$price','$logo','$description','$date')";
    
    //echo "insert into merchant_products(merchant_id,product_category,product_title,product_price,product_image,product_description,date)values('$uid','$category','$title','$logo1','$description','$date')";
    $result = mysqli_query($con,$query);
    //echo "2";
    if($result)
    {
       // echo "3";
        $msg = "Product Inserted Successfully ";
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Add New Product</title>
  </head>
  <?php include('../header.php');?>
  
   <section id="Add-New-Product_bad">
   
    <div class="container">
        <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                            <li class="active"><a href="../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                            <li>Products</li>
                            
                        </ul>
                    </div>
        <div class="row">
            <div class="col-md-12">
<div class="add-new-product-section">
			
			<div class="Category-title">
                        <h3>Add New Product</h3></div>
                         <div class="center-top-text"><?php echo $msg; ?></div>
			<div class="form-main-box-area-add">
					<form class="needs-validation" novalidate="" method="post" enctype="multipart/form-data">
					  <div class="form-row">
						<div class="col-md-12 mb-3">
						  <input type="text" class="form-control" id="validationCustom03" placeholder="Product Name" name="protitle" required="">
						</div>
						
						<div class="col-md-12 mb-3">
						  <input type="text" class="form-control" id="validationCustom03" placeholder="Price" name="proprice" required="">
						</div>
						 <div class="col-md-12 mb-3">
					<div class="custom-file">
						<input type="file" class="custom-file-input " id="validatedCustomFile" required="" name="picupload">
						<label class="custom-file-label " for="validatedCustomFile"></label>
					  </div>
					  </div>
					  
						 <div class="col-md-12 mb-3">
						<textarea id="validationCustom04" class="form-control" placeholder="Description" name="prodescription" required=""></textarea>
					  </div>
					  </div>
					  <button class="btn btn-primary click-ntn-submit" type="submit" name="btnsubmit">Submit</button><br/>
					 
					</form>
	
			</div>
			</div>

            </div>
        </div>
    </div>

</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script> 
  </body>
</html>
