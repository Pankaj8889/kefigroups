<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Thanku</title>
  </head>
  <body>
    <section id="Thanku">
    <div class="container">
            <div class="thanku-sec-area">
            <div id="form_box_area" class="right-bar-Sec">
			<h1>Thank You!</h1>
			<p>you are registered successfully!</p>
			
			<div class="login__btn text-center mt-3"><a href="merchant-sign-in.php">Login Here</a></div>
			
  
            </div>
            </div>
    </div>
    
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script> 
  </body>
</html>
