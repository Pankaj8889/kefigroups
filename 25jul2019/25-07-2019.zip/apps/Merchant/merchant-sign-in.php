<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Merchant Sign In</title>
  </head>
<?php
include('connect.php');
session_start();
if(isset($_POST['btnlogin']))
{
	
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	
	$query = "select * from merchant_signup where merchant_email='$email'and merchant_password='$password'";
	$result = mysqli_query($con,$query);
	if(!$result)
	{
		echo "Error while insertion".mysqli_error($con);
	}
	$count = mysqli_num_rows($result);
	if($count == 1)
	{
		$row = mysqli_fetch_array($result);
	    $_SESSION['merchantid'] = $row['merchant_id'];
		header('location:index.php');
	}
	else
	{
		$msg = "Invalid Email/Password";
	}
} 
?>  
  <body id="Sign-up-page" class="body-bg-color">
    <section id="sign-up-page" class="sign-up-page">
    <div class="container">
        <div class="">
            <div class="">
                <div id="form_box_area" class="right-bar-Sec">
                    <div class="Same-style-form login">
					  <div class="logo-header">
                            <a href="javascript:void(0);"><img src="images/logo.png"></a>
                        </div>
                         <?php  if (empty(!$msg)) {
                                ?>
                                <div class="alert alert-danger">
                                  <strong><?php echo $msg; ?></strong>
                                </div>
                                <?php
                                }
                                ?>
                        <form class="needs-validation" novalidate name="merchantsignin" action="" method="post">
                            <div class="form-group">
                              
                                <input type="email" class="form-control" id="validationCustom03" placeholder="Email" name="email" required>
								<img src="images/email-icon-1.png">
                            </div>
                            <div class="form-group">
                               
                                <input type="password" class="form-control" id="validationCustom03" placeholder="Password" name="password" required>
								<img src="images/lock.png">
                            </div>                 
							<div class="click-btn">
								<div class="custom-control custom-checkbox Remember_me">
								<input type="checkbox" class="custom-control-input" id="customControlInline" required>
								<label class="custom-control-label" for="customControlInline">KEFI, Remember me! </label>
								</div>
								<div class="click-btn">							 					
							 <button type="submit" class="btn btn-primary secondary" name="btnlogin">Login</button><br/>
							<!--<button type="submit" class="btn btn-primary" name="btnlogin">Login</button><br/>-->
							    <p>Not Registered? <a href="merchant-sign-up.php">Sign Up</a></p>
								</div>
							</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script> 
  </body>
</html>
