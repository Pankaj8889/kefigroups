<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Rehibernate Account</title>
  </head>
  
<?php
include('connect.php');
	if(isset($_POST['btnlogin']))
	{
		$email = $_POST['email'];
		$query = "select * from user_signup where user_email = '$email'";
		$result = mysqli_query($con,$query);
		$count = mysqli_num_rows($result);
		if($count == 1)
		{
			$row = mysqli_fetch_array($result);
			
				$querylogin = "update user_signup set status = '' where user_email = '$email' && status = 'deactivate'";
				$resultlogin = mysqli_query($con,$querylogin);
				?>
				<script>
					window.location.href="https://www.kefigroups.com/apps/User/user-sign-in.php";
				</script>
				<?php
				
			
		}
		else
		{
			$msg = "Invalid Email Id";
		}
	}
?>
        
	<body id="Sign_in_page">
  
    <section id="sign-up-page" class="sign-up-page">
    <div class="container">
            <div class="">
                <div id="form_box_area" class="right-bar-Sec">
                    <div class="Same-style-form login">
					  <div class="logo-header">
                            <a href="javascript:void(0);"><img src="images/logo.png"></a>
                        </div>
						<div class="center-top-text text1"><?php echo $msg; ?></div>
                            
                        
                        <form class="needs-validation" novalidate name="usersignin" action="" method="post">
                            <div class="form-group">
                              
                                <input type="email" class="form-control" id="validationCustom03" placeholder="Email" required name="email">
								<img src="images/email-icon-1.png">
                            </div>
							 <div class="click-btn">							 					
							 <button type="submit" class="btn btn-primary secondary" name="btnlogin">Submit</button><br/>	
							  
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script>
 
	
	
        <!-- stop PHP Code -->
 
         
   
    <!-- end wrap div --> 
</body>
</html>