<?php

include('connect.php');

session_start();

$message = '';

if(isset($_SESSION['user_id']))
{
 header('location:indexchat.php');
}

if(isset($_POST["login"]))
{
 $query = "
   SELECT * FROM user_signup 
    WHERE user_email = :username
 ";
 $statement = $con1->prepare($query);
 $statement->execute(
    array(
      ':username' => $_POST["username"]
     )
  );
  $count = $statement->rowCount();
  if($count > 0)
 {
  $result = $statement->fetchAll();
    foreach($result as $row)
    {
      if(md5($_POST["password"])==$row["user_password"])
      {
        $_SESSION['user_id'] = $row['user_id'];
        $_SESSION['username'] = $row['user_username'];
        $sub_query = "
        INSERT INTO login_details 
        (user_id) 
        VALUES ('".$row['user_id']."')
        ";
        $statement = $con1->prepare($sub_query);
        $statement->execute();
        $_SESSION['login_details_id'] = $con1->lastInsertId();
        header("location:indexchat.php");
      }
      else
      {
       $message = "<label>Wrong Password</label>";
      }
    }
 }
 else
 {
  $message = "<label>Wrong Username</labe>";
 }
}

?>

<html>  
    <head>  
        <title>Login</title> 
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/responsive.css">
  </head>  
  <body> 
   <header>
		<div class="sub-header-main">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="site-logo">
						<a href="../index.php"><img src="../images/logo.png"></a>
		    </div>
					</div>
					
					<div class="col-md-9">
						<div class="name-group">
							<ul class="nav justify-content-end">
								<li class="nav-item">
									<a href="JavaScript:Void(0);"><img src="../images/setting-icon.png">
                                    <br>Settings</a>
								</li>
								<li class="nav-item">
									<a href="JavaScript:Void(0);"><img src="../images/user-icon.png">
                                    <br>Profile</a>
								</li>
							</ul>
		
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</header>
  <div class="container">
   <br />
   
   <!--<h3 align="center">Chat Application using PHP Ajax Jquery</a></h3><br />-->
   <br />
   <div class="panel panel-default" style="margin-top:116px;width:50%; margin:0 auto;">
      <div class="panel-heading"><spam style="margin-left:230px;font-size:20px;">Login</spam></spam></div>
    <div class="panel-body">
     <form method="post">
      <p class="text-danger"><?php echo $message; ?></p>
      <div class="form-group">
       <label style="font-size:15px;">Enter Email</label>
       <input type="email" name="username" class="form-control" required />
      </div>
      <div class="form-group">
       <label style="font-size:15px;">Enter Password</label>
       <input type="password" name="password" class="form-control" required />
      </div><br/>
      <div class="form-group" style="margin-left:230px;">
       <input type="submit" name="login" class="btn btn-info" value="Login" style="font-size:20px;"/>
      </div>
     </form>
    </div>
     
   </div><br/><br/>
   <a href="../index.php" style="margin-left:523px;">Previous page</a>
  </div>
    </body>  
</html>
