<?php

//fetch_user.php

include('connect.php');
session_start();
$query = "
SELECT * FROM user_signup 
WHERE user_id != '".$_SESSION['user_id']."' and user_type='merchant' 
";
$statement = $con1->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$output = '
<table class="table table-bordered table-striped">
 <tr>
  <th width="70%">Merchants</td>
  
  <th width="10%"> &nbsp;</td>
 </tr>
';
foreach($result as $row)
{

 $status = '';
 $current_timestamp = strtotime(date("Y-m-d H:i:s") . '- 10 second');
 $current_timestamp = date('Y-m-d H:i:s', $current_timestamp);
 $user_last_activity = fetch_user_last_activity($row['user_id'], $con1);
 if($user_last_activity > $current_timestamp)
 {
 // $status = '<span class="label label-success">Online</span>';
 }
 else
 {
 // $status = '<span class="label label-danger">Offline</span>';
 }
 
 /*$output .= '
 <tr>
  <td>'.$row['user_username'].' ('.$row['user_type'].') '.count_unseen_message($row['user_id'], $_SESSION['user_id'], $con1).' '.fetch_is_type_status($row['user_id'], $con1).'</td>
  
  <td><button type="button" class="btn btn-info btn-xs start_chat" data-touserid="'.$row['user_id'].'" data-tousername="'.$row['user_username'].'">Message</button></td>
 </tr>
 ';
}

$output .= '</table>';
*/

$output .= '
 <tr>
  <td><a href = "#" style="text-decoration: none;" class="start_chat" data-touserid="'.$row['user_id'].'" data-tousername="'.$row['user_username'].'" >'.$row['user_username'].'  '.count_unseen_message($row['user_id'], $_SESSION['user_id'], $con1).' '.fetch_is_type_status($row['user_id'], $con1).'</a></td>
  
  <td><button type="button" class="btn btn-info btn-xs start_chat" data-touserid="'.$row['user_id'].'" data-tousername="'.$row['user_username'].'">Message</button></td>
 </tr>
 ';
}

$output .= '</table>';


echo $output;


$query1 = "
SELECT * FROM user_signup 
WHERE user_id != '".$_SESSION['user_id']."' and user_type='user' 
";
$statement1 = $con1->prepare($query1);
$statement1->execute();
$result1 = $statement1->fetchAll();
$output1 = '
<table class="table table-bordered table-striped">
 <tr>
  <th width="70%">Friends</td>
  
  <th width="10%">&nbsp;</td>
 </tr>
';
foreach($result1 as $row1)
{

 $status1 = '';
 $current_timestamp1 = strtotime(date("Y-m-d H:i:s") . '- 10 second');
 $current_timestamp1 = date('Y-m-d H:i:s', $current_timestamp1);
 $user_last_activity1 = fetch_user_last_activity($row1['user_id'], $con1);
 if($user_last_activity1 > $current_timestamp1)
 {
 // $status = '<span class="label label-success">Online</span>';
 }
 else
 {
 // $status = '<span class="label label-danger">Offline</span>';
 }
 
 /*$output .= '
 <tr>
  <td>'.$row['user_username'].' ('.$row['user_type'].') '.count_unseen_message($row['user_id'], $_SESSION['user_id'], $con1).' '.fetch_is_type_status($row['user_id'], $con1).'</td>
  
  <td><button type="button" class="btn btn-info btn-xs start_chat" data-touserid="'.$row['user_id'].'" data-tousername="'.$row['user_username'].'">Message</button></td>
 </tr>
 ';
}

$output .= '</table>';
*/

$output1 .= '
 <tr>
  <td><a href = "#" style="text-decoration: none;" class="start_chat" data-touserid="'.$row1['user_id'].'" data-tousername="'.$row1['user_username'].'" >'.$row1['user_username'].' '.(count_unseen_message($row1['user_id'], $_SESSION['user_id'], $con1)).' '.fetch_is_type_status($row1['user_id'], $con1).'</a></td>
  
  <td><button type="button" class="btn btn-info btn-xs start_chat" data-touserid="'.$row1['user_id'].'" data-tousername="'.$row1['user_username'].'">Message</button></td>
 </tr>
 ';
}

$output1 .= '</table>';


echo $output1;

?>