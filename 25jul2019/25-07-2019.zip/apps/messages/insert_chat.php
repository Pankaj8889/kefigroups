<?php

//insert_chat.php

include('connect.php');

session_start();
date_default_timezone_set('Asia/Kolkata');
$timestamp = date("Y-m-d h:i:s");
//echo $timestamp;
$data = array(
 ':to_user_id'  => $_POST['to_user_id'],
 ':from_user_id'  => $_SESSION['user_id'],
 ':chat_message'  => $_POST['chat_message'],
 ':timestamp' => $timestamp,
 ':status'   => '1'
);

$query = "
INSERT INTO chat_message 
(to_user_id, from_user_id, chat_message,timestamp, status) 
VALUES (:to_user_id, :from_user_id, :chat_message, :timestamp, :status)
";

$statement = $con1->prepare($query);

if($statement->execute($data))
{
 echo fetch_user_chat_history($_SESSION['user_id'], $_POST['to_user_id'], $con1);
}

?>
