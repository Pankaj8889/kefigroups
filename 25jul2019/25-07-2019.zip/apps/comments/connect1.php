<?php
	date_default_timezone_set('Asia/Kolkata');
	$dbhost = 'localhost';
	$dbuser = 'kefigrou_kefi';
	$dbpass = 'bU;CDy}x!(do';
	$dbname = 'kefigrou_kefi';

	$connect = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die(mysqli_error($connect));
?>
