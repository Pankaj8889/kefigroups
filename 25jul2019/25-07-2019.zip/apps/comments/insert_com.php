<?php
	// new comment
	$url= $_SERVER['REQUEST_URI'];
	$var = explode('/',$url);
	$var2 = explode('?',$var[2]);
	$var3 = explode('=',$var2[1]);
	$post_idd= $var3[1];
	if(isset($_POST['new_comment'])) {
		$new_com_name = $_SESSION['user'];
		$new_com_text = $_POST['comment'];
		$new_com_date = date('Y-m-d H:i:s');
		$new_com_code = generateRandomString();
		$userid = $_SESSION['userid'];

		if(isset($new_com_text)) {
			mysqli_query($con, "INSERT INTO `comment_parents` (`user_id`,`user_name`, `text`, `date`, `code`,`post_id`) VALUES ('$userid','$new_com_name', '$new_com_text', '$new_com_date', '$new_com_code','$post_idd')");
		}		?>		<script>		window.location.href="";		</script>		<?php
		//header("Location: ");
	}
	// new reply
	if(isset($_POST['new_reply'])) {
		$new_reply_name = $_SESSION['user'];
		$new_reply_text = $_POST['new-reply'];
		$new_reply_date = date('Y-m-d H:i:s');
		$new_reply_code = $_POST['code'];
		$userid1 = $_SESSION['userid'];

		if(isset($new_reply_text)) {
			mysqli_query($con, "INSERT INTO `comment_children` (`user_id`,`user_name`, `text`, `date`, `par_code`,`post_id`) VALUES ('$userid1','$new_reply_name', '$new_reply_text', '$new_reply_date', '$new_reply_code','$post_idd')") or die(mysqli_error());
		}		?>		<script>		window.location.href="";		</script>		<?php
		//header("Location: ");
	}
?>