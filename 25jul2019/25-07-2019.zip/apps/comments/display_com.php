<?php
	session_start();
	$_SESSION['user'] = $_SESSION['username'];
	$url1= $_SERVER['REQUEST_URI'];
	$var1 = explode('/',$url1);
	$var21 = explode('?',$var1[2]);
	$var31 = explode('=',$var21[1]);
	$post_idd1= $var31[1];
	
	include('../config.php');
	/*function get_total() 
	{
		$url1= $_SERVER['REQUEST_URI'];
		$var1 = explode('/',$url1);
		$var21 = explode('?',$var1[2]);
		$var31 = explode('=',$var21[1]);
		$post_idd1= $var31[1];
		require 'connect1.php';
		$result = mysqli_query($connect, "SELECT * FROM `comment_parents` WHERE post_id =$post_idd1  ORDER BY `date` DESC");
	//	echo "SELECT * FROM `comment_parents` WHERE post_id ='$var31[1]'  ORDER BY `date` DESC";
		$row_cnt = mysqli_num_rows($result);
		echo '<h1>All Comments ('.$row_cnt.')</h1>';
	}*/

	function get_comments() 
	{
		$url1= $_SERVER['REQUEST_URI'];
		$var1 = explode('/',$url1);
		$var21 = explode('?',$var1[2]);
		$var31 = explode('=',$var21[1]);
		$post_idd1= $var31[1];
		include('../connect.php');
		$result =  mysqli_query($con, "SELECT * FROM `comment_parents` WHERE post_id='$post_idd1' ORDER BY `date` DESC");
		$row_cnt = mysqli_num_rows($result);

		foreach($result as $item) {
			$date = new dateTime($item['date']);
			$date = date_format($date, 'M j, Y | h:i:s');
			$user = $item['user_name'];
			$comment = $item['text'];
			$par_code = $item['code'];

			echo '<div class="comment" id="'.$par_code.'">'
					.'<p class="user">'.$user.'</p>&nbsp;'
					.'<p class="time">'.$date.'</p>'
					.'<p class="comment-text user__hi">'.$comment.'</p>';
				/*	.'<a class="link-reply" onclick="myFunction()" id="reply" name="'.$par_code.'">Reply</a>';
				$chi_result = mysqli_query($connect, "SELECT * FROM `comment_children` WHERE `par_code`='$par_code' and `post_id` = '$post_idd1' ORDER BY `date` DESC");
				$chi_cnt = mysqli_num_rows($chi_result);

				if($chi_cnt == 0){
				} else {
					echo '<a class="link-reply" id="children" name="'.$par_code.'"><span id="tog_text">replies</span> ('.$chi_cnt.')</a>'
						.'<div class="child-comments" id="C-'.$par_code.'">';

					foreach($chi_result as $com) {
						$chi_date = new dateTime($com['date']);
						$chi_date = date_format($chi_date, 'M j, Y | h:i:s');
						$chi_user = $com['user_name'];
						$chi_com = $com['text'];
						$chi_par = $com['par_code'];

						echo '<div class="child" id="'.$par_code.'-C">'
								.'<p class="user">'.$chi_user.'</p>&nbsp;'
								.'<p class="time">'.$chi_date.'</p>'
								.'<p class="comment-text comment1">'.$chi_com.'</p>'
							.'</div>';
					}
					echo '</div>';
				}*/
				echo '</div>';
		}
	}

	function generateRandomString($length = 6) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$characterLength = strlen($characters);
		$randomString = '';

		for($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $characterLength - 1)];
		}
		return $randomString;
	}
?>