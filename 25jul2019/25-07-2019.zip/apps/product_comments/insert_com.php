<?php
	// new comment
$url= $_SERVER['REQUEST_URI'];
//echo $url."<br/>";
$var = explode('/',$url);
//echo $var[3];
$var2 = explode('?',$var[3]);
$var3 = explode('=',$var2[1]);
$pro_idd= $var3[1];
//echo $pro_idd;
	if(isset($_POST['new_comment'])) {
		$new_com_name = $_SESSION['user'];
		$new_com_text = $_POST['comment'];
		$new_com_date = date('Y-m-d H:i:s');
		$new_com_code = generateRandomString();
		$userid = $_SESSION['userid'];

		if(isset($new_com_text)) {
			mysqli_query($connect, "INSERT INTO `productcomment_parents` (`user_id`,`user_name`, `text`, `date`, `code`,`product_id`) VALUES ('$userid','$new_com_name', '$new_com_text', '$new_com_date', '$new_com_code','$pro_idd')");
		}		?>		<script>		window.location.href="";		</script><?php
		//header("Location: ");
	}
	// new reply
	if(isset($_POST['new_reply'])) {
		$new_reply_name = $_SESSION['user'];
		$new_reply_text = $_POST['new-reply'];
		$new_reply_date = date('Y-m-d H:i:s');
		$new_reply_code = $_POST['code'];
		$userid1 = $_SESSION['userid'];

		if(isset($new_reply_text)) {
			mysqli_query($connect, "INSERT INTO `productcomment_children` (`user_id`,`user_name`, `text`, `date`, `par_code`,`product_id`) VALUES ('$userid1','$new_reply_name', '$new_reply_text', '$new_reply_date', '$new_reply_code','$pro_idd')") or die(mysqli_error());
		}		?>		<script>		window.location.href="";		</script><?php
		//header("Location: ");
	}
?>