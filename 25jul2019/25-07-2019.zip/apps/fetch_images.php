<?php
	include('connect.php');
	include('config.php');
   
	session_start();
	 $uid = $_SESSION['userid'];
	 $tid = $_GET['tid'];
	
	$type =  $_SESSION['user_type'] ;


 $query = "SELECT * FROM users_meta where user_id = '$uid' ";

//$statement = $conn->prepare($query);
$exe = mysqli_query($con,$query);



if($exe)
{
while($result= mysqli_fetch_assoc($exe))
 {
 echo 'data:image/png;base64,'.base64_encode($result["users_image"]).'';
}
}


?>

