<?php

	include('connect.php');
	include('config.php');
   
	session_start();
	//echo $_SESSION['merchantid'];
	 $uid = $_SESSION['userid'];
	 $tid = $_GET['tid'];
	
	$type =  $_SESSION['user_type'] ;


if(isset($_POST["image"]))
{
 //include('database_connection.php');

 $data = $_POST["image"];


 $image_array_1 = explode(";", $data);

 $image_array_2 = explode(",", $image_array_1[1]);

 $data = base64_decode($image_array_2[1]);

 $imageName = "imagesupload/".$uid."-".time() . '.png';

 file_put_contents($imageName, $data);

 $image_file = addslashes(file_get_contents($imageName));
 
 $selquery = "select * from users_meta where user_id = '$uid'";
  $runquery = mysqli_query($con,$selquery);
 $count = mysqli_num_rows($runquery);

 if($count ==1)
 {
  
  $qry ="UPDATE users_meta set users_image='".$image_file."' WHERE user_id = '". $uid."'";
   $statement = mysqli_query($con,$qry);
 }
 else
 {
  
  $query = "INSERT INTO users_meta(users_image,user_id) VALUES ('".$image_file."','". $uid."')";
  $statement = mysqli_query($con,$query);
  
 }

 if($statement)
 {
  echo 'Image uploaded successfully !';
  //unlink($imageName);
 }

}

?>