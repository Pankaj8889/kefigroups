<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Search</title>
  </head>
<?php
include('connect.php');
include('config.php');
session_start();
if(!($_SESSION['userid']))
{ ?><script>	//window.location.href="user-sign-in.php"; 

    window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

	</script><?php
	//header('location:user-sign-in.php');
}
$uid = $_SESSION['userid'];

?>
 <body>
<?php include('header.php');?>
   
       <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Search</li>
                          
                        </ul>
                      </div>
                    </div>
                 </div>
               </div>

               <div class="user-watchmie-main-section_2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                          <form method="post" action="">
                              
                              <?php
              //include('connect.php');
              if(isset($_POST['search']))
              {
              $term = strtolower($_POST['term']);    
              //$querysearch = "SELECT * FROM post WHERE description LIKE '%".$term."%'";
              $querysearch = "SELECT * FROM user_signup WHERE user_username LIKE '%".$term."%'";


              $resultsearch = mysqli_query($con,$querysearch);

               $count = mysqli_num_rows($resultsearch);
                            if($count >=1){         


              while ($rowsearch = mysqli_fetch_array($resultsearch))
              {
                $id = $rowsearch['user_id'];
                $username = $rowsearch['user_username'];
                $type = $rowsearch['user_type'];
                if($type == 'user' && $id != $uid)
                {
                $qryforfrnd = "select * from user_addfriend where user_id = '$uid'";
                $resultforfrnd = mysqli_query($con,$qryforfrnd);
                      while($rowforfrnd = mysqli_fetch_assoc($resultforfrnd))
                       {
                      $frnd_id[] = $rowforfrnd['addfriend_id'];
                       }
                       //print_r($frnd_id);

                      if(in_array($id,$frnd_id))
                      {
                       echo "Already added as friend";

                      }
                      else
                      {
                         //die("hiii");
                $queryforpic = "select * from users_meta where user_id= '$id'";
                      $resultforpic= mysqli_query($con,$queryforpic);
                      $rowforpic = mysqli_fetch_assoc($resultforpic);
                      $pic = $rowforpic['users_image'];
                      if($pic)
                      {
                        ?>

                          <div class="user-friends-list">
                          <div class="user-friends-pick"><span><a href = "#"><img src ='<?php echo "https://".$baseurl."imagesupload/$pic"; ?>' /></a></span></div>
                           <div class="user-friends-list-title-hero">
                           <input type="checkbox" name="chk" id="chk_<?php echo $rowsearch['user_id'] ;?>" value ="<?php echo $rowsearch['user_id'] ;?>">Add Friend
                           <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                           <span><?php echo $rowsearch['user_username'];?></span>
                           
                           </div>
                          </div>

                            <!--<li class="nav-item">
                              <a href='User/nearmie/alluser_profile.php?id=<?php echo $rowsearch['user_id'];?>'><img src ='<?php echo "https://".$baseurl."imagesupload/".$pic."" ;?>' /></a><br/>
                                  <span><?php echo $username; ?></span>
                                    </li>-->

                                 <?php

                            }
                            else
                            {
                              ?>

                              <div class="user-friends-list">
                          <div class="user-friends-pick"><span><a href = "#"><img src ="images/man.png"/></a></span></div>
                           <div class="user-friends-list-title-hero">
                           <input type="checkbox" name="chk" id="chk_<?php echo $rowsearch['user_id'] ;?>" value ="<?php echo $rowsearch['user_id'] ;?>">Add Friend
                           <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                           <span><?php echo $rowsearch['user_username'];?></span>
                           
                           </div>
                          </div>


                                  <!--<li class="nav-item">
                                                  <a href='User/nearmie/alluser_profile.php?id=<?php echo $rowsearch['user_id'];?>'><img src="images/man.png"></a><br/>
                                                      <span><?php echo $username; ?></span>                        
                                                  </li>-->



                                    <?php
                                  }
                                }
                              }
                              } 
                              }
                              else
                              {
                                echo "No result found";
                              }
                            }
                            //$result = mysqli_fetch_assoc($resultsearch)

                            //echo json_encode( $result );
                            
                              ?> 
                           </form>                  
                       </div>
                    </div> 
                </div> 
             </div> 

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script> 
  </body>
</html>
<!--===============================Check box value send through ajax in user_favourite table==========================-->
<script>
        $(document).on("change", "input[name='chk']", function () {
            var checkbox = $(this);
            var checked = checkbox.prop('checked');
            
        
            var favid = $(this).attr('value');
            var uid = document.getElementById('uid').value;
            //alert(uid);
          //alert(favid);
          //die;

            $.ajax({
                url:"User/nearmie/ajax_useraddfriend.php",
                type: 'post',
                data: {
                    //action: 'checkbox-select', 
                    //id: checkbox.data('contact_avl'),
                    favid: favid,
                    uid: uid,
                    checked:checked
                      },
                success: function(data) {                  
                    window.location.href="https://<?php echo $baseurl;?>User/watchmie/user_friends.php";
                    alert("Friend added in friend list successfully");
                    //alert(data);
                   // alert("yes");
                },
                error: function(data) {
                   // alert(data);
                    // Revert
                    checkbox.attr('checked', !checked);
                }
            });
        });
    </script>
<!--===============================End ajax==========================================================-->
