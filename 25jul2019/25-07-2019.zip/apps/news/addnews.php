<?php
if(isset($_POST['btnsubmit']))
{
    $date = $_POST['datepick'];
    $title = $_POST['title'];
    $description = $_POST['texteditor'];
    
	$querynews = "insert into news(date,news_title,news_description,news_image)values('$date','$title','$description',0)";
	$resultnews = mysqli_query($con,$querynews);
	if($resultnews)
	{
	    echo "success";
	}
}
?>
<html>
    <head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
		<script src="../editor/editor.js"></script>
		<script>
			$(document).ready(function() {
				$("#txtEditor").Editor();
			});
		</script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<link href="../editor/editor.css" type="text/css" rel="stylesheet"/>
		<!--<title>LineControl | v1.1.0</title>-->
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">
				<!--<h2 class="demo-text">LineControl Demo</h2>-->
				<div class="container">
					<div class="row">
						<div class="col-lg-12 nopadding">
						   <br/><br/> Date published <input type="date" name="datepick"><br/>
						    Title <input type="text" name="title">
							<textarea id="txtEditor" name="texteditor"></textarea><br/> 
							<input type="file" name="file">
							<input type="submit" value="Save" name="btnsubmit">
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</body>
</html>

    
