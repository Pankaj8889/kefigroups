<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">    
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://kefigroups.com/apps/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- country code scripts -->
    <!--<link rel="stylesheet" href="intl-tel-input-master/build/css/intlTelInput.css">
  <link rel="stylesheet" href="intl-tel-input-master/build/css/demo.css">--> 
    <!--end country code scripts -->

    <title>Setting</title>
  </head>
<?php
include('connect.php');
include('config.php');
session_start();
/*
if(!($_SESSION['userid']))
{ ?><script>	//window.location.href="user-sign-in.php"; 

    window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

	</script><?php
	//header('location:user-sign-in.php');
}
*/
$uid = $_SESSION['userid'];

if(isset($_POST['btnsubmit']))
{
    //echo "1";
    $uname = $_POST['uname'];
   
    $email = $_POST['email'];
    
    $mobile = $_POST['mobile'];
    $queryin = "update user_signup set user_username ='$uname',user_email ='$email',user_mobileno ='$mobile' where user_id =$uid";
    $resultin = mysqli_query($con,$queryin);
    if($resultin)
    {
       
        $msg = "Data updated successfully";
        
    }
}

$querysetting = "select * from user_signup where user_id = $uid";
$resultsetting = mysqli_query($con,$querysetting);
if($resultsetting)
$rowsetting = mysqli_fetch_array($resultsetting);



/*=========================================INTERFACE====================================================*/

if(isset($_POST['btnpost']))
{
	
	$postvisibility = $_POST['post'];
	//echo "1";
	$changepassword = md5($_POST['changepassword']);
	//die();
	$queryselectpost = "select * from user_signup where user_id = '$uid'";
	$resultselectpost = mysqli_query($con,$queryselectpost);
	$countpost = mysqli_num_rows($resultselectpost);
	if($countpost == 1){
		if(!empty($postvisibility))
		{
		
	$rowselectpost = mysqli_fetch_array($resultselectpost);
	$querypost = "update user_signup set post_visibility = '$postvisibility' where user_id = '$uid'";
	$resultpost = mysqli_query($con,$querypost);
		}
		if(!empty($_POST['changepassword'])){
	
	$querychangepassword = "update user_signup set user_password = '$changepassword' where user_id = '$uid'";
	$resultchangepassword = mysqli_query($con,$querychangepassword);
		}
	
	}
	
	
}


?>
 <body>
<?php include('header.php');?>
  
   <section id="Setting-sec">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="user_tabs">
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#General" role="tab" aria-controls="nav-home" aria-selected="true">General</a>
                          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#Interface" role="tab" aria-controls="nav-profile" aria-selected="false">Interface</a>
                            <!--<a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#Home" role="tab" aria-controls="nav-contact" aria-selected="false">Home</a>-->
                        </div>
                    </nav>                                   
                    <div class="tab-content" id="nav-tabContent">
                        
                        <div class="tab-pane fade show active" id="General" role="tabpanel" aria-labelledby="nav-home-tab">
						<form method="post" action="setting.php">
                        <div class="center-top-text text2"><?php echo $msg; ?></div>
                            <div class="same-style-design">
                                     <div class="form-group row">
                                             <label class="col-sm-2"><strong>User name :</strong></label>
                                            <div class="col-sm-10">
                                               <input class="form-control" type = "text" name = "uname" value = "<?php echo $rowsetting['user_username']; ?>" />
                                            </div>
                                      </div>
                            </div>

                            <div class="same-style-design">
                                
                                 <div class="form-group row">
                                             <label class="col-sm-2"><strong>Email address :</strong></label>
                                            <div class="col-sm-10">
                                               <input class="form-control" type="email" name="email" value="<?php echo $rowsetting['user_email']; ?>" />
                                            </div>
                                </div>
                                <!--<div class="col-md-4">
                                    <div class="user-edit_btn"><a href="#">Edit</a></div>
                                </div>-->
                            </div>

                            <div class="same-style-design">
                              
                               <div class="form-group row">
                                             <label class="col-sm-2"><strong>Mobile number : </strong></label>
                                            <div class="col-sm-10">
                                              <input class="form-control" type = "text" name="mobile" id = "mobile"  value="<?php echo $rowsetting['user_mobileno']; ?>" pattern = "[0-9]{10}" title="Must contain 10 digit mobile number"/>
                                            </div>
                                </div>
                              
                                
                                    
                              <!--  <div class="col-md-4">
                                    <div class="user-edit_btn"><a href="#">Edit</a></div>
                                </div>-->
                            </div>

                            <div class="same-style-design">
                               <div class="form-group row">
                                             <label class="col-sm-2"><strong>Account</strong></label>
                                            <div class="col-sm-10">
                                                <?php 
                                /*============================checked session user is deactive or not=========================*/
                                $queryhib = "select * from user_signup where user_id=$uid && status = 'deactivate'";
                                $resulthib = mysqli_query($con,$queryhib);
                                $row = mysqli_num_rows($resulthib);
                                if($row)
                                {?>
                                              
                                              <div class="user-edit_btn d-active" disabled="true">Hibernate</div>
                                 <?php }
                                 else{
                                ?>
                                           <div class="user-edit_btn"><a href="hibernate.php">Hibernate</a></div>   
                                <?php
                               }
                                /*==============================end checking=================================*/
                               ?>
                               
                                            </div>
                                </div>
                              
                            </div>

                            <div class="user-data-save_btn">
                                <input class="btn btn-info" type = "submit" name="btnsubmit" value ="UPDATE" />
                                </div>
                            </form>     
                        </div>
                           
							
                        <div class="tab-pane fade" id="Interface" role="tabpanel" aria-labelledby="nav-profile-tab">
						
						<!--==============================post visibility value==============================-->
						<?php
						$queryvisibility = "select * from user_signup where user_id = '$uid'";
						$resultvisibility = mysqli_query($con,$queryvisibility);
						$rowvisibility = mysqli_fetch_array($resultvisibility);
						$visibility = $rowvisibility['post_visibility'];
						?>
						
						
						<form method="post" action ="">
						<div class="form-group row">
						<div class="same-style-design" style="margin-top:0;">
						<label class="col-sm-12"><strong>Post visibility:Public/Private/Friend</strong></label>
						</div>
						<div class="col-sm-6">
						<select name = "post">
							<option value = "" selected = "true" disabled>---SELECT POST VISIBILITY---</option>
							<option value="public" <?php if($visibility=="public") echo 'selected="selected"'; ?>>Public</option>
							<option value="private" <?php if($visibility=="private") echo 'selected="selected"'; ?> >Private</option>
							<option value="friends" <?php if($visibility=="friends") echo 'selected="selected"'; ?>>Friends</option>
							
						</select>
						</div>
						</div>
						
						<div class="same-style-design">
						
                                
                                 <div class="form-group row">
                                    <label class="col-sm-5"><strong>Change Password :</strong></label>
									<div class="center hideform">
									<!--<button id="close" style="float: right;">X</button>-->
									<!--<form method = "post">-->
									
									<input type="password" name="changepassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
									<br><br>
									
									<!--<input type="submit" value="Submit">
									</form>-->
									</div>
											 <div class="col-md-6">
                                    <div class="user-edit_btn"><button type="button" id ="show">Edit</button></div>
                                </div>
                                            
                                </div>
                                
                            </div>
                        
                            <div class="user-data-save_btn">
							<button type="submit" name="btnpost">Save</button>
							</div>
						</form>
                        </div>
                        <div class="tab-pane fade" id="Home" role="tabpanel" aria-labelledby="nav-contact-tab">..3.</div>
                    </div>
					
					
					
					
					
                </div>

            </div>
        </div>
    </div>
</section>
	
	
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script> 
  </body>
  <footer>
    <?php include('footer.php'); ?>
  </footer>
</html>

<script type="text/javascript">
	/*$(document).ready(function() {
 
	$('#mobile').on('keypress', function() {
    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/.test(this.value);
    if(!re) {
        $('#error').show();
    } else {
        $('#error').hide();
    }
});

});*/
</script>
<script>
$('#show').on('click', function () {
    $('.center').show();
    $(this).hide();
})

/*$('#close').on('click', function () {
    $('.center').hide();
    $('#show').show();
})*/
</script>
<style>
/*.center {
    margin: auto;
    width: 60%;
    padding: 20px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}*/

.hideform {
    display: none;
}
</style>
<!--<script src="intl-tel-input-master/build/js/intlTelInput.js"></script>
  <script>
    var input = document.querySelector("#mobile");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
      // hiddenInput: "full_number",
      // initialCountry: "auto",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
      // separateDialCode: true,
      utilsScript: "intl-tel-input-master/build/js/utils.js",
    });
  </script>-->