<?php
/*
$to = "ns947675@gmail.com";
$subject = "My subject";
$txt = "Hello ";
$headers = "From: webmaster@example.com" ;


if(mail($to,$subject,$txt,$headers))
{
	echo "mail send";
}
else
{
	echo "email not send";
}
*/


ini_set( 'display_errors', 1 );
error_reporting( E_ALL );
$from = "contact@kefigroups.com ";
$to = "hr.codingxperts@gmail.com";
$subject = "Checking PHP mail";
$message = "PHP mail works just fine";
$headers = "From:" . $from;
mail($to,$subject,$message, $headers);
echo "The email message was sent.";
?>
