<?php
$abspath = $_SERVER['DOCUMENT_ROOT'];
$baseurl =  $_SERVER['SERVER_NAME']."/apps/";
session_start();
	
	if (!isset($_SESSION['userid']))
	 {
	 	?>
	 	<script>
			window.location.href="https://<?php echo $baseurl; ?>User/user-sign-in.php";
		</script>
	 	<?php        
        
    }
    $now = time(); // Checking the time now when home page starts.
    if ($now > $_SESSION['expire'])
     {
     	$uid = $_SESSION['userid'];
		$query = "update user_addfriend set user_status ='offline' where addfriend_id = '$uid'";
		$result = mysqli_query($con,$query);
		$qry = "update user_signup set user_status = 'offline' where user_id = '$uid' ";
		$result = mysqli_query($con,$qry);
        session_destroy();
        ?>
	 	<script>
			window.location.href="https://<?php echo $baseurl; ?>User/user-sign-in.php";
		</script>
	 	<?php 
        
     }
	/*if(!($_SESSION['userid']))
	{ 
	?>
	<script>
	window.location.href="https://<?php echo $baseurl; ?>User/user-sign-in.php";
	</script>
	<?php
		//header('location:https://'.$baseurl.'/Kefi/User/user-sign-in.php');
	}*/
	
?>