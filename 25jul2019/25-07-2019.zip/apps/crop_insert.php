<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db = "test";

$conn = mysqli_connect($servername,$username ,$password , $db);


if(isset($_POST["image"]))
{
 //include('database_connection.php');

 $data = $_POST["image"];
 $uploads_dir = 'uploads/';

 $image_array_1 = explode(";", $data);

 $image_array_2 = explode(",", $image_array_1[1]);

 $data = base64_decode($image_array_2[1]);

 $imageName = "uploads/".time() . '.png';

 file_put_contents($imageName, $data);

 $image_file = addslashes(file_get_contents($imageName));

 $query = "INSERT INTO tbl_images(images) VALUES ('".$image_file."')";


//move_uploaded_file($imageName, "$uploads_dir");
 //$statement = $connect->prepare($query);
 $statement = mysqli_query($conn,$query);

 if($statement)
 {
  echo 'Image save into database';
  //unlink($imageName);
 }

}



?>