  <?php include('config.php');
  session_start();
 	$type =  $_SESSION['user_type'] ;

$urlink = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
//echo $urlink;
//echo "<br>";
 $url = "https://".$baseurl."index.php";

if($urlink == $url || $type == 'merchant' )
{


 	?>
	<header>
		<div class="sub-header-main">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="site-logo">
						<!--<a href="https://<?php echo $baseurl; ?>index.php"><img src="https://<?php echo $baseurl; ?>images/logo.png"></a>-->
		
						</div>
					</div>
					
					<div class="col-md-9">
						<div class="name-group">
							<ul class="nav justify-content-end">
								<li class="nav-item">
									<a href="https://<?php echo $baseurl; ?>index.php"><i class="fa fa-home home-icon1" aria-hidden="true"></i> <br>Home</a>
								</li>

								<?php
								/*
								if($type == 'user')
								{?>
									<li class="nav-item">
									<a href="https://<?php echo $baseurl; ?>User/nearmie/profile_seen.php"><i class="fa fa-eye fa-2" aria-hidden="true"></i>
                                    <br>Status</a>
								</li>

								<?php
							}
							*/
									?>




								<?php
									if(	$type == 'merchant')
									{?>
								<li class="nav-item">
									
									<div class="menu-name-list My-Account Products">
										<div class="dropdown">
										<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<!--<a class="p-0" href="<?php //echo $baseurl; ?>/Merchant/merchant_addproduct.php">-->
										<img class="products-ICON" src="https://<?php echo $baseurl; ?>images/products-icon.png">
					                                   Product
					                    <!-- </a>-->
											</button>
											<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											<ul class="Products-title-name">
												<li><a href="https://<?php echo $baseurl; ?>Merchant/merchant_addproduct.php">Add  new  product</a></li>	
												<li><a href="https://<?php echo $baseurl; ?>Merchant/product_view.php">All products</a></li>
											</ul>
										</div>
					
										</div>			
					
					                </div>
											
							
								</li>
								<?php } ?>

									<!--<li class="nav-item">
									<a href="https://<?php echo $baseurl; ?>User/nearmie/profile_seen.php"><i class="fa fa-eye fa-2" aria-hidden="true"></i>
                                    <br>Profile View</a>
								</li>-->						
								
								<li class="nav-item">
									<a href="https://<?php echo $baseurl; ?>setting.php"><img src="https://<?php echo $baseurl; ?>images/setting-icon.png">
                                    <br>Settings</a>
								</li>
								<li class="nav-item">
														
									<div class="menu-name-list My-Account">
										<div class="dropdown">
											<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<img src="https://<?php echo $baseurl; ?>images/user-icon.png">
					                                    <br>Profile
											</button>
											<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											<a class="dropdown-item" href="https://<?php echo $baseurl; ?>User/user_logout.php"><i class="fa fa-power-off" aria-hidden="true"></i> Logout</a>						
										</div>
					
										</div>			
					
					                </div>
									
								</li>
							</ul>
		
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</header>
	<?php
}
	?>