<?php
include('connect.php');
include('config.php');
if(isset($_POST['comment']) && isset($_POST['name']) && isset($_POST['postid']))
{

	$name=$_POST['name'];
	$comment=$_POST['comment'];
	$postid=$_POST['postid'];
	$date1 =date('Y-m-d h:i:sa');

	$query = "insert into post_comments(name,comment,post_time,post_id) values('$name','$comment','$date1','$postid')";
	$runquery = mysqli_query($con,$query);
	if($runquery)
	{
		//echo '<li>'.$comment.'</li>';
		$select=mysqli_query($con,"select * from post_comments where name='$name' and comment='$comment' and post_id='$postid'");
  
		  if($row=mysqli_fetch_array($select))
		  {
			  $name=$row['name'];
			  $comment=$row['comment'];
		      $time=$row['post_time'];
		  ?>
		      <div class="comment_div"> 
			    <p class="name">Posted By:<?php echo $name;?> <strong class="time"><?php echo $time;?></strong></p>
		        <p class="comment"><?php echo $comment;?></p>	
			  </div>
		  <?php
		  }

	}

}


?>