<?php
include('image-resize/vendor/autoload.php');

use \Gumlet\ImageResize;

if (isset($_POST["submit"])) {   
    
    
  
    //$path = $_SERVER['DOCUMENT_ROOT']."apps/imagesupload/thumbs/";
    $path = 'imagesupload/thumbs/';
   
     $tmpFile = $_FILES["file"]["tmp_name"];
    
     $fileName = $_FILES["file"]["name"];
    
    
     $file = $path."thumb_".$fileName;
	 
	$image = new ImageResize($tmpFile);
	$image->resizeToBestFit(300, 300);
	$image->save($file);
	echo "end ";
}

?>
<form action="" method="post" enctype="multipart/form-data">
 <label for="file">Image:</label>
 <input type="file" name="file" id="file"><br>
 <input type="submit" name="submit" value="Upload and Crop">
</form>

