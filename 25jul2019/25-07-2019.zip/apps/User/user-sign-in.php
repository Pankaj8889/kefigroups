<?php  
include('../connect.php');
//include('../config.php');
session_start();

if(isset($_POST['btnlogin']))
{

		
/* 		if(isset($_COOKIE[$cookie_name])) {
			echo "Cookie '" . $cookie_name . "' is set!<br>";
			echo "Value is: " . $_COOKIE[$cookie_name];
			die();
			
		} else {
			
			echo "Cookie named '" . $cookie_name . "' is not set!";
			//header("Location: ".$_SERVER["PHP_SELF"]);
			die();
			
		}	 */
	
    
	
	$useremail = $_POST['email'];
	$userpassword =md5($_POST['password']);
	$remember = $_POST['remember_me'];
	//die();
	//$userpassword=password_hash($userpassword1, PASSWORD_DEFAULT);
	
	$querydec = "select * from user_signup where status='deactivate' &&  user_email = '$useremail'";
	$resultdec = mysqli_query($con,$querydec);
	$rowdec = mysqli_num_rows($resultdec);
	if($rowdec)
	{
	    $msgdec = "Your account has been hibernated.Please <a href='https://www.kefigroups.com/apps/rehibernate.php'>CLICK HERE</a> to re-hibernate the account";
	}
	else{
	$querylogin = "select * from user_signup where user_email='$useremail'and user_password='$userpassword'";
	$resultlogin = mysqli_query($con,$querylogin);
	if(!$resultlogin)
	{
		echo "Error while insertion".mysqli_error($con);
	}
	 $countlogin = mysqli_num_rows($resultlogin);



	if(trim($countlogin) == 1)
	{
		

		$cookie_email = "email";
		$cookie_valueemail = $useremail;
		$cookie_password = "password";
		$cookie_valuepass = $userpassword;
		
		setcookie($cookie_email, $cookie_valueemail, time() + (60 * 30), "/");
		setcookie($cookie_password, $cookie_valuepass, time() + (60 * 30), "/"); 
		//setcookie($cookie_email, $cookie_valueemail, time() + (60 * 2), "/");
		//setcookie($cookie_password, $cookie_valuepass, time() + (60 * 2), "/"); 
		
		
		
		
/* 		echo $_COOKIE[$cookie_name];
die("asdasdasdasd"); */		

					
					
	    
		$rowlogin = mysqli_fetch_assoc($resultlogin);

		 $_SESSION['userid'] = $rowlogin['user_id'];
		 $_SESSION['start'] = time();
		 $_SESSION['expire'] = $_SESSION['start'] + (60 * 15);
		 //echo $_SESSION['start']."<br>" ;
		 //echo $_SESSION['expire']."<br>" ;
		//die();
	
		$_SESSION['user_username'] = $rowlogin['user_username'];
		$_SESSION['user_type'] = $rowlogin['user_type'];
	
		$uid = $_SESSION['userid'];
		$queryonline="update user_signup set user_status='online' where user_id = '$uid'";
		$resultonline = mysqli_query($con,$queryonline);
		
?>

		<script>	window.location.href="https://kefigroups.com/apps/index.php";	</script>	<?php
	   //header('location:../index.php');
		
	}
	else
	{
		$msg = "Invalid Email/Password";
	}

}
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Sign In</title>
  </head>
  <body id="Sign_in_page">

    <section id="sign-up-page" class="sign-up-page">
    <div class="container">
            <div class="">
                <div id="form_box_area" class="right-bar-Sec">
                    <div class="Same-style-form login">
					  <div class="logo-header">
                            <a href="javascript:void(0);"><img src="../images/logo.png"></a>
                        </div>
                        <div class="center-top-text text1"><?php echo $msgdec; ?></div>
                            <?php  if (empty(!$msg)) {
                                ?>
                                <div class="alert alert-danger">
                                  <strong><?php echo $msg; ?></strong>
                                </div>
                                <?php
                                }
                            ?>
                        <form class="needs-validation" novalidate name="usersignin" action="" method="post">
                            <div class="form-group">
                              
                                <input type="email" class="form-control" id="validationCustom03" placeholder="Email" required name="email">
								<img src="../images/email-icon-1.png">
                            </div>
                            <div class="form-group">
                               
                                <input type="password" class="form-control" id="validationCustom03" placeholder="Password" required name="password">
								<img src="../images/lock.png">
                            </div>                 
						
							<div class="custom-control custom-checkbox Remember_me">
								<input type="checkbox" class="custom-control-input" id="customControlInline" required name = "remember_me">
								<label class="custom-control-label" for="customControlInline">KEFI, Remember me! </label>
							</div>								
						
							 <div class="click-btn">							 					
							 <button type="submit" class="btn btn-primary secondary" name="btnlogin">Login</button><br/>	
							  <p>Not Registered? <a href="user-sign-up.php">Sign Up</a></p>
							</div>
                        </form>
                    
                    </div>
                </div>
            </div>
    </div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script> 
  </body>
</html>
