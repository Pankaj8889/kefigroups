<?php
include('../connect.php');
include('../config.php');
session_start();
$pid = $_GET['tid'];//get post id
$uid = $_SESSION['userid'];
$querypost = "select * from post where post_id = '$pid'";
$resultpost = mysqli_query($con,$querypost);
$rowpost = mysqli_fetch_array($resultpost);
$touid = $rowpost['user_id'];
$queryinsert = "insert into post_share(from_userid,to_userid,post_id) values('$uid','$touid','$pid')"; //insert post in to database
$resultpost = mysqli_query($con,$queryinsert);
   
$queryselect = "select * from post_share where from_userid = '$uid' ORDER BY share_id DESC;";
$resultselect = mysqli_query($con,$queryselect);

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Share Post</title>
  </head>
  <?php include('../header.php'); ?>
   <body>
       
       <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Post</li>
                        </ul>
                    </div>
                </div>
           </div>
       </div>
<div class="user-watchmie-main-section">
    <div class="user-post-section-1">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    
                   
                <?php
                    while($rowselect = mysqli_fetch_array($resultselect))  //fetch value from post_share table to display shared post
                    {
                         $postid = $rowselect['post_id'];
                         $touuid = $rowselect['to_userid'];
                         $fromuuid = $rowselect['from_userid'];
                         $queryuserto = "select * from user_signup where user_id = '$touuid'";
                         $resultuserto = mysqli_query($con,$queryuserto);
                         $rowuserto = mysqli_fetch_array($resultuserto);
                         $touserid = $rowuserto['user_username'];
                         $queryuserfrom = "select * from user_signup where user_id = '$fromuuid'";
                         $resultuserfrom = mysqli_query($con,$queryuserfrom);
                         $rowuserfrom = mysqli_fetch_array($resultuserfrom);
                         $fromuserid = $rowuserfrom['user_username'];
                    ?>
                        <div class="media-user-post-block-media1">                
                         <div class="media user-post-block-media">
                     <!--<img class="mr-3 Hero-user-pick" src="../images/man.png" alt=""><br/>
                             <span>username</span>-->
                           <div class="media-body">
                               
                                <span class="user"><?php echo $fromuserid; ?> shared <?php echo $touserid; ?>'s post</span><br/>
                                <?php
                                /*============ select post from post table whose postid is matched with post share(table) postid =======*/
                                
                                    $querypost1 = "select * from post where post_id = '$postid'";
                                    $resultpost1 = mysqli_query($con,$querypost1);
                                    $rowpost1 = mysqli_fetch_array($resultpost1);
                                    $rowpost1['post_id'];
                                ?>
                                <p><br/><a href ="post_details.php?id=<?php echo $rowpost1["post_id"];?>"><?php echo $rowpost1['description']; ?></a></p>
                                	<?php
										if (!empty($rowpost1['post_media']))
										{
										?>
									<div class="user__media__upload">
 										<span>Media :</span><a href="User/post_details.php?id=<?php echo $rowpost1["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$rowpost1['post_media'];?> </a>
									</div>
									<?php
										}
										?>
                            </div>
                       
                    </div>
                    <?php
                    /*=======================================Select post seen from post table==============================*/
						//	$ppid = $rowdis['post_id'];
							//$queryseen = "select post_seen from post where post_id = $ppid";
							$queryseen = "select count(distinct user_id) as seen from post_seen where post_id = '$postid' ";
							$resultseen = mysqli_query($con,$queryseen);
							if($resultseen)
							$rowseen = mysqli_fetch_array($resultseen);
					/*========================================End post seen =============================*/		
                     ?>
                    <div class="user-like-section">
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="JavaScript:Void(0);"><img src="../images/seen-icon.png"> &nbsp;Seen(<?php echo $rowseen['seen'];?>)</a>
                            </li>
                            <li class="nav-item">
                                <a href="post_details.php?id=<?php echo $rowpost1["post_id"];?>"><img src="../images/say-something-icon.png"> &nbsp;Say Something</a>
                            </li>
                            <li class="nav-item">
                                <a href="postshare.php?tid=<?php echo $rowpost1["post_id"];?>" value="like"><img src="../images/toss-icon1.png"> &nbsp;Toss</a>
                            </li>
                        </ul>
                    </div>
                 </div>
                 <?php
                    }//End while loop
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
       
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/custom.js"></script> 
	
</body>
</html>
