<?php
//upload.php
session_start();
include('../config.php');
include('../connect.php');
$uid = $_SESSION['userid'];
//	echo $uid;
if($_FILES["file"]["name"] != '')
{
    
$filepath = date("YmdHis") . "_thumb.jpg";    

$file = $_FILES['file']['tmp_name']; 
$source_properties = getimagesize($file);
$image_type = $source_properties[2]; 
if( $image_type == IMAGETYPE_JPEG ) {
$image_resource_id = imagecreatefromjpeg($file);  
$target_layer = fn_resize($image_resource_id,$source_properties[0],$source_properties[1]);
$img = imagejpeg($target_layer,'../imagesupload/'.$filepath);

//$file= $target_layer,'../imagesupload/'.$filepath;
//echo $target_layer;
}
elseif( $image_type == IMAGETYPE_PNG ) {
$image_resource_id = imagecreatefrompng($file); 
$target_layer = fn_resize($image_resource_id,$source_properties[0],$source_properties[1]);

$img = imagepng($target_layer,'../imagesupload/'.$filepath);
}

$logo1 = $filepath;
if($img)
{
     $queryuser = "SELECT * FROM users_meta WHERE user_id = '$uid'";
	 $resultuser = mysqli_query($con,$queryuser);
	 if (mysqli_num_rows($resultuser) != 0)
	 {
	  $queryup = "update users_meta set users_image = '$logo1' where user_id = '$uid'";
	 	//echo "update users_meta set users_image = '$logo1' where user_id = $uid";
	 	$resultup = mysqli_query($con,$queryup);
	 
	 }
	 else
	 {
	 	//echo "3";
		$query = "insert into users_meta(users_image,user_id)values('$logo1','$uid')";
		$result = mysqli_query($con,$query);
	 }

}	

	// }
	 
// echo '<img src="'.$location.'" height="150" width="225" class="img-thumbnail" />';
 //$query = "insert into users_meta(users_image,user_id)values('$logo1','1')";
	//	$result = mysqli_query($con,$query);
 //}
 
 echo "https://".$baseurl."imagesupload/".$filepath;
}

function fn_resize($image_resource_id,$width,$height) {
    $target_width =300;
    $target_height =300;
    $target_layer=imagecreatetruecolor($target_width,$target_height);
    imagecopyresampled($target_layer,$image_resource_id,0,0,0,0,$target_width,$target_height, $width,$height);
    return $target_layer;
}
?>