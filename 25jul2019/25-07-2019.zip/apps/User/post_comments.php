<?php
include('../connect.php');
include('../config.php');
if(isset($_POST['user_comm']) && isset($_POST['user_name']) && isset($_POST['pro_id']))
{
  $comment=$_POST['user_comm'];
  $name=$_POST['user_name'];
  $poid=$_POST['pro_id'];
  $date = date('Y-m-d h:i:s');
  //echo $proid;
  $insert=mysqli_query($con,"insert into post_comments values('','$name','$comment','$date','$poid')");
  
  //$id=1;

  $select=mysqli_query($con,"select * from post_comments where name='$name' and comment='$comment' and post_id='$poid'");
  
  if($row=mysqli_fetch_array($select))
  {
	  $name=$row['name'];
	  $comment=$row['comment'];
      $time=$row['post_time'];
  ?>
      <div class="comment_div"> 
	    <p class="name">Posted By:<?php echo $name;?> <strong class="time"><?php echo $time;?></strong></p>
        <p class="comment"><?php echo $comment;?></p>	
	  </div>
  <?php
  }
exit;
}

?> 