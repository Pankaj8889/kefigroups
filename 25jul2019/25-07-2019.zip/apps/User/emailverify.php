<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Sign Up</title>
  </head>
        <!-- start PHP code -->
        <?php
         include('../connect.php');
		 if(isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['hash']) && !empty($_GET['hash'])){
    // Verify data
    $email = $_GET['email']; // Set email variable
    $hash = $_GET['hash']; // Set hash variable
	$search = "SELECT user_email, hash, active FROM user_signup WHERE user_email='".$email."' AND hash='".$hash."' AND active='0'" ; 
	$result = mysqli_query($con,$search);
	
	$match  = mysqli_num_rows($result);
	?>
	  <body id="user-up_page">
    <section id="sign-up-page">
    <div class="container">
            <div class="custom__container">
                <div id="form_box_area" class="right-bar-Sec">
                    <div class="Same-style-form Sign-up">
					    <div class="logo-header">
                            <a href="javascript:void(0);"><img src="../images/logo.png"></a>
                        </div>						                
                      <?php  if($match > 0){
        // We have a match, activate the account
        $searchup = "UPDATE user_signup SET active='1' WHERE user_email='".$email."' AND hash='".$hash."' AND active='0'";
		$resultup = mysqli_query($con,$searchup);
        echo '<div class="statusmsg">Your account has been activated, you can now <a href="user-sign-in.php">login</a></div>';
    }else{
        // No match -> invalid url or account has already been activated.
        echo '<div class="statusmsg">The url is either invalid or you already have activated your account.</div>';
    }
                 
	}else{
    // Invalid approach
    echo '<div class="statusmsg">Invalid approach, please use the link that has been send to your email.</div>';
	}

             
        ?>
                       
                        
                    </div>
                </div>
            </div>
    </div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script>
 
	
	
        <!-- stop PHP Code -->
 
         
   
    <!-- end wrap div --> 
</body>
</html>