<?php
$to = "suraj.codingxperts@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: webmaster@example.com" ;


if(mail($to,$subject,$txt,$headers))
{
	echo "mail send";
}
else
{
	echo "email not send";
}

?>