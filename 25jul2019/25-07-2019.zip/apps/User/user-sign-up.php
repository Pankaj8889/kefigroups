<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <title>Sign Up</title>
  </head>
<?php
include('../connect.php');
//ob_start();//echo https://."'$baseurl'"./Kefi/User/user-sign-in.php
if(isset($_POST['submit']))
{
  
     $la=$_POST['geoData'];//fetch latitude and longitude value
    $var1 = explode("/",$la);//seperate latitide and longitide value from script

	$usercategory = $_POST['radio-stacked'];
	$username = strtolower($_POST['username']);
	$useremail = $_POST['email'];
	$userid =date("YmdHis");
	$userpassword = md5($_POST['password']);
		$hash = md5( rand(0,1000) );
	
       
	//$userpassword=  password_hash($userpassword1, PASSWORD_DEFAULT);
	$query = "insert into user_signup(user_id,user_category,user_username,user_email,user_password,user_type,latitude,longitude,hash,active,post_visibility) values('$userid','$usercategory','$username','$useremail','$userpassword','user','$var1[0]','$var1[1]','$hash',0,'public')";
	$res = mysqli_query($con,$query);
	if($res)
	{
	    //$msg = "You are registered successfully.";	?>	
		<script>	window.location.href="success.php";	</script>	
		<?php
	    //header('Location:https://kefigroups.com/Kefi/User/user-sign-in.php');
		//echo $useremail;
		//echo "Success: Your account is created successfully, please check your email for verification link to activate your account.";

		/*$to = $useremail;
		$subject = "Signup | Verification";
		$txt = "Thanks for signing up!
			Your account has been created, you can login after you have activated your account by pressing the url below.
			Please click this link to activate your account:
			https://www.kefigroups.com/apps/User/emailverify.php?email=$useremail&hash=$hash";
		$headers = "From: kefi@example.com" ;
      //$headers = "From: webmaster@example.com" ;


  mail($to,$subject,$txt,$headers); */


ini_set( 'display_errors', 1 );

//error_reporting( E_ALL );

$from = "contact@kefigroups.com ";

$to = $useremail;

$subject = "Signup | Verification";

$txt = "Thanks for signing up!
			Your account has been created, you can login after you have activated your account by pressing the url below.
			Please click this link to activate your account:
			https://www.kefigroups.com/apps/User/emailverify.php?email=$useremail&hash=$hash";

$headers = "From:" . $from;

mail($to,$subject,$txt, $headers);

//echo "The email message was sent.";
  
      
		
	}
	else
	{
	    $msg = "Email Already Exist.Please signup with another account";
	}

	
}
?>
  <body id="user-up_page">
    <section id="sign-up-page">
    <div class="container">
            <div class="custom__container">
                <div id="form_box_area" class="right-bar-Sec">
                    <div class="Same-style-form Sign-up">
					    <div class="logo-header">
                            <a href="javascript:void(0);"><img src="../images/logo.png"></a>
                        </div>						                
                        
                        <form class="needs-validation" novalidate name="usersignup" action="" method="post">
                        <!--<form class="needs-validation" novalidate name="usersignup" action="user-sign-up.php" method="post" onsubmit="return checkForm(this);">-->
						<div class="Category-box">
						    <?php  if (empty(!$msg)) {
                                ?>
                                <div class="alert alert-danger">
                                  <strong><?php echo $msg; ?></strong>
                                  <?php echo $msgrestrict; ?>
                                </div>
                                <?php
                                }
                                ?>
                            <div class="Category-title text-center"><h3>Select  Category</h3></div>
						<ul class="nav User_sign_up justify-content-center">
						    <li>
                                <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation1" name="radio-stacked" required value="male">
                                    <label class="custom-control-label" for="customControlValidation1">
                                        <img src="../images/male-gender-sign.svg">
                                </label>
                                </div>
							</li>
							<li>
                                  <div class="custom-control custom-radio mb-2">
                                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked" required value="female">
                                    <label class="custom-control-label" for="customControlValidation2">
                                      <img src="../images/female-icon.svg"> 
                                    </label>
                                  </div>
							</li>
						</ul>
                        </div>
                            <div class="form-group">                              
                                <input type="text" class="form-control" id="validationCustom01" placeholder="User Name" name="username" required>
								<img src="../images/user-icon.svg">
                            </div>
                            <div class="form-group">
                              
                                <input type="email" class="form-control" id="validationCustom02" placeholder="Email" name="email" required>
								<img src="../images/email-icon-1.png">
                            </div>
                            <div class="form-group">
                               
                                <!--<input type="password" class="form-control" id="validationCustom03" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>-->

                                <input required type="password" class="form-control" id="validationCustom" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
								<img src="../images/lock.png">
                                
								
                            </div>
                            <span id="pwderror" style="display:none;">Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters</span>
							 <div class="custom-control custom-checkbox Remember_me">
								<input type="checkbox" class="custom-control-input" id="customControlInline" onclick="getLocation();" required>
								<label class="custom-control-label" for="customControlInline">Agreed to KEFI's Disclaimer</label>
							  </div>
							  <!--=================latitude and longitude================ in submit button onclick function to call script-->
							  <input name="geoData" id="inputId" required value="" hidden >
                            <div class="click-btn">							 					
							 <button type="submit" class="btn btn-primary secondary" name="submit" >Sign Up</button>	
							
							</div>							
                        </form>
                        
                    </div>
                </div>
            </div>
    </div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script>

	
<!--================================================== for latitude and longitude================================-->	
<script>

var x = document.getElementById("inputId");

function getLocation() {
	alert("Please allow access to location");
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.value = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    x.value = position.coords.latitude + 
    "/ " + position.coords.longitude;

}
</script>

<!--=====================passowrd validation==========-->

<!--<script type="text/javascript">

  function checkForm(form)
  {
    
    

    if(form.password.value != "" ) {
      if(form.password.value.length < 8) {
        alert("Error: Password must contain at least 8 characters!");
        form.password.focus();
        return false;
      }
    
      re = /[0-9]/;
      if(!re.test(form.password.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        form.password.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(form.password.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.password.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(form.password.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.password.focus();
        return false;
      }
    } else {
      alert("Error: Please enter password!");
      form.password.focus();
      return false;
    }

    //alert("You entered a valid password: " + form.pwd1.value);
    //return true;
  }

</script>-->
<script>
  $(document).ready(function() {
 
  $('#validationCustom').on('keypress', function() {
    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/.test(this.value);
    if(!re) {
        $('#pwderror').show();
    } else {
        $('#pwderror').hide();
    }
})

});
</script>
  </body>
</html>