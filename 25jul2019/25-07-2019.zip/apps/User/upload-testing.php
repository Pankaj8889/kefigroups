<?php

session_start();
include('../config.php');
include('../connect.php');
$uid = $_SESSION['userid'];

//if(isset($_POST["submit"])) {
if($_FILES["file"]["name"] != ''){

$file = $_FILES['file']['tmp_name'];
$filepath = date("YmdHis") . "_thumb.jpg"; 
 
$source_properties = getimagesize($file);
$image_type = $source_properties[2]; 
if( $image_type == IMAGETYPE_JPEG ) {   
//$image_resource_id = imagecreatefromjpeg($file);  


 
$image_resource_id = imagecreatefromjpeg($file);  


$exif = exif_read_data($file);

         if (!empty($exif['Orientation'])) {
             switch ($exif['Orientation']) {
                 case 8:
                     $image_resource_id = imagerotate($image_resource_id, 90, 0);
                     break;
                 case 3:
                     $image_resource_id = imagerotate($image_resource_id, 180, 0);
                     break;
                 case 6:
                     $image_resource_id = imagerotate($image_resource_id, -90, 0);
                     break;
             }
         }





$target_layer = fn_resize($image_resource_id,$source_properties[0],$source_properties[1]);
$up = imagejpeg($target_layer,'../imagesupload/'.$filepath);
//imagejpeg($target_layer,'../imagesupload/'.$filepath);
if($up)
{
//echo"file uploaded jpg";
}

}
elseif( $image_type == IMAGETYPE_PNG ) {
$image_resource_id = imagecreatefrompng($file); 
$target_layer = fn_resize($image_resource_id,$source_properties[0],$source_properties[1]);
$up = imagepng($target_layer,'../imagesupload/'.$filepath);
if($up)
{
//echo"file uploaded png";
}


}
else{
//echo "please select valid image";
}
}
else{
//echo "not selected";
}

$logo1 = $filepath;
if($up){
    
     $queryuser = "SELECT * FROM users_meta WHERE user_id = '$uid'";
	 $resultuser = mysqli_query($con,$queryuser);
	 if (mysqli_num_rows($resultuser) != 0)
	 {
	  $queryup = "update users_meta set users_image = '$logo1' where user_id = '$uid'";
	 	//echo "update users_meta set users_image = '$logo1' where user_id = $uid";
	 	$resultup = mysqli_query($con,$queryup);
	 
	 }
	 else
	 {
	 	//echo "3";
		$query = "insert into users_meta(users_image,user_id)values('$logo1','$uid')";
		$result = mysqli_query($con,$query);
	 }

}
else{
    //echo "image not uploaded";
}

echo "https://'".$baseurl."'imagesupload/".$filepath;



function fn_resize($image_resource_id,$width,$height) {
$target_width =300;
$target_height =300;
$target_layer=imagecreatetruecolor($target_width,$target_height);
imagecopyresampled($target_layer,$image_resource_id,0,0,0,0,$target_width,$target_height, $width,$height);
return $target_layer;
}
?>