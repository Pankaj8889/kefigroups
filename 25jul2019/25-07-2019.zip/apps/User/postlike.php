<?php

include('../connect.php');
include('../config.php');
session_start();
$pid = $_GET['id'];
$uid = $_SESSION['userid'];
$query = "insert into post_likes(user_id,post_id,likes) values('$uid','$pid',1)";
$result = mysqli_query($con,$query);

if($result)
{
    header("Location: https://'".$baseurl."'index.php"); /* Redirect browser */
    exit();
    
/*$query12 = "select count(distinct user_id) as value from post_likes where post_id = $pid";
$result12 = mysqli_query($con,$query12);
$row = mysqli_fetch_array($result12);
echo $row['value'];*/
}
?>