<?php

/*$url1= $_SERVER['REQUEST_URI'];
$var1 = explode('/',$url1);
$var21 = explode('?',$var1[2]);
$var31 = explode('=',$var21[1]);
$post_idd1= $var31[1];*/


include('../config.php');
include('../connect.php');
//include('comments/connect1.php');
//require_once '../comments/display_com.php';



session_start();
$uid = $_SESSION['userid'];
$postid = $_GET['id'];
$username = $_SESSION['user_username'];
//echo $postid;

$querypost = "select * from post WHERE post_id = $postid";
$resultpost = mysqli_query($con,$querypost);
if($resultpost)
$rowpost = mysqli_fetch_array($resultpost);
$vid = $rowpost['post_media'];


/*$sql = "UPDATE post SET post_seen = post_seen + 1 WHERE post_id = $postid"; 
$resultsql = mysqli_query($con,$sql);*/

$sql = "insert into post_seen(post_id,user_id,post_seen) values('$postid','$uid',1)";
$resultsql = mysqli_query($con,$sql);

//echo $vid;
?>

<!--<div>
   <br/><br/> Post Description : <?php// echo $rowpost['description'];?>
   <br/><br/> Published : <?php //echo $rowpost['date'];?>
</div>-->


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/stylecomment.css">
    <link rel="stylesheet" href="../css/responsive.css">
	<link rel="stylesheet" href="https://djea2nr17ey16.cloudfront.net/wp-content/themes/astronaut-2014/css/font-awesome-4.7.0.css">
    <title>Post</title>
  </head>
  <body>
<?php include('../header.php');?>
	
	<section class="post-block">
		
		<div class="container">
			<div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          
                          <li>Post</li>
                        </ul>
                </div>
			<div class="custom-container-center">
			<div class="mb-5">
			 <div class="user-post-information">
			     <?php
	                $ext = pathinfo($vid, PATHINFO_EXTENSION);
	                //echo $ext;
	                if($ext == 'wav' || $ext == 'ogg' || $ext == 'mpeg')
	                {
                  ?>
                        <audio controls>
                        <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="audio/<?php echo $ext; ?>">
                        </audio>
                 <?php
                    }
                    $url = "https://".$baseurl."imagesupload/";
                     if ($ext == 'png' || $ext =='jpeg' || $ext == 'jpg')
                    
                        echo '<img src= "'.$url.$vid.'" alt="HTML5 Icon"/>';
                         //'<img src="'.$vid.'" alt="HTML5 Icon"/>'
                    
                    
                    if ($ext == 'webm' || $ext == 'mp4' || $ext == 'ogg')
                    {
                    ?>
                    <video autoplay>
                     <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="video/<?php echo $ext; ?>">
                     </video>
                    <?php
                    }
                    ?>
			     <!--<a href=""><img src="images/post-img.jpg"></a></div>-->
			 <p><?php echo $rowpost['description'];?> </p>
			  <div class="comment-Area mt-4">
			 <ul class="nav">
			 	<?php	
				/*	$querylikes = "select count(distinct user_id) as value from post_likes where post_id = $postid";
					$resultlikes = mysqli_query($con,$querylikes);
					$rowlikes = mysqli_fetch_array($resultlikes);*/
				?>					
			<!--	<li><a href=""> Toss (<?php //echo $rowlikes['value'];?>)</a></li>-->
			<?php	
				$url1= $_SERVER['REQUEST_URI'];
				$var1 = explode('/',$url1);
				$var21 = explode('?',$var1[2]);
				$var31 = explode('=',$var21[1]);
				$post_idd1= $var31[1];
				//require 'connect.php';
				$result = mysqli_query($con, "SELECT * FROM `post_comments` WHERE post_id =$postid  ORDER BY `post_time` DESC");
				//echo "SELECT * FROM `comment_parents` WHERE post_id ='$var31[1]'  ORDER BY `date` DESC";
				$row_cnt = mysqli_num_rows($result);
			/*	echo '<h1>All Comments ('.$row_cnt.')</h1>';*/
			?>			
				<li><a href="">Comment(<?php echo  ($row_cnt);?>)</a></li>
				<!--<li><a href=""> Posts (3)</a></li>-->
			 </ul>			 
			 </div>
			 
			<!-- <div class="user-CommenT">
			 <form>
				<div class="form-group">
					<textarea    class="form-control" id="" placeholder="Comment"></textarea>
				</div>
				<div class="form-group">
					<button type="button" class="btn btn-info">Post Comment</button>				
				</div>
			 </form>
			 </div>-->
<!--=========================================	Comment Section =======================================-->		 
		<form method='post' action="" onsubmit="return post();">
  <textarea class="form-control" id="comment" placeholder="Write Your Comment Here....."></textarea>
  <br>
  <input type="hidden" id="username1" placeholder="Your Name" />
  <input type="hidden" id="username" placeholder="Your Name"  value ="<?php echo $username; ?>"/>

  <input type="hidden" id="proid1" placeholder="Your Name"  />
  <input type="hidden" id="proid" placeholder="Your Name" value="<?php echo $postid; ?>"  />
  <input class="btn btn-info Post__Comment" type="submit" value="Post Comment">
  </form>

  <div id="all_comments">
  <?php
    

    
  
    $comm = mysqli_query($con,"select * from post_comments where post_id = $postid order by post_time desc");
    while($row=mysqli_fetch_array($comm))
    {
	  $name=$row['name'];
	  $comment=$row['comment'];
      $time=$row['post_time'];
    ?>
	
	<div class="comment_div"> 
	  <p class="name">Posted By: <?php echo $name;?> <strong class="time"> <?php echo $time;?></strong></p>
      <p class="comment"><?php echo $comment;?></p>	

	</div>
  
    <?php
    }
    ?>
  </div>
<!--============================================ End commment section ===============================-->
			 </div>
			</div>
			<?php
			if(isset($_SERVER['HTTP_REFERER'])) { ?>
    

			   <!-- <a class="user-Previous-Page-btn" href="../index.php" style="color:blue"><i class="fa fa-caret-left" aria-hidden="true"></i> &nbsp; Previous Page</a> -->
			    <a class="user-Previous-Page-btn" href='<?php echo $_SERVER['HTTP_REFERER']; ?>' style="color:blue"><i class="fa fa-caret-left" aria-hidden="true"></i> &nbsp; Previous Page</a>
		<?php	}
			else
			{ ?>
			    
			    <a class="user-Previous-Page-btn" href="../index.php" style="color:blue"><i class="fa fa-caret-left" aria-hidden="true"></i> &nbsp; Previous Page</a>
			    
	<?php		}

			?>
			
			
		</div>
	</section>
	
	
	
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
	<script src="../js/custom.js"></script> 
	<script src="../js/global.js"></script>
	<!--<script>$('html,body').animate({scrollTop: document.body.scrollHeight},"fast");</script>-->
  </body>
</html>
<!--===============================Comment section===================-->
<script type="text/javascript">
function post()
{
  var comment = document.getElementById("comment").value;
  var name = document.getElementById("username").value;
  
  var proid = document.getElementById("proid").value;
 // alert(proid);
  if(comment && name && proid)
  {
    $.ajax
    ({
      type: 'post',
      url: 'post_comments.php',
      data: 
      {
         user_comm:comment,
	     user_name:name,
	     pro_id:proid,
      },
      success: function (response) 
      {
	    document.getElementById("all_comments").innerHTML=response+document.getElementById("all_comments").innerHTML;
	    document.getElementById("comment").value="";
        document.getElementById("username1").value="";
        document.getElementById("proid1").value="";
        
  
      }
    });
  }
  
  return false;
}
</script>
<!--=================================End comment Section===================-->