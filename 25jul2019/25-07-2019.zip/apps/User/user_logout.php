<?php

//logout.php
include('../connect.php');
session_start();

 $uid = $_SESSION['userid'];
 $query = "update user_addfriend set user_status ='offline' where addfriend_id = '$uid'";
$result = mysqli_query($con,$query);
$qry = "update user_signup set user_status = 'offline' where user_id = '$uid' ";
$result = mysqli_query($con,$qry);
session_destroy();

$cookie_email = "email";
$cookie_valueemail = $useremail;
$cookie_password = "password";
$cookie_valuepass = $userpassword;
		
setcookie($cookie_email, "",time() - 3600, "/");
setcookie($cookie_password, "",time() - 3600, "/"); 

?>
<script>
	window.location.href="user-sign-in.php";
	</script>
<?php        
//header('location:user-sign-in.php');

?>