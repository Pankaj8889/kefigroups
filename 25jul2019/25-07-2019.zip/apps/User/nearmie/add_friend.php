<?php
include('../../connect.php');
include('../../config.php');
session_start();
//echo "eded";
if(!($_SESSION['userid']))
{ ?><script>  //window.location.href="user-sign-in.php"; 

    window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

  </script><?php
  //header('location:user-sign-in.php');
}
$uid = $_SESSION['userid'];
/*if (empty($_POST['term']))
{
 echo $value = $_SESSION['value'];  
}
else{
if(isset($_POST['search']))
{
echo $value= $_POST['term'];
$value1 = rtrim($value,"m");
$_SESSION['value'] = $value;
}
}*/
//echo $value12 = $_POST['term'];
//$_SESSION['value'] = $value;
//$value2= $_POST['term'];
//echo $value = $_SESSION['value12'];
//unset($_SESSION['value']);

$value = $_GET['id'];

$queryfav = "select * from user_addfriend where user_id= $uid";
$resultfav = mysqli_query($con,$queryfav);

$fav_array = array();

while($rowfav = mysqli_fetch_assoc($resultfav))
{
    
    $fav_array[] = $rowfav['addfriend_id'];
}
$querylatitude = "select * from user_signup where user_id = '$uid'";
$resultlatitude = mysqli_query($con,$querylatitude);
$rowlatitude = mysqli_fetch_array($resultlatitude);
//echo "aa";
$lat1 = $rowlatitude['latitude'];
$lng1 = $rowlatitude['longitude'];

?>
<input type = text id="lat1" value= "<?php echo $lat ;?>" hidden/>
<input type = text id="long1" value= "<?php echo $long ;?>" hidden/>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <?php
    if($rowusertype['user_type'] == 'user')
    {?>
   
   <?php 
   }
   else
   {?>
   <?php
   }?>
     <title>Friends</title>
  </head>
  <?php include('../../header.php'); ?>
<body>
           <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="search.php">Distance  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Friends</li>
                          
                        </ul>
                </div>
                   
               </div>
           </div>
       </div>
    
        <div class="user-watchmie-main-section_2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                <form method="post" action="">
                    
                <?php
               /*=======================================================fetch all users who are registered=========================*/
                    $queryuser = "select * from user_signup ";
                    $resultuser = mysqli_query($con,$queryuser);

                while($rowuser = mysqli_fetch_array($resultuser))
                {					
					
                    /*========================================discard value which are in favourite=======================*/
                    if (!in_array($rowuser['user_id'], $fav_array))
                    {					

                       /*=================fetch user's latitude and longitude================*/
                       $lat2 = $rowuser['latitude'];
                      $lng2 = $rowuser['longitude'];
                      /*=======================convert logitude and latitude into distance(meter)======================*/
                       $earthRadius = 3958.75;

                      $dLat = deg2rad($lat2-$lat1);
                      $dLng = deg2rad($lng2-$lng1);
                      $a = sin($dLat/2) * sin($dLat/2) +
                      cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
                      sin($dLng/2) * sin($dLng/2);
                      $c = 2 * atan2(sqrt($a), sqrt(1-$a));
                      $dist = $earthRadius * $c;
                      // from miles
                      $meterConversion = 1609;
                      $geopointDistance1 = $dist * $meterConversion;
                      $geopointDistance = round($geopointDistance1);


                    //$distance = $geopointDistance."m";
                    /*==========================End=========================================*/
    
                        
                     /* ========================================  discard session id from registered user===================*/ 
                        if($rowuser['user_id'] != $uid)
                        {
                          // echo "<br/>".$row['user_id']; 
                    /*=======================================================only select distance display user==============*/
                    if($value <= 500000)
                    { //check range(value) less than 300

                    if($geopointDistance <= $value)
                    {
                        //echo $value;
                    /*====================================select user type because display checkbox on usertype=====================*/
                     if($rowuser['user_type'] == 'user')
                     {
        //$variable = "<script>document.write(cd)</script>"; //I want above javascript variable 'a' value to be store here
					
                    $id = $rowuser['user_id'];
                    $queryimage = "select * from users_meta where user_id = $id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $id)
                    {
                    $image = $rowimage['users_image'];
                   ?>
                   <div class="user-friends-list">
                    <div class="user-friends-pick"><span><a href = 'alluser_profile.php?id=<?php echo $rowuser['user_id'];?>&&sess_id=<?php echo $uid;?>'><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></a></span></div>
                    <!--<div class="user-friends-pick"><span><a href = 'alluser_profile.php?id=<?php echo $rowuser['user_id'];?>&&sess_id=<?php echo $uid;?>'><img src ='<?php echo "https://".$baseurl."imagesupload/$image"; ?>' /></a></span></div>-->
                     <div class="user-friends-list-title-hero">
                      <input type="checkbox" name="chk" id="chk_<?php echo $rowuser['user_id'] ;?>" value ="<?php echo $rowuser['user_id'] ;?>">Add Friend
                      <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                       <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                       <span><?php echo $geopointDistance; ?>m</span>
                       </div>
                   </div>
                <?php 
                        
                    }
                else
                {
                ?>
                  <div class="user-friends-list">
                       <div class="user-friends-pick"><span><a href = 'alluser_profile.php?id=<?php echo $rowuser['user_id'];?>&&sess_id=<?php echo $uid;?>'><img src="../../images/man.png" /></a></span></div>
                         <div class="user-friends-list-title-hero">
                             <input type="checkbox" name="chk" id="chk_<?php echo $rowuser['user_id'] ;?>" value ="<?php echo $rowuser['user_id'] ;?>">Add Friend
                             <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                         <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                         <span><?php echo $geopointDistance; ?>m</span>
                         
                        </div>
                  </div>
                
                <?php
                }//else part
                }// End select user type
                /*====================================select merchant under range============================*/
                else
                {
                    $id = $rowuser['user_id'];
                    $category =  $rowuser['user_category'];
                    $queryimage = "select * from users_meta where user_id = $id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $id)
                    {
                    $image = $rowimage['users_image'];
                   ?>
                   <div class="user-friends-list">
                     <div class="user-friends-pick"><span><a href='merchant_product.php?id=<?php echo $id ;?>&&category=<?php echo $category; ?>&&range=<?php echo $value; ?>&&sess_id=<?php echo $uid;?>'><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></a></span></div>
                    <!--<div class="user-friends-pick"><span><a href='merchant_product.php?id=<?php echo $id ;?>&&category=<?php echo $category; ?>&&range=<?php echo $value; ?>&&sess_id=<?php echo $uid;?>'><img src ='<?php echo "https://".$baseurl."imagesupload/$image"; ?>' /></a></span></div>-->
                     <div class="user-friends-list-title-hero">
                     <!-- <input type="checkbox" name="chk" id="chk_<?php //echo $row['user_id'] ;?>" value ="<?php //echo $row['user_id'] ;?>">Add Friend
                      <input type="hidden" name="uid" id="uid" value ="<?php //echo $uid; ?>" /><br/>-->
                       <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                       <span><?php echo $geopointDistance; ?>m</span>
                       <!-- <span><?php// echo $row['user_category']; ?></span>-->
                       </div>
                   </div>
                <?php 
                        
                    }
                else
                {
                ?>
                  <div class="user-friends-list">
                       <div class="user-friends-pick"><span><a href='merchant_product.php?id=<?php echo $id ;?>&&category=<?php echo $category; ?>&&range=<?php echo $value; ?>&&sess_id=<?php echo $uid;?>'><img src="../../images/man.png" /></a></span></div>
                         <div class="user-friends-list-title-hero">
                             <!--<input type="checkbox" name="chk" id="chk_<?php //echo $row['user_id'] ;?>" value ="<?php //echo $row['user_id'] ;?>">Add Friend
                             <input type="hidden" name="uid" id="uid" value ="<?php //echo $uid; ?>" /><br/>-->
                         <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                         <span><?php echo $geopointDistance; ?>m</span>
                        <!-- <span><?php // echo $row['user_category']; ?></span>-->
                        </div>
                  </div>
                
                <?php
                }//else part
                }//End merchant type
               
                }//end distance display user
            }//end under 300            
            
            else //else part of range if greater than range
            {
            if($geopointDistance >= 500001)
               {
                    /*====================================select user type because display checkbox on usertype=====================*/
                     if($rowuser['user_type'] == 'user')
                     {
        //$variable = "<script>document.write(cd)</script>"; //I want above javascript variable 'a' value to be store here
    
                    $id = $rowuser['user_id'];
                    $queryimage = "select * from users_meta where user_id = $id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $id)
                    {
                    $image = $rowimage['users_image'];
                   ?>
                   <div class="user-friends-list">
                    <div class="user-friends-pick"><span><a href = 'alluser_profile.php?id=<?php echo $rowuser['user_id']; ?>&&sess_id=<?php echo $uid;?>'><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></a></span></div>
                    <!--<div class="user-friends-pick"><span><a href = 'alluser_profile.php?id=<?php echo $rowuser['user_id']; ?>&&sess_id=<?php echo $uid;?>'><img src ='<?php echo "https://".$baseurl."imagesupload/$image"; ?>' /></a></span></div>-->
                     <div class="user-friends-list-title-hero">
                      <input type="checkbox" name="chk" id="chk_<?php echo $rowuser['user_id'] ;?>" value ="<?php echo $rowuser['user_id'] ;?>">Add Friend
                      <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                       <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                       <span><?php echo $geopointDistance; ?>m</span>
                       </div>
                   </div>
                <?php 
                        
                    }
                else
                {
                ?>
                  <div class="user-friends-list">
                       <div class="user-friends-pick"><span><a href = 'alluser_profile.php?id=<?php echo $rowuser['user_id']; ?>&&sess_id=<?php echo $uid;?>'><img src="../../images/man.png" /></a></span></div>
                         <div class="user-friends-list-title-hero">
                             <input type="checkbox" name="chk" id="chk_<?php echo $rowuser['user_id'] ;?>" value ="<?php echo $rowuser['user_id'] ;?>">Add Friend
                             <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                         <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                         <span><?php echo $geopointDistance; ?>m</span>
                         
                        </div>
                  </div>
                
                <?php
                }//else part
                }// End select user type
                /*====================================select merchant under range============================*/
                else
                {
                    $id = $rowuser['user_id'];
                    $category =  $row['user_category'];
                    $queryimage = "select * from users_meta where user_id = $id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $id)
                    {
                    $image = $rowimage['users_image'];
                   ?>
                   <div class="user-friends-list">
                     <div class="user-friends-pick"><span><a href='merchant_product.php?id=<?php echo $id ;?>&&category=<?php echo $category; ?>&&range=<?php echo $value; ?>&&sess_id=<?php echo $uid;?>'><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></a></span></div>
                    <!--<div class="user-friends-pick"><span><a href='merchant_product.php?id=<?php echo $id ;?>&&category=<?php echo $category; ?>&&range=<?php echo $value; ?>&&sess_id=<?php echo $uid;?>'><img src ='<?php echo "https://'".$baseurl."'imagesupload/$image"; ?>' /></a></span></div>
                     <div class="user-friends-list-title-hero">-->
                     <!-- <input type="checkbox" name="chk" id="chk_<?php //echo $row['user_id'] ;?>" value ="<?php //echo $row['user_id'] ;?>">Add Friend
                      <input type="hidden" name="uid" id="uid" value ="<?php //echo $uid; ?>" /><br/>-->
                       <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                       <span><?php echo $geopointDistance; ?>m</span><br/>
                       <!-- <span><?php// echo $row['user_category']; ?></span>-->
                       </div>
                   </div>
                <?php 
                        
                    }
                else
                {
                ?>
                  <div class="user-friends-list">
                       <div class="user-friends-pick"><span><a href='merchant_product.php?id=<?php echo $id ;?>&&category=<?php echo $category; ?>&&range=<?php echo $value; ?>&&sess_id=<?php echo $uid;?>'><img src="../../images/man.png" /></a></span></div>
                         <div class="user-friends-list-title-hero">
                             <!--<input type="checkbox" name="chk" id="chk_<?php //echo $row['user_id'] ;?>" value ="<?php //echo $row['user_id'] ;?>">Add Friend
                             <input type="hidden" name="uid" id="uid" value ="<?php //echo $uid; ?>" /><br/>-->
                         <span><?php echo $rowuser['user_username'];?>(<?php echo $rowuser['user_type'];?>)</span>
                         <span><?php echo $geopointDistance; ?>m</span><br/>
                         <!--<span><?php// echo $row['user_category']; ?></span>-->
                        </div>
                  </div>
                
                <?php
                }//else part
                }//End merchant type
               
                }//end distance display user
            
        }  //end range else part
            
         
                }
                
                }
                }
               // }
                /*=====================================End==================================*/
                ?>
                
                <!--<div class="submit-info-btn"><input class="btn btn-info user-Previous-Page-btn" type="submit" name="submit" value="Submit"/></div>
                </form>-->
                
                   
                       </div>
                    </div> 
                </div> 
        </div> 
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
  <footer>
    <?php include('../../footer.php'); ?>
  </footer>
</html>
<!--===============================Check box value send through ajax in user_favourite table==========================-->
<script>
        $(document).on("change", "input[name='chk']", function () {
            var checkbox = $(this);
            var checked = checkbox.prop('checked');
            
        
            var favid = $(this).attr('value');
            var uid = document.getElementById('uid').value;
            //alert(uid);
          //alert(favid);
            $.ajax({
                url:"ajax_useraddfriend.php",
                type: 'post',
                data: {
                    //action: 'checkbox-select', 
                    //id: checkbox.data('contact_avl'),
                    favid: favid,
                    uid: uid,
                    checked:checked
                      },
                success: function(data) {
                    window.location.href="";
                    //alert(data);
                   // alert("yes");
                },
                error: function(data) {
                   // alert(data);
                    // Revert
                    checkbox.attr('checked', !checked);
                }
            });
        });
    </script>
<!--===============================End ajax==========================================================-->

                    

                  