<?php
include('../../connect.php');
include('../../config.php');
$catname = $_GET['category'];
//echo $catname;
$query = "select * from user_signup where user_category ='$catname'";
//echo "select * from user_signup where user_category ='$catname'";
$result = mysqli_query($con,$query);
//$rowcat = mysqli_fetch_array($result);

/*while ($rowcat = mysqli_fetch_array($result))
{
    echo $rowcat['user_id'];
}
   ?>
   <a href="merchant_product.php?id=<?php echo $rowcat['user_id'];?>"><?php echo $rowcat['user_username'];?></a><br/>

    <?php
    
}
$queryimage = "select * from user_signup where user_id = $";
	$resultusertype = mysqli_query($con,$queryimage);
	$rowusertype = mysqli_fetch_array($resultusertype);*/

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>Merchant</title>
  </head>
  <?php include('../../header.php'); ?>
   <section id="Product__detail__page Merchant">
    <div class="container">
        <div class="row">
		<div class="col-md-12">
		    <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="merchant_categories.php">Categories  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Merchants</li>
                          
                        </ul>
                </div>
                <div class="Category-title">
                        <h3>Merchant</h3></div></div>
                        <?php
                         while ($rowcat = mysqli_fetch_array($result))
                         {
                           $uuid=  $rowcat['user_id'];
                           $queryimage = "select * from users_meta where user_id = '$uuid'";
                           $resultimage = mysqli_query($con,$queryimage);
                           $rowimage = mysqli_fetch_array($resultimage);
	                       if($rowimage['user_id']==$uuid)
                            {
                             ?> 
                               
		                        <div class="col-md-3 col-sm-6">
							    <div class="Same-Design">
                               <div class="img-product">
                                   <a href='product_detail.php?id=<?php echo $uuid ;?>&category=<?php echo $catname; ?>'><img src="<?php echo  "https://".$baseurl."imagesupload/". $rowimage['users_image'];?>"></div></a>
                        <?php
                               }
                            else
                            {
                             ?>
                              <div class="col-md-3 col-sm-6">
							  <div class="Same-Design">
                              <div class="img-product"><a href='product_detail.php?id=<?php echo $uuid ;?>&category=<?php echo $catname; ?>'><img src="../../images/man.png"></div></a>
                                 <?php 
                               }
                                ?>
                    <div class="entry-title">
                        <h1><a href='product_detail.php?id=<?php echo $uuid ;?>&category=<?php echo $catname; ?>'><?php echo $rowcat['user_username'];?></h1></a> </div>
                    <div class="description">
                        <!--<p>Lorem Ipsum is simply dummy text of the printing and </p>-->
                    </div>
          
                   <!-- <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>-->
                </div>
            </div>
            <?php
                }
                ?>

           <!-- <div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="images/man.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                           <!--<p>Lorem Ipsum is simply dummy text of the printing </p>-->
                    <!--</div>
              
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>-->

            <!--<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="images/man.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                           <!--<p>Lorem Ipsum is simply dummy text of the printing </p>-->
                    <!--</div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>-->
			

			
					<!--	<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="images/man.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                           <!--<p>Lorem Ipsum is simply dummy text of the printing </p>-->
                    <!--</div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>-->
			
			
					<!--	<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="images/man.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                        <!--<p>Lorem Ipsum is simply dummy text of the printing </p>-->
                    <!--</div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>-->
			
			
					<!--	<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="images/man.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                        <!--<p>Lorem Ipsum is simply dummy text of the printing </p>-->
                    <!--</div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>-->






			
			</div>
			<!--<div class="row">
			<div class="col-md-12">
			<div class="pagination-rol mb-5">
                    <ul class="nav justify-content-end">
                        <li class="nav-item"><a href="JavaScript:Void(0);">Prev</a></li>
                        <li class="nav-item active"> <a href="JavaScript:Void(0);">1</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">2</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">3</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">4</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">Next</a></li>

                    </ul>
                </div>
                </div>
			</div>-->
        </div>
    </div>

</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
</html>
