<?php
include('../../config.php');
include('../../connect.php');
session_start();
/*
if(!($_SESSION['userid']))
{ ?><script>  //window.location.href="user-sign-in.php"; 

    window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

  </script><?php
  //header('location:user-sign-in.php');
}
*/
 $uid = $_SESSION['userid'];

 
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>profile Seen</title>
  </head>
  <?php include('../../header.php'); ?>
   <body>
       
       <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Profile Viewer</li>
                          
                        </ul>
                </div>
                   
               </div>
           </div>
       </div>
<div class="user-watchmie-main-section">
    <div class="user-post-section-1">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                  
                    <div class="header-section-watchmie-info">
                     <ul class="nav">
                         <?php
                          $qry = "select * from user_profile_seen where to_id = '$uid'";
            							$result = mysqli_query($con,$qry);
                          $count = mysqli_num_rows($result);
                          if($count >=1){
            							while($resultrow= mysqli_fetch_assoc($result))
            							{
            								$id= $resultrow['from_id'];

            								$query = "select * from user_signup where user_id = $id";
            								$queryresult= mysqli_query($con,$query);
            								$row= mysqli_fetch_assoc($queryresult);
            								$username = $row['user_username'];
            								$queryforpic = "select * from users_meta where user_id= '$id'";
            								$resultforpic= mysqli_query($con,$queryforpic);
            								$rowforpic = mysqli_fetch_assoc($resultforpic);
            								$pic = $rowforpic['users_image'];
            								if($pic)
            								{
            									?>

          									<li class="nav-item">
                                          <a href="javascript:void(0);"><img src ="data:image/png;base64,<?php echo base64_encode($pic); ?>" /></a><br/>
                                           <span><?php echo $username; ?></span>
                                           </li>

                                 <?php

                  								}
                  								else
                  								{
                  									?>

                  									<li class="nav-item">
                  		                                <a href="javascript:void(0);"><img src="../../images/man.png"></a><br/>
                  		                                <span><?php echo $username; ?></span>
                  		                        
                  		                            </li> 


                  									<?php
                  								}


                  							}
                              }else
                              {
                                echo "Profile seen list is empty";
                              }

                  							?>
                  							</ul>
                                      </div> 
                    
<!--=================================End online user==========================-->
                    <!--===========================Post==============================================-->
                 
                        
                     
                        
                    
  <!--===================================End section post====================================================-->                

                    
                    <!--<div class="user-Friend list-section">-->
                        <!--<ul class="nav">
                            <li>
                               <!-- <div class="dropdown">
                                <button onclick="myFunction()" class="dropbtn-btn-click">Friend list <i class="fa fa-caret-down" aria-hidden="true"></i></button>
                                  <div id="myDropdown" class="dropdown-content">
                                    <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
                                    <a href="#">Apple</a>
                                    <a href="#">Ken</a>
                                     <a href="#">Apple</a>
                                    <a href="#">Ken</a>
                                   
                                  </div>
                                  
                                </div>-->
                                <!--<a href="user_friends.php">Friends</a>
                            </li>
                            
                             <li>
                               <a href="user_favourite.php">Favourite</a>
                            </li>
                            
                             <li>
                              <a href="../../index.php">Home</a>
                            </li>
                        </ul>
                        
                    <!--</div>-->

                </div>
            </div>
        </div>
    </div>
</div>
       
       
       
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
	<script>
</script>
  </body>
  <footer>
    <?php include('../../footer.php'); ?>
  </footer>
</html>
