<?php
include('../../config.php');
session_start();
?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>Distance</title>
  </head>
  <?php 
      
      include('../../header.php');
       
       //echo $_SESSION['userid'];
       //die("ffjhjf");
      /*
      if(!($_SESSION['userid']))
      { ?><script>  //window.location.href="user-sign-in.php"; 

          window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

        </script><?php
        //header('location:user-sign-in.php');
      }
      */
    ?>
  
   <section id="product_bad">
    <div class="container">
		<div class="pagination-form-header"> 
			<!--<ul class="breadcrumb">
			  <li class="active">
			  <a href="../../index.php">Profile  &nbsp;&nbsp;/ &nbsp;&nbsp;</a></li>
			  <li>Distance</li>			  
			</ul>-->
		</div>
        <div class="row">
            <div class="col-md-12">

                
                <div class="Category-box">
                    
                    
                    <div class="Category-title">
                    <!--<a href = "profile_seen.php"><button type = "button">click here</button></a><p> to see who visited your profile</p>-->
                        <h3>Select Distance</h3></div>
                        <!--<div class = "slider">-->
    
                    <!--<ul class="nav distence">
                        <li>
                            <a href = "add_friend.php?id=<?php echo "50m"; ?>"><button type = "button">50m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "100m"; ?>"><button type = "button">100m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "150m"; ?>"><button type = "button">150m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "200m"; ?>"><button type = "button">200m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "250m"; ?>"><button type = "button">250m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "300m"; ?>"><button type = "button">300m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "301m"; ?>"><button type = "button">above 300m</button></a>
                        </li>
                    </ul>-->
                    <ul class="nav distence">
                        <li>
                            <a href = "add_friend.php?id=<?php echo "1m"; ?>"><button type = "button">1m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "50m"; ?>"><button type = "button">50m</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "1000m"; ?>"><button type = "button">1km</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "500000m"; ?>"><button type = "button">500km</button></a>
                        </li>
                        <li>
                            <a href = "add_friend.php?id=<?php echo "500001m"; ?>"><button type = "button">above 500km</button></a>
                        </li>
                        
                    </ul>
                    <!--</div>-->
                   <!-- <form action="add_friend.php" method="post">
                    <div class="input-group mb-3 mt-5 search_bar">
								<input type="text" class="form-control" placeholder="Search..." name="term">
								<div class="input-group-append">
							    <button	 type="submit" name="search"><span class="input-group-text" id="basic-addon2"><i class="fa fa-search" aria-hidden="true"></i></button>
</span>
								</div>
							</div>	
							</form>-->
                    
                </div>

            </div>
        </div>
    </div>
</section>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
<div class="user-Friend list-section">
                        <ul class="nav">
                            <li>
                              
                                <a href="https://kefigroups.com/apps/User/watchmie/user_friends.php">Friends</a>
                            </li>

                            <li>
                              <a href="https://kefigroups.com/apps/index.php">Home</a>
                            </li>
                            
                             <li>
                               <a href="https://kefigroups.com/apps/User/watchmie/user_favourite.php">Favourite</a>
                            </li>                            
              
                        </ul>
                        
                    </div>
<footer>
 <?php include('../../footer.php');  ?>
 </footer>
</html>

<!--<script>
  $(document).ready(function () {
  
    $("#slider").scrollLeft();
});
</script>
<style>
  .slider{
    overflow: auto;
    white-space: nowrap;    
    width: 600px;
  }
</style>-->