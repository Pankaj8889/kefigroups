<?php
include "qrlib.php";
$pid = $_GET['id'];

// create a QR Code with this text and display it
  
// QRcode::png(1);
QRcode::png($pid);

 ?>
 

