
<?php
$width = 150;
$height = 150;
$url1= 'This is Qr code';
$url = urlencode($url1);
//$image = QRcode::png("My First QR Code");
$image  = 'http://chart.apis.google.com/chart?chs='.$width.'x'.$height.'&cht=qr&chl='.$url;
$file = file_get_contents($image);
    header("Content-type: application/octet-stream");
    header("Content-Disposition: attachment; filename=qrcode.png");
    header("Cache-Control: public");
    header("Content-length: " . strlen($file)); // tells file size
    header("Pragma: no-cache");
    echo $file;
    ?>