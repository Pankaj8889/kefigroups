<?php
/*=================Start Comments Section=====================*/
/*if(!($_SESSION['userid']))
	{ 
		header('location:user-sign-in.php');
	}*/
$url= $_SERVER['REQUEST_URI'];
//echo $url."<br/>";
$var = explode('/',$url);
//echo $var[3];
$var2 = explode('?',$var[3]);
$var3 = explode('=',$var2[1]);
$pro_idd= $var3[1];
//echo $pro_idd;
session_start();
include('../../config.php');
//include('../product_comments/connect1.php');
//require_once '../product_comments/display_com.php';
/*=======================End Comment Section================*/
include('../../connect.php');
$id = $_GET['id'];
$range = $_GET['range'];
$category = $_GET['category'];
$merchantid = $_GET['merchantid'];
//$category = $_GET['category'];
$uid = $_SESSION['userid'];

$username = $_SESSION['user_username'];
//echo $username;
$querypro = "select * from merchant_products where  product_id = '$id'";
//echo "select * from merchant_products where product_id = $pid";
$resultpro = mysqli_query($con,$querypro);
if($resultpro)

//$rowpro = mysqli_fetch_array($resultpro);
//$mid = $rowpro['merchant_id'];
//$pid = $rowpro[]

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <!-- <link rel="stylesheet" href="../css/stylecomment.css">-->
    <link rel="stylesheet" href="../../css/responsive.css">
   
    <title>Product</title>
  </head>
  <?php include('../../header.php'); ?>
  
  
   <section id="view--product">
    <div class="container">
        <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="search.php">Distance  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="add_friend.php?id=<?php echo $range;?>">Friends  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="merchant_product.php?id=<?php echo $merchantid; ?>&&category=<?php echo $category;?>&&range=<?php echo $range;?>">Products  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Product Detail</li>
                        </ul>
                </div>
        <?php
		     while($rowpr = mysqli_fetch_array($resultpro))
		     {
		     ?>
        <div class="row">
		
		
		<div class="col-md-4">
		<div class="product-img-hd">
		    <?php
		   
		         $pid = $rowpr['product_id'];
		        //echo $pid;
		         $mid = $rowpr['merchant_id'];
		       
		         //echo $mid;
		    ?>
		<img class="" src="<?php echo "https://".$baseurl."productimages/". $rowpr['product_image']; ?>"></a>
		</div>
		</div>
		
		<div class="col-md-8">
		<div class="product_information_block">
		<h2><?php echo $rowpr['product_title']; ?></h2>
		<p><?php echo $rowpr['product_description'];?> </p>
		
		<div class="Price mt-3"><strong>Rs. <?php echo $rowpr['product_price']; ?></strong></div>
		 
          
		<div class="Click-btn">
          <a href ="qr.php?id=<?php echo $pid.'-'.$uid;?>&merchantid=<?php echo $mid;?>&userid=<?php echo $uid;?>"><button type="button"  id="download_btn" class="btn btn-primary Click_btn-1">Download QR Code</button></a>
          <?php //header("Location:https://kefii-dev-pankajsaini8889.c9users.io/Kefi/nearmie/product_detail.php?id=$pid"); ?>

          <a href = "../nearmie/phpqrcode-master/viewqr.php?id=<?php echo $pid.'-'.$uid;?>"><button type="button" class="btn btn-primary Click_btn-2">View QR Code</button></a>
        </div>
		
		</div>
		</div>
		
	

        
    </div>
 <!--=========================================Comment Section======================================-->   
  <br/><form method='post' action="" onsubmit="return post();">
  <textarea class="form-control space-1" id="comment" placeholder="Write Your Comment Here....."></textarea>

  <input type="hidden" id="username1" placeholder="Your Name" />
  <input type="hidden" id="username" placeholder="Your Name"  value ="<?php echo $username; ?>"/>
  
  <input type="hidden" id="proid1" placeholder="Your Name"  />
  <input type="hidden" id="proid" placeholder="Your Name" value="<?php echo $pid; ?>"  />
  <div class="Click-btn"><input class="btn btn-primary" type="submit" value="Post Comment"></div>
  </form>

  <div id="all_comments" class="user-post-show-b-d">
  <?php
    

    
  
    $comm = mysqli_query($con,"select * from comments where product_id = $pid order by post_time desc");
    while($row=mysqli_fetch_array($comm))
    {
	  $name=$row['name'];
	  $comment=$row['comment'];
      $time=$row['post_time'];
    ?>
	
	<div class="comment_div"> 
	  <p class="name">Posted By:<?php echo $name;?> <strong class="time"><?php echo $time;?></strong></p>
      <p class="comment"><?php echo $comment;?></p>	

	</div>
  
    <?php
    }
    ?>
  </div>
 <!--=======================================End Comment section==========================---->
		

   
    <?php
          }
          ?>
          </div>
</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
	<!--<script src="../js/global.js"></script>-->
  </body>
  <script>
  /*$('#download_btn').click(function(){
    window.location.href = 'https://kefii-dev-pankajsaini8889.c9users.io/Kefi/nearmie/product_detail.php?id=$pid';
    console()
});*/
</script>

<!--===============================Comment section===================-->
<script type="text/javascript">
function post()
{
  var comment = document.getElementById("comment").value;
  var name = document.getElementById("username").value;
  
  var proid = document.getElementById("proid").value;
 // alert(proid);
  if(comment && name && proid)
  {
    $.ajax
    ({
      type: 'post',
      url: 'product_comments.php',
      data: 
      {
         user_comm:comment,
	     user_name:name,
	     pro_id:proid,
      },
      success: function (response) 
      {
	    document.getElementById("all_comments").innerHTML=response+document.getElementById("all_comments").innerHTML;
	    document.getElementById("comment").value="";
        document.getElementById("username1").value="";
        document.getElementById("proid1").value="";
        
  
      }
    });
  }
  
  return false;
}
</script>
<!--=================================End comment Section===================-->
</html>
