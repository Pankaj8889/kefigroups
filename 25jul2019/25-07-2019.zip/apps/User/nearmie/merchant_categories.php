
<!--<link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/responsive.css">
 <a href="merchant_name.php?id=entertainment"><i class="fa fa-music"></i></a>
 <a href = "merchant_name.php?id=cutlery"><img src="images/icon4.png" width=50px height=50px></a>  
 <a href = "merchant_name.php?id=general"><img src="images/icon-4.jpg" width=50px height=50px></a> 
 <a href = "merchant_name.php?id=accommodation"><img src="images/icon-7.png" width=50px height=50px></a>
 <a href = "merchant_name.php?id=apparel"><img src="images/icon1.png" width=50px height=50px></a>
 <a href = "merchant_name.php?id=e-commerce"><img src="images/icon-6.png" width=50px height=50ox></a>-->
 
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title> Category</title>
  </head>
  <?php include('../../header.php');
       include('../../config.php');
    ?>
  
   <section id="product_bad">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Categories</li>
                          
                        </ul>
                </div>
                
                <div class="Category-box">
                    
                    
                    <div class="Category-title">
                        <h3>Select  Category</h3></div>

                    <ul class="nav">
                        <li>
                            <a href="merchant_name.php?category=entertainment"><img src="../../images/Entertainment.png">
                                <br> <span>Entertainment</span></a>
                        </li>
                        <li>
                            <a href="merchant_name.php?category=cutlery"><img src="../../images/icon4.png">
                                <br><span>Cutlery</span></a>
                        </li>
                        <li>
                            <a href="merchant_name.php?category=general"><img src="../../images/icon-4.jpg">
                                <br><span>General</span></a>
                        </li>
                        <li>
                            <a href="merchant_name.php?category=accommodation"><img src="../../images/icon-7.png">
                                <br><span>Accommodation</span>
                            </a>
                        </li>
                        <li>
                            <a href="merchant_name.php?category=apparel"><img src="../../images/icon1.png">
                                <br><span>Apparel</span></a>
                        </li>
                        <li>
                            <a href="merchant_name.php?category=e-commerce"><img src="../../images/icon-6.png">
                                <br><span>E-commerce</span></a>
                        </li>
                    </ul>
                    <a href="add_friend.php">User</a>
                </div>

            </div>
        </div>
    </div>

</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
</html>
