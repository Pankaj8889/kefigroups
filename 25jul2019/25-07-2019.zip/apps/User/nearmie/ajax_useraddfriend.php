<?php
include('../../connect.php');
include('../../config.php');

if(isset($_POST['favid']) && isset($_POST['uid']) && isset($_POST['checked']))
{
    $fav_id = $_POST['favid'];
    
    $uid_id = $_POST['uid'];
    echo $fav_id;
    
    $query = "insert into user_addfriend(user_id,addfriend_id) values('$uid_id','$fav_id')";
   // echo "insert into user_favourite(user_id,favourite_id) values('$uid_id','$fav_id')";
    $result = mysqli_query($con,$query);
    
}
?>