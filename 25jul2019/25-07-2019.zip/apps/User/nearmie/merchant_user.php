<?php
include('../../connect.php');
session_start();
$uid = $_SESSION['userid'];
if(isset($_POST['btnsubmit']))
{
$value= $_POST['carlist'];
echo $value;
$query = "select * from user_signup where user_id = '$uid'";
$result = mysqli_query($con,$query);
$row = mysqli_fetch_array($result);
echo $lat1 = $row['latitude'];
echo "<br/>".$lng1 = $row['longitude'];
$queryuser = "select * from user_signup";
$resultuser = mysqli_query($con,$queryuser);
while($rowuser = mysqli_fetch_array($resultuser))
{
   echo  $lat2 = $rowuser['latitude'];
   echo "<br/>". $lng2 = $rowuser['longitude'];
  
    $earthRadius = 3958.75;

    $dLat = deg2rad($lat2-$lat1);
    $dLng = deg2rad($lng2-$lng1);
    $a = sin($dLat/2) * sin($dLat/2) +
    cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
    sin($dLng/2) * sin($dLng/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    $dist = $earthRadius * $c;
                    // from miles
    $meterConversion = 1609;
    $geopointDistance1 = $dist * $meterConversion;
    $geopointDistance2 = round($geopointDistance1);
    echo "<br/>". $distance =$geopointDistance2."m"; 
                    
   if($distance > '50m')
   {
        $type = $row['user_type'];
        if ($type == 'user')
        {
            
            $queryfav = "select * from user_addfriend where user_id= $uid";
$resultfav = mysqli_query($con,$queryfav);

$fav_array = array();

while($rowfav = mysqli_fetch_assoc($resultfav)){
    
    $fav_array[] = $rowfav['addfriend_id'];
}?>
<div class="user-watchmie-main-section_2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                <form method="post" action="">
                    
                <?php
               /*=======================================================fetch all users who are registered=========================*/
                    $query = "select * from user_signup ";
                    $result = mysqli_query($con,$query);
                while($row = mysqli_fetch_array($result))
                {
                    /*========================================discard value which are in favourite=======================*/
                    if (!in_array($row['user_id'], $fav_array)){
                        if($row['user_id'] != $uid){
                    
                    
                    
                     
        //$variable = "<script>document.write(cd)</script>"; //I want above javascript variable 'a' value to be store here
    
                    $id = $row['user_id'];
                    $queryimage = "select * from users_meta where user_id = $id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $id)
                    {
                    $image = $rowimage['users_image'];
                   ?>
                   <div class="user-friends-list">
                    <div class="user-friends-pick"><span><img src ='<?php echo "https://$baseurl/Kefi/imagesupload/$image"; ?>' /></span></div>
                     <div class="user-friends-list-title-hero">
                      <input type="checkbox" name="chk" id="chk_<?php echo $row['user_id'] ;?>" value ="<?php echo $row['user_id'] ;?>">Add Friend
                      <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                       <span><?php echo $row['user_username'];?>(<?php echo $row['user_type'];?>)</span>
                      <span><?php echo $distance; ?></span>
                       </div>
                   </div>
                <?php 
                        
                    }
                else
                {
                ?>
                  <div class="user-friends-list">
                       <div class="user-friends-pick"><span><img src="../../images/man.png" /></span></div>
                         <div class="user-friends-list-title-hero">
                             <input type="checkbox" name="chk" id="chk_<?php echo $row['user_id'] ;?>" value ="<?php echo $row['user_id'] ;?>">Add Friend
                             <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                         <span><?php echo $row['user_username'];?>(<?php echo $row['user_type'];?>)</span>
                        <span><?php echo $distance; ?></span>
                        </div>
                  </div>
                
                <?php
                }    
                }
                }
                }
                /*=====================================End==================================*/
                ?>
                
                <!--<div class="submit-info-btn"><input class="btn btn-info user-Previous-Page-btn" type="submit" name="submit" value="Submit"/></div>
                </form>-->
                
                   
                       </div>
                    </div> 
                </div> 
        </div> 

            
    <?php
    }
        }
    }
}

?>
 <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  
<!--===============================Check box value send through ajax in user_favourite table==========================-->
<script>
        $(document).on("change", "input[name='chk']", function () {
            var checkbox = $(this);
            var checked = checkbox.prop('checked');
            
        
            var favid = $(this).attr('value');
            var uid = document.getElementById('uid').value;
            //alert(uid);
          //alert(favid);
            $.ajax({
                url:"ajax_useraddfriend.php",
                type: 'post',
                data: {
                    //action: 'checkbox-select', 
                    //id: checkbox.data('contact_avl'),
                    favid: favid,
                    uid: uid,
                    checked:checked
                      },
                success: function(data) {
                    window.location.href="";
                    //alert(data);
                   // alert("yes");
                },
                error: function(data) {
                   // alert(data);
                    // Revert
                    checkbox.attr('checked', !checked);
                }
            });
        });
    </script>