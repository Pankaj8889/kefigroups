<?php
$con=mysqli_connect("localhost","kefigrou_kefi","bU;CDy}x!(do","kefigrou_kefi");
if(!$con)
{
	die("Error while connecting db".mysqli_connect_error());
}
$pid = $_GET['id'];
$mid = $_GET['merchantid'];
$uid = $_GET['userid'];

$date ="barcode".date("YmdHis");

function forceDownloadQR($url, $width = 150, $height = 150) {
    $url    = urlencode($url);
    $image  = 'http://chart.apis.google.com/chart?chs='.$width.'x'.$height.'&cht=qr&chl='.$url;
    $file   =  file_get_contents($image);
   
    header("Content-type: application/octet-stream");
    header("Content-Disposition: attachment; filename=".date("YmdHis").".png");
    header("Cache-Control: public");
    header("Content-length: " . strlen($file)); // tells file size
    header("Pragma: no-cache");
    echo $file;
   
/* Make sure that code below does not get executed when we redirect. */
   // die;
}
$queryqr = "select * from product_qrcode where user_id = '$uid' && merchant_id = '$mid' && product_id = '$pid'";
$resultqr = mysqli_query($con,$queryqr);
$rowqr = mysqli_fetch_array($resultqr);
if($rowqr)   
{
    $queryup = "update product_qrcode SET qr_code = '$date' where user_id = '$uid' && merchant_id = '$mid' && product_id = '$pid' ";
    $resultup = mysqli_query($con,$queryup);
}
else
{
$query = "insert into product_qrcode(user_id,merchant_id,product_id,qr_code)values('$uid','$mid','$pid','$date')";
$result = mysqli_query($con,$query);
}
forceDownloadQR($pid);
 //header("Location:https://kefii-dev-pankajsaini8889.c9users.io/Kefi/nearmie/product_detail.php?id=$pid");
 //exit();
?>
