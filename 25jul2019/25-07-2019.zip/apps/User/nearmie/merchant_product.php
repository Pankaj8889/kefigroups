<?php
include('../../connect.php');
$id = $_GET['id'];
$category = $_GET['category'];
$range = $_GET['range'];


//echo "user id".$id = $_GET['id'];
$sess_id = $_GET['sess_id'];

  $selectqry = "select * from user_profile_seen where from_id = '$sess_id' && to_id = '$id'";
  $selectresult = mysqli_query($con,$selectqry);
  $count = mysqli_num_rows($selectresult);
  if($count< 1)
  {

    $qry = "insert into user_profile_seen (from_id,to_id) values ('$sess_id','$id ')";
    $result = mysqli_query($con,$qry);

  }



$query = "select * from merchant_products where merchant_id = '$id' && product_category = '$category'";
$result = mysqli_query($con,$query);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>Products</title>
  </head>
<?php include('../../header.php'); ?>
  
   <section id="Product__detail__page Product_pagE">
    <div class="container">
        	<div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li class="active"><a href="search.php">Distance  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li class="active"><a href="add_friend.php?id=<?php echo $range; ?>">Friends  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Products</li>
                          
                        </ul>
                </div><br/>
        <div class="row">
		<div class="col-md-12"> 
		<!--<div class="Category-title"><h3>products</h3></div>-->
	
		</div>
            <?php
            while($row = mysqli_fetch_array($result))
            {
                $pid = $row['product_id'];
                ?>
		    <div class="col-md-3 col-sm-6">
							
                <div class="Same-Design">
                    <div class="img-product"><a href="product_detail.php?id=<?php echo $pid; ?>&&range=<?php echo $range;?>&&category=<?php echo $category;?>&&merchantid=<?php echo $id; ?>"><img src="<?php echo "https://".$baseurl."productimages/". $row['product_image'];?>"></div></a>
                    <div class="entry-title">
                        <h1><?php echo $row['product_title'] ;?></h1> </div>
                    <div class="description">
                   <p><?php echo substr($row['product_description'],0,90);?>... </p>
				   
                    </div>
          <div class="Price mt-3"><strong>Rs. <?php echo $row['product_price'];?></strong></div>
         
                    <div class="Click-btn">
                        <a href="product_detail.php?id=<?php echo $pid; ?>&&range=<?php echo $range;?>&&category=<?php echo $category;?>&&merchantid=<?php echo $id; ?>"><button type="button" class="btn btn-primary">View Detail</button><a/>
                    </div>
                </div>
            </div>
<?php 
                
            }
?>
            <!--<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="../images/image-4.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                   <p>Lorem Ipsum is simply dummy text of the printing </p>
                    </div>
                <div class="Price mt-3"><strong>$50.60</strong></div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="../images/image-4.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                      <p>Lorem Ipsum is simply dummy text of the printing </p>
                    </div>
					  <div class="Price mt-3"><strong>$50.60</strong></div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>
			

			
						<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="../images/image-4.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                         <p>Lorem Ipsum is simply dummy text of the printing </p>
                    </div>
					  <div class="Price mt-3"><strong>$50.60</strong></div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>
			
			
						<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="../images/image-4.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                    <p>Lorem Ipsum is simply dummy text of the printing </p>
                    </div>
					  <div class="Price mt-3"><strong>$50.60</strong></div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>
			
			
						<div class="col-md-3 col-sm-6">
                <div class="Same-Design">
                    <div class="img-product"><img src="../images/image-4.png"></div>
                    <div class="entry-title">
                        <h1>Lorem Ipsum is</h1> </div>
                    <div class="description">
                      <p>Lorem Ipsum is simply dummy text of the printing </p>
                    </div>
					  <div class="Price mt-3"><strong>$50.60</strong></div>
                    <div class="Click-btn">
                        <button type="button" class="btn btn-primary">ADD TO CART</button>
                    </div>
                </div>
            </div>-->






			
			</div>
			<!--<div class="row">
			<div class="col-md-12">
			<div class="pagination-rol mb-5">
                    <ul class="nav justify-content-end">
                        <li class="nav-item"><a href="JavaScript:Void(0);">Prev</a></li>
                        <li class="nav-item active"> <a href="JavaScript:Void(0);">1</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">2</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">3</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">4</a></li>
                        <li class="nav-item"><a href="JavaScript:Void(0);">Next</a></li>

                    </ul>
                </div>
                </div>
			</div>-->
        </div>
    </div>

</section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
</html>
