<?php
include('../../connect.php');
echo $query = "SELECT * FROM post WHERE DATEDIFF(date('Y-m-d h:i:sa'),date) <= 3";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_array($result))
{
echo "<br/>".$row['date'];
}
?>