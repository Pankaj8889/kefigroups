<?php
include('../../connect.php');
//echo $query = "SELECT * from post WHERE date > (NOW() - INTERVAL 24 HOUR)";

$query = "SELECT * 
FROM post
WHERE post.date > DATE_SUB(now(), INTERVAL 1 DAY)";

$result = mysqli_query($con,$query);
while($row = mysqli_fetch_array($result))
{
echo "<br/>".$row['date'];
}
?>