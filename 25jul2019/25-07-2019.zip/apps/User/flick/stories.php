<?php
include('../../connect.php');
include('../../config.php');
session_start();

if(!($_SESSION['userid']))
{ ?><script>  //window.location.href="user-sign-in.php"; 

    window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

  </script><?php
  //header('location:user-sign-in.php');
}


$uid = $_SESSION['userid'];
$query = "select * from user_addfriend where user_id='$uid'";
$result = mysqli_query($con,$query);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>Status</title>
  </head>
  <?php include('../../header.php'); ?>
   <body>
		<div class="container">
			<div class="pagination-form-header"> 
				<ul class="breadcrumb">
					<li class="active"><a href="../../index.php">Profile &nbsp;&nbsp; &nbsp;&nbsp;</a></li>
					<li>Stories</li>
				</ul>
			</div>
		</div>
		
      <div class="user-watchmie-main-section">
        <div class="user-post-section-1">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
                <div class="header-section-watchmie-info">
                   <ul class="nav">
                     <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
                      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
                         <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

                    <?php
                       while($row = mysqli_fetch_array($result))
                        {
                       
                            $idd = $row['addfriend_id'];
                            
                           /*================================select addfriend post in 24 hours last 1 video(select user's)=========================*/
                            $querypost = "select * from post where user_id = '$idd' && date > DATE_SUB(NOW(), INTERVAL 2 DAY) Order by post_id desc limit 0,1 "; 
                            $resultpost = mysqli_query($con,$querypost);
                           // $rowpost1 = mysqli_fetch_array($resultpost);
							foreach($resultpost as $rowpost){
			   
                            if (!empty($rowpost['post_media']))
      	                    {
                               $var1 = $rowpost['post_media'];
	                            $var2 = explode(".",$var1);
								
	                            if($var2[1] == 'webm') //check video
	                            {
	                                $qry = "select * from user_signup where user_id='$idd' ";
	                                $res = mysqli_query($con,$qry);
	                                $result1 = mysqli_fetch_array($res);
	                                $name = $result1["user_username"];
	                                $idd1 = $result1['user_id'];
	                                $queryimage1 = "select * from users_meta where user_id = '$idd1'";
                                    $resultimage1 = mysqli_query($con,$queryimage1);
                                    $rowimage1 = mysqli_fetch_array($resultimage1);
                                    
                             ?>
                               <li class="nav-item">
                                	                         
                    
                          
                              <?php if($rowimage1['user_id']== $idd1)//if user has uploaded image
                                {
                                  
                                  $image1 = $rowimage1['users_image'];
								  /*=========================select postmedia in 24 hours limit 1 in desc(only one video)=============*/
                                  $query1 = "SELECT post_media from post where user_id='$idd' && date > DATE_SUB(NOW(), INTERVAL 2 DAY) Order by post_id desc limit 0,1";
                                  $result1 = mysqli_query($con, $query1); 
                            
                                  while($row1 = mysqli_fetch_assoc($result1)) 
                                     {
                                       if (!empty($row1['post_media']))
                                        {  
                                          $post1 = $row1['post_media'];
										  $post12 = explode(".",$post1);
										  $post12[1];
										  if($post12[1] == 'webm')
										  {
											  //echo "true";
											  $post = $row1['post_media'];
										  
                               ?>
                          
  <div class="modal fade" id="myModal<?php echo $idd;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
    <div class="modal-content">
     <div class="modal-body">
      <video src="<?php echo "https://".$baseurl."imagesupload/".$post."";?>" id="myvideo<?php echo $idd;?>" style="width: 100%; height: auto; margin:0 auto; frameborder:0;" type="video/webm" >
      </video>
     </div>
    </div>
   </div>
  </div>
  
<script>
  $('#myModal<?php echo $idd;?>').on('shown.bs.modal', function () {
  $('#myvideo<?php echo $idd;?>')[0].play();
});
$('#myModal<?php echo $idd;?>').on('hidden.bs.modal', function () {
  $('#myvideo<?php echo $idd;?>')[0].pause();
  
});
</script>

 <?php
 }
 }
  }
  ?>
  <!--<a href="#" data-toggle="modal" data-target="#myModal<?php echo $idd; ?>"><img src ="<?php echo "https://".$baseurl."imagesupload/".$image1."" ;?>" /></a><br/>-->
  <a href="#" data-toggle="modal" data-target="#myModal<?php echo $idd; ?>"><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></a><br/>  
  <span><?php echo $name; ?></span><br/>
  
<?php 
} //if part
else //if user not uploaded image
 {
   $queryelse = "SELECT post_media from post where user_id='$idd'  && date > DATE_SUB(NOW(), INTERVAL 2 DAY) Order by post_id desc limit 0,1";
   $resultelse = mysqli_query($con, $queryelse); 
                            
   while($rowelse = mysqli_fetch_assoc($resultelse)) 
    {
      if (!empty($rowelse['post_media']))
       {                       
        $postelse1 = $rowelse['post_media'];
		$postelse12 = explode(".",$postelse1);
										  
		if($postelse12[1] == 'webm')
		{
											  //echo "true";
			$postelse = $rowelse['post_media'];
       
     ?>
     
  <div class="modal fade" id="myModal<?php echo $idd;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
    <div class="modal-content">
     <div class="modal-body">
      <video src="<?php echo "https://".$baseurl."imagesupload/".$postelse."";?>" id="myvideo<?php echo $idd;?>" style="width: 100%; height: auto; margin:0 auto; frameborder:0;" type="video/webm">
        </video>
       </div>
      </div>
     </div>
    </div>
    
<script>
  $('#myModal<?php echo $idd;?>').on('shown.bs.modal', function () {
  $('#myvideo<?php echo $idd;?>')[0].play();
});
$('#myModal<?php echo $idd;?>').on('hidden.bs.modal', function () {
  $('#myvideo<?php echo $idd;?>')[0].pause();
  
});
</script>

 <?php
 }
	   }
}
?>
 <a  href= "" data-toggle="modal" data-target="#myModal<?php echo $idd;?>" class = "click" data-id = "<?php echo $idd;?>"><img src ="../../images/man.png" /></a><br/>
  <span><?php echo $name; ?></span><br/>
                            
 <?php
 } //last else part
	
	
} //end if check webm
} //if part of post media
} //end for each loop
 }//end while loop
?>     
</ul>
 </div> 
  </div>
  </div>
 </div>
</div>
</div>
</body>
<footer>
    <?php include('../../footer.php'); ?>
  </footer>
</html>


