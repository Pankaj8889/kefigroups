<?php
include('../../connect.php');
include('../../config.php');
$id = $_POST['user_id'];;
$query = "delete from user_favourite where favourite_id = '$id' ";
$result = mysqli_query($con,$query);
$run= mysqli_query($con,$query);
if($run)
{
	echo "1";
}

?>