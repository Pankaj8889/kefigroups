<?php
include('../../config.php');
include('../../connect.php');

$uid = $_SESSION['userid'];


// $post = array();
$con = mysqli_connect("localhost", "kefigrou_kefi", "bU;CDy}x!(do", "kefigrou_kefi"); 
if (mysqli_connect_errno())
{ 
echo "Failed to connect to MySQL: " . mysqli_connect_error(); 
} 
$query = "SELECT post_media from post where user_id='$uid'";
$result = mysqli_query($con, $query); 

while($row = mysqli_fetch_assoc($result)) 
{
    
$post[] = $row['post_media'];


}

//print_r($post);

//exit();
?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
  Launch demo modal
</button>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        <video controls id="video1" style="width: 100%; height: auto; margin:0 auto; frameborder:0;"  autoplay>
          <?php
          foreach ($post as $row1)
            {
                   
            ?>
          <source src="<?php echo "https://'".$baseurl."'imagesupload/$row1";?>" type="video/webm" id= "webm">
          <?php }   ?>
        
        </video>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php
$vid= $post;

?>
<script>
$('#myModal').on('shown.bs.modal', function () {
  $('#video1')[0].play();
})
$('#myModal').on('hidden.bs.modal', function () {
  $('#video1')[0].pause();
});
</script>
