<?php
include('../../connect.php');
include('../../config.php');
session_start();
$uid = $_SESSION['userid'];
//echo "dsd";
/*$query = "select * from user_favourite where user_id = $uid";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_array($result))
{
    echo $row['favorite_id']."<br/>";
}*/

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
     <title>User Favourites</title>
  </head>
  <?php include('../../header.php'); ?>
<body>
           <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="online_user.php">User  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Favourite</li>
                          
                        </ul>
                </div>
                   
               </div>
           </div>
       </div>
        <div class="user-watchmie-main-section_2">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="user-friends-list2">
                <!--=============================== Fetch user favourite from user_favourite table=====================-->             
                
                <?php  
                $queryfav = "select * from user_favourite where user_id = $uid";
                $resultfav = mysqli_query($con,$queryfav);
                if($resultfav)
                {
                    $count = mysqli_num_rows($resultfav);
                    if($count >= 1){
                    while($rowfav = mysqli_fetch_array($resultfav))
                    {
                        $fav_id = $rowfav['favourite_id'];
                        $queryqw = "select * from user_signup where user_id ='$fav_id'";
                        $resultqw= mysqli_query($con,$queryqw);
                        $rowqw = mysqli_fetch_array($resultqw);
                    
                    $queryimage = "select * from users_meta where user_id = $fav_id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $fav_id)
                    {
                        $image = $rowimage['users_image'];
                        ?>
                            <div class="user-friends-list">
                                <!--<a href="user_profile.php?id=<?php echo $fav_id;?>"><div class="user-friends-pick"><span><img src='<?php echo "https://".$baseurl."imagesupload/$image"; ?>' /></span></div></a>-->
                                <a href="user_profile.php?id=<?php echo $fav_id;?>"><div class="user-friends-pick"><span><img src="data:image/png;base64,<?php echo base64_encode($image); ?>" /></span></div></a>
                                <div class="user-friends-list-title-hero">
                                    <span><?php echo $rowqw['user_username'];?>(<?php echo $rowqw['user_type'];?>)</span>
                                </div>
                               <!--<div class="click-to-remove-btn"><a href="deletefavourite.php?id=<?php echo $id; ?>"><img src="../../images/delete-icon.png"></a></div>-->
                               <div class="click-to-remove-btn"><a onclick="deletenum('<?php echo $fav_id; ?>')" href="JavaScript:Void(0);"><img  src="../../images/delete-icon.png"></a></div>
                            </div>
        
                    <?php 
                        
                    }
                    else
                {
                ?>
                         <div class="user-friends-list">
                                <a href="user_profile.php?id=<?php echo $fav_id;?>"><div class="user-friends-pick"><span><img src="../../images/man.png" /></span></div></a>
                                <div class="user-friends-list-title-hero">
                                    <span><?php echo $rowqw['user_username'];?>(<?php echo $rowqw['user_type'];?>)</span>
                                </div>
                                <!--<div class="click-to-remove-btn"><a href="deletefavourite.php?id=<?php echo $id; ?>"><img src="../../images/delete-icon.png"></a></div>-->
                                 <div class="click-to-remove-btn"><a onclick="deletenum('<?php echo $fav_id; ?>')" href="JavaScript:Void(0);"><img  src="../../images/delete-icon.png"></a></div>

                            </div>  
                             
                   <?php
                    
                }
                    }
                }
                else
                    {
                        echo "Favourite list empty";
                    }
                }
            
                ?>
          <!--===================================End User favourite=======================================-->                   
        
                           <!-- <div class="submit-info-btn">
                                <input class="btn btn-info user-Previous-Page-btn" type="submit" name="submit" value="Submit" />
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>



    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
  <footer>
    <?php include('../../footer.php'); ?>
  </footer>
</html>

<script>
     function deletenum(id){

      var user_id= id;
      
      $.ajax
      ({
        type: 'post',
        url: 'deletefavourite.php',
        data: 
        {
           user_id:user_id
         
        },
      success: function(data) {
        if(data ==1)
        { 

           window.location.href="user_favourite.php";
            }

         },
       });
    }
    </script>