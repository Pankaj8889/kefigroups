<?php
include('../../connect.php');
include('../../config.php');
session_start();
$uid = $_SESSION['userid'];
$id = $_GET['id'];

//echo $id;
$qry = "select * from user_favourite where user_id = '$uid'";
$qryrun = mysqli_query($con,$qry);
$count = mysqli_num_rows($qryrun);
if($count >= 1)
{
	$deletefav = "delete from user_favourite where user_id = '$uid' && favourite_id = '$id'";
	$delfavqry = mysqli_query($con,$deletefav);
	$deletefrnd = "delete from user_addfriend where user_id = '$uid' && addfriend_id = '$id'";
	$delfrndqry = mysqli_query($con,$deletefrnd);
}
else
{
	$deletefrnd = "delete from user_addfriend where user_id = '$uid' && addfriend_id = '$id'";
	$delfrndqry = mysqli_query($con,$deletefrnd);
	
}

	?>
		<script>
	window.location.href="user_friends.php";
	</script>
	<?php
    //header("Location:user_favourite.php");


?>