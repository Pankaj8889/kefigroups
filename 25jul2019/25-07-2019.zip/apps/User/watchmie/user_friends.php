<?php
include('../../connect.php');
include('../../config.php');
session_start();
//echo "eded";
$uid = $_SESSION['userid'];

$queryfav = "select * from user_favourite where user_id= $uid";
$resultfav = mysqli_query($con,$queryfav);

$fav_array = array();

while($rowfav = mysqli_fetch_assoc($resultfav)){
    
    $fav_array[] = $rowfav['favourite_id'];
}
//print_r($fav_array);

 $queryaddfriend = "select * from user_addfriend where user_id = '$uid' ";
$resultaddfriend = mysqli_query($con,$queryaddfriend);

$addfriend_array = array();

while($rowfriend = mysqli_fetch_assoc($resultaddfriend)){
    
    $addfriend_array[] = $rowfriend['addfriend_id'];
}

//print_r($addfriend_array);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <?php
    if($rowusertype['user_type'] == 'user')
    {?>
   
   <?php 
   }
   else
   {?>
   <?php
   }?>
     <title>User friends</title>
  </head>
  <?php include('../../header.php'); ?>
<body>
           <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li><a href="online_user.php">User  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Friends</li>
                          
                        </ul>
                </div>
                   
               </div>
           </div>
       </div>
    
        <div class="user-watchmie-main-section_2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                <form method="post" action="">
                    
                <?php
               /*=======================================================fetch users added in user_addfriend table=========================*/
              
                    $query = "select * from user_addfriend where user_id = '$uid' ";
                    
                    $result = mysqli_query($con,$query);
                    $count1 = mysqli_num_rows($result);
                    if($count1 >= 1)
                    {
                        
                while($row = mysqli_fetch_array($result))
                {
                    
                    $idd =  $row['addfriend_id'];
                    $querytype = "select * from user_signup where user_id = '$idd'";
                    $resulttype = mysqli_query($con,$querytype);
                    $rowtype = mysqli_fetch_array($resulttype);
                    {
                   
                    /*========================================discard value which are in favourite=======================*/
                    if (!in_array($row['addfriend_id'], $fav_array)){
                        
                     /* ========================================  discard session id from registered user===================*/ 
                       // if($row['user_id'] != $uid){
                    
                   
                    $id = $row['addfriend_id'];
                    $queryimage = "select * from users_meta where user_id = $id";
                    $resultimage = mysqli_query($con,$queryimage);
                    $rowimage = mysqli_fetch_array($resultimage);
                    if($rowimage['user_id']== $id)
                    {
                    $image = $rowimage['users_image'];
                   ?>
                   <div class="user-friends-list">
                     <!--<a href="user_profile.php?id=<?php echo $id;?>"><div class="user-friends-pick"><span><img src ='<?php echo "https://".$baseurl."imagesupload/$image"; ?>' /></span></div></a>-->
                     <!--<a href="user_profile.php?id=<?php echo $id;?>"><div class="user-friends-pick"><span><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></span></div></a>-->
                     <a href="user_profile.php?id=<?php echo $rowimage['user_id'];?>&&sess_id=<?php echo $uid;?>"><div class="user-friends-pick"><span><img src ="data:image/png;base64,<?php echo base64_encode($image); ?>" /></span></div></a>
                     <div class="user-friends-list-title-hero">
                      <!--<input type="checkbox" name="chk" id="chk_<?php echo $row['addfriend_id'] ;?>" value ="<?php echo $row['addfriend_id'] ;?>">Save as favourite-->
                      <input type="checkbox" name="chk" id="chk_<?php echo $row['addfriend_id'] ;?>" value ="<?php echo $row['addfriend_id'] ;?>">favourite friend

                      <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                       <span><?php echo $rowtype['user_username'];?>(<?php echo $rowtype['user_type'];?>)</span><br/>
                       <!--================== unfriend button=======================-->
                       
                       <!--<a href="deletefriend.php?id=<?php echo $id; ?>"><span>Unfriend</span></a>-->

                       <!--================== unfriend button=======================-->
                       </div>
                   </div>
                <?php 
                        
                    }
                else
                {
                ?>
                  <div class="user-friends-list">
                       <!--<a href="user_profile.php?id=<?php echo $id;?>"> <div class="user-friends-pick"><span><img src="../../images/man.png" /></span></div></a>-->
                       <a href="user_profile.php?id=<?php echo $id;?>&&sess_id=<?php echo $uid;?>"> <div class="user-friends-pick"><span><img src="../../images/man.png" /></span></div></a>
                         <div class="user-friends-list-title-hero">
                             <!--<input type="checkbox" name="chk" id="chk_<?php echo $row['addfriend_id'] ;?>" value ="<?php echo $row['addfriend_id'] ;?>">Save as favourite-->
                             <input type="checkbox" name="chk" id="chk_<?php echo $row['addfriend_id'] ;?>" value ="<?php echo $row['addfriend_id'] ;?>">favourite friend
                             <input type="hidden" name="uid" id="uid" value ="<?php echo $uid; ?>" /><br/>
                         <span><?php echo $rowtype['user_username'];?>(<?php echo $rowtype['user_type'];?>)</span><br>
                         <!--================== unfriend button=======================-->
                       
                       <!--<a href="deletefriend.php?id=<?php echo $id; ?>"><span>Unfriend</span></a>-->
                       
                       <!--================== unfriend button=======================-->
                        </div>
                  </div>
                
                <?php
               // } 
                }
                }
                
                }
                }
               // if(!empty($fav_array)){
                //$diff = array_diff($fav_array,$addfriend_array);
                if($fav_array == $addfriend_array)
                {
                    echo "all friends are added in favourite list";
                }
                // if(!empty($diff)){
                   
                   //echo "all friends are added in favourite list";
                   
              // }
                
               // }
                    }
            
                else
                {
                    echo "Friend list empty";
                }
                /*=====================================End==================================*/
                ?>
                
                <!--<div class="submit-info-btn"><input class="btn btn-info user-Previous-Page-btn" type="submit" name="submit" value="Submit"/></div>
                </form>-->
                
                   
                       </div>
                    </div> 
                </div> 
        </div> 
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
  <footer>
    <?php include('../../footer.php'); ?>
  </footer>
</html>
<!--===============================Check box value send through ajax in user_favourite table==========================-->
<script>
        $(document).on("change", "input[name='chk']", function () {
            var checkbox = $(this);
            var checked = checkbox.prop('checked');
            
        
            var favid = $(this).attr('value');
            var uid = document.getElementById('uid').value;
            //alert(uid);
          //alert(favid);
            $.ajax({
                url:"ajax_userfriend.php",
                type: 'post',
                data: {
                    //action: 'checkbox-select', 
                    //id: checkbox.data('contact_avl'),
                    favid: favid,
                    uid: uid,
                    checked:checked
                      },
                success: function(data) {
                    window.location.href="";
                    alert(data);
                   //alert("yes");
                },
                error: function(data) {
                   // alert(data);
                    //alert("no");
                    // Revert
                    checkbox.attr('checked', !checked);
                    
                }
            });
        });
    </script>
<!--===============================End ajax==========================================================-->