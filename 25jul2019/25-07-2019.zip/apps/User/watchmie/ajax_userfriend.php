<?php
include('../../connect.php');
include('../../config.php');
$uid = $_SESSION['userid'];


if(isset($_POST['favid']) && isset($_POST['uid']) && isset($_POST['checked']))
{
    $fav_id = $_POST['favid'];
    
    $uid_id = $_POST['uid'];
   // echo $fav_id;
    
    
   $getrow = "select count(*) as number from user_favourite where user_id= $uid";
    $rowfetch =mysqli_query($con,$getrow);
    $row = mysqli_fetch_assoc($rowfetch);
   
   if($row['number'] >=11)
   {
       echo "You cannot add more than 10 friend in favourite list";
   }
   else
   {
        
    $query = "insert into user_favourite(user_id,favourite_id) values('$uid_id','$fav_id')";
  //  echo "insert into user_favourite(user_id,favourite_id) values('$uid_id','$fav_id')";
    $result = mysqli_query($con,$query);
    echo "friend added in favourite list";
       
   }
    
    
    //$query = "insert into user_favourite(user_id,favourite_id) values('$uid_id','$fav_id')";
  //  echo "insert into user_favourite(user_id,favourite_id) values('$uid_id','$fav_id')";
   // $result = mysqli_query($con,$query);
    
}
?>