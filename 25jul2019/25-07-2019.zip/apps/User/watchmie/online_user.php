<?php
include('../../config.php');
include('../../connect.php');
session_start();
/*
if(!($_SESSION['userid']))
{ ?><script>	//window.location.href="user-sign-in.php"; 

    window.location.href="https://<?php echo $baseurl;?>User/user-sign-in.php"; 

	</script><?php
	//header('location:user-sign-in.php');
}
*/
  $uid = $_SESSION['userid'];
//$query = "select us.*,um.* from user_signup us join users_meta um  on us.user_id = um.user_id where us.user_status = 'online'";
//echo "1";
//$query = "select * from user_signup where user_status = 'online'";


//$query = "select * from user_addfriend where user_status = 'online' && user_id = '$uid'";

$queryselfriend = "select * from user_addfriend where user_id = '$uid' ";
$resultselfriend = mysqli_query($con,$queryselfriend);


if($resultselfriend)
{

	while($resrow = mysqli_fetch_array($resultselfriend))
	{
		$friendid = $resrow['addfriend_id'];
		$queryselect = "select * from user_signup where user_id = '$friendid' && user_status='online'";
		$resultselect = mysqli_query($con,$queryselect);
		if($resultselect)
		{
			$rowselect = mysqli_fetch_array($resultselect);
			$userid = $rowselect['user_id'];
			$queryinsert = "update user_addfriend set user_status = 'online' where addfriend_id = '$userid'";
			$resultinsert = mysqli_query($con,$queryinsert);
		}
	}
}



//$querygetdata = "select * from user_addfriend where addfriend_id = '20190108102331' && user_status = 'online'";
//$execitequery= mysqli_query($con,$querygetdata);



/*echo $query12 = "select addfriend_id from user_addfriend where user_id = '$uid'";
$result12 = mysqli_query($con,$query12);
$row123 = mysqli_num_rows($result12);
if($row123 >= 1)
{
    echo "Success";
    while($row12 = mysqli_fetch_array($result12))
    {
        //if(!empty($row12))
        echo "<br/>".$row12['addfriend_id'];
        //else
        //echo "no";
    }
}
else
{
    echo "Not successfull";
}
die();*/


//$querypost = "select po.* ,us.* from post po join user_signup us on po.user_id = us.user_id where us.user_status = 'online' order by post_id DESC";
 //$querypost = "select po.* ,us.* , user.* from post po join user_addfriend us on po.user_id = us.addfriend_id join user_signup user on po.user_id = user.user_id where us.user_id = '$uid' && user.post_visibility='friends' or user.post_visibility='public' order by post_id DESC";
//echo "select po.*  us.* from post po join user_signup us on po.user_id = us.user_id where us.user_status = 'online' order by post_id DESC";





?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>Online Users</title>
  </head>
  <?php include('../../header.php'); ?>
   <body>
       
       <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>Users</li>
                          
                        </ul>
                </div>
                   
               </div>
           </div>
       </div>
<div class="user-watchmie-main-section">
    <div class="user-post-section-1">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                  
                    <div class="header-section-watchmie-info">
                         <ul class="nav">
        <!--=================================Online user =================================-->
                    <?php


                    $querygetdata = "select * from user_addfriend where user_id = '$uid' && user_status = 'online'";
					          $execitequery= mysqli_query($con,$querygetdata);

                    /*=========================== to check add any user or any user online======================*/
                        $count1 = mysqli_num_rows($execitequery);
                        if($count1 >= 1) //if greater than 1 ie user online in addfriend list
                        {
                       while($row = mysqli_fetch_array($execitequery))
                    {
                        
                        
                       $id = $row['addfriend_id'];
                       $queryname = "select * from user_signup where user_id = '$id' "; // to fetch username
                       $resultname = mysqli_query($con,$queryname);
                       $rowname = mysqli_fetch_array($resultname);
                       // echo $name = $rowname['user_username'];
                        //echo $row['user_username'];
                        $queryimage = "select * from users_meta where user_id = $id";
                        $resultimage = mysqli_query($con,$queryimage);
                        $rowimage = mysqli_fetch_array($resultimage);
                        //echo "jhjkn";
                        //echo $rowimage['user_id'];
                        if($rowimage['user_id']== $id)
                        {
                            $image = $rowimage['users_image'];
                            
                           //echo $row
                            
                       ?>
                              <li class="nav-item">
                                <!--<a href="user_profile.php?id=<?php echo $rowimage['user_id'];?>&&sess_id=<?php echo $uid;?>"><img src ='<?php echo "https://".$baseurl."imagesupload/".$image."" ;?>' /></a><br/>-->
                                <a href="user_profile.php?id=<?php echo $rowimage['user_id'];?>&&sess_id=<?php echo $uid;?>"><img src="data:image/png;base64,<?php echo base64_encode($image); ?>" /></a><br/>
                                 <span><?php echo $rowname['user_username']; ?></span><br/>
                                 <span class="online-active">Online</span>
                    <?php
                        }
                        else
                        {
                            
                          ?>
                              <li class="nav-item">
                                <a href="user_profile.php?id=<?php echo $id;?>&&sess_id=<?php echo $uid;?>"><img src="../../images/man.png"></a><br/>
                                <span><?php echo $rowname['user_username']; ?></span><br/>
                                <span class="online-active">Online</span>
                            </li>   
                           <?php 
                            
                        }
   
                    }
                   
                  }
                 
                  else
                  {
                      //echo "No Active user";
                  }
                 
                    ?>
  
                           
                           </ul>
                          
                    </div> 
                    
<!--=================================End online user==========================-->
                    <!--===========================Post==============================================-->
                  <?php
                  $querypost = "select po.* ,us.* , user.* from post po join user_addfriend us on po.user_id = us.addfriend_id join user_signup user on po.user_id = user.user_id where us.user_id = '$uid' && (user.post_visibility='public' || user.post_visibility='friends') order by post_id DESC";

                   $resultpost = mysqli_query($con,$querypost);
                                  
                        while($rowpost = mysqli_fetch_array($resultpost))
                        {
                          //echo "eryierugerug";
                          //die;

                            //$id1 = $rowpost['user_id'];
                            $id1 = $rowpost['addfriend_id'];                      
                            $queryname1 = "select * from user_signup where user_id = '$id1' ";// to fetch username
                            $resultname1 = mysqli_query($con,$queryname1);
                            $rowname1 = mysqli_fetch_array($resultname1);
                           $queryimage1 = "select * from users_meta where user_id = $id1";
                            $resultimage1 = mysqli_query($con,$queryimage1);
                            $rowimage1 = mysqli_fetch_array($resultimage1);
                         /*===========================fetch user media to discard the video(webm)==========================*/
                        $var1 = $rowpost['post_media'];
                        
                        //die;
						$var2 = explode(".",$var1);
					    if($var2[1] != 'webm' && $var2[1] != 'wav' && $rowpost['post_media'] != '')
					    {
					    ?>
                        
                     
                         <div class="media-user-post-block-media1">   
                        <div class="media user-post-block-media">
                            <?php if($rowimage1['user_id']== $id1)
                        {
                            $image1 = $rowimage1['users_image'];
                            ?>
                            <!--<img class="mr-3 Hero-user-pick" src='<?php echo "https://".$baseurl."imagesupload/".$image1."" ;?>' alt=""><br/>-->
                            <img class="mr-3 Hero-user-pick" src="data:image/png;base64,<?php echo base64_encode($image1); ?>" alt=""><br/>
                            <span class="name-margin"><?php echo $rowname1['user_username']; ?></span>
                           
                         <?php
                        }
                        else
                        {

                             ?>
                             <img class="mr-3 Hero-user-pick" src="../../images/man.png" alt=""><br/>
                             <span class="name-margin"><?php echo $rowname1['user_username']; ?></span>
                             
                        <?php
                            
                        }
                        ?>
                        <div class="media-body text-margin">
                        <p><a href ="../post_details.php?id=<?php echo $rowpost['post_id'];?>"><?php echo substr($rowpost['description'],0,30);?>.....</a></p>
                      	
                        <?php
                        /*
							         if (!empty($rowpost['post_media']))
							         {
							         ?>
                         <div class="user__media__upload-post">
 									          <span>Media : </span><a href="../post_details.php?id=<?php echo $rowpost["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$rowpost['post_media'];?></a>
									         </div>
									     <?php 
                       }
                       */
									     ?>
                       <?php
                    if (!empty($rowpost['post_media']))
                    {
                    ?>
                  <div class="user__media__upload">
                    <!--<span>Media :</span><a href="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$getdataquery['post_media'];?> </a>-->

                    <?php
                    $vid =$rowpost['post_media'];
                            $ext = pathinfo($vid, PATHINFO_EXTENSION);
                            //echo $ext;
                            if($ext == 'wav' || $ext == 'ogg' || $ext == 'mpeg')
                            {
                            ?>
                                <a href="User/post_details.php?id=<?php echo $rowpost["post_id"];?>">
                                  <audio controls>
                                  <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="audio/<?php echo $ext; ?>">
                                  </audio>
                                  </a>
                           <?php
                              }
                              $urlimg = "https://".$baseurl."imagesupload/thumbs/";
                               if ($ext == 'png' || $ext =='jpeg' || $ext == 'jpg')
                              
                                  echo '<img src= "'.$urlimg.$rowpost['thumb_img'].'"  width="300px"/>';
                             ?>    

                            </div>
                              <?php
                              }
                              ?>

                         </div>

                    </div>
                      
                <!--=================================post seen=======================-->        
                        <?php
                        $ppid = $rowpost['post_id'];
						//$queryseen = "select post_seen from post where post_id = $ppid";
						$queryseen = "select count(distinct user_id) as seen from post_seen where post_id = $ppid";
						$resultseen = mysqli_query($con,$queryseen);
						if($resultseen)
						$rowseen = mysqli_fetch_array($resultseen);
				/*-=================================End	 post seen ====================*/
				
				
				/*====================================post like===========================*/		
					/*	$querylikes = "select count(distinct user_id) as value from post_likes where post_id = $ppid";
						$resultlikes = mysqli_query($con,$querylikes);
						$rowlikes = mysqli_fetch_array($resultlikes);
						$postid= $rowpost["post_id"];*/
					/*==============================End post like============================*/	
					
					
						/*===================select share count from post share table===================*/
									$queryshare = "select count(post_id) as value from post_share where post_id = $ppid";
									$resultshare = mysqli_query($con,$queryshare);
									$rowshare = mysqli_fetch_array($resultshare);
									$postid= $rowpost["post_id"];
									
						/*==============================End post share============================*/	
				
					
						?>
					
                        <div class="user-like-section">
                            <ul class="nav">
                                <li class="nav-item">
                                    <a href="JavaScript:Void(0);"><img src="../../images/seen-icon.png"> &nbsp;Seen(<?php echo $rowseen['seen'];?>)</a>
                                </li>
                                <li class="nav-item">
                                    <a href="../post_details.php?id=<?php echo $rowpost['post_id'];?> "><img src="../../images/say-something-icon.png"> &nbsp;Say Something</a>
                                </li>
                                <li class="nav-item">
                                    
                                    <?php 
                                    /*if($uid == $rowlikes['user_id']){
                                        echo $uid;
                                    ?>
                                    <img src="../../images/toss-icon1.png"> &nbsp;Toss(<?php echo $rowlikes['value'];?>)
                                    <?php
                                    } 
                                    else
                                    {*/
                                    ?>
                                    <!--<a href="onlineuser_like.php?id=<?php echo $rowpost['post_id'];?>" value="like"><img src="../../images/toss-icon1.png"> &nbsp;Toss(<?php echo $rowlikes['value'];?>)</a>-->
                                    
                                    <a href="../../index.php?tid=<?php echo $rowpost['post_id'];?>" value="like"><img src="../../images/toss-icon1.png"> &nbsp;Toss</a>
                                    
                                    <?php
                                   // }?>
                                </li>

                            </ul>
                        </div>
                    </div>
                    <?php
                    }// end video(webm if)
                        }
                        
                    ?>
                    
  <!--===================================End section post====================================================-->                

                    
                    <div class="user-Friend list-section">
                        <ul class="nav">
                            <li>
                               <!-- <div class="dropdown">
                                <button onclick="myFunction()" class="dropbtn-btn-click">Friend list <i class="fa fa-caret-down" aria-hidden="true"></i></button>
                                  <div id="myDropdown" class="dropdown-content">
                                    <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
                                    <a href="#">Apple</a>
                                    <a href="#">Ken</a>
                                     <a href="#">Apple</a>
                                    <a href="#">Ken</a>
                                   
                                  </div>
                                  
                                </div>-->
                                <a href="user_friends.php">Friends</a>
                            </li>

                            <li>
                              <a href="../../index.php">Home</a>
                            </li>
                            
                             <li>
                               <a href="user_favourite.php">Favourite</a>
                            </li>                            
              
                        </ul>
                        
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
       
       
       
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
	<script>
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDropdown");
    a = div.getElementsByTagName("a");
    for (i = 0; i < a.length; i++) {
        if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
}
</script>
  </body>
</html>
