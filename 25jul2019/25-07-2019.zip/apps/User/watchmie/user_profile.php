<?php 
include('../../connect.php');
include('../../config.php');
$id = $_GET['id'];
//echo "id".$id;
//$idd = $_GET['idd'];
//echo "user id".$id = $_GET['idd'];
$sess_id = $_GET['sess_id'];

//echo $id;
if($id != '' && $sess_id != '')
{

	session_start();
  $selectqry = "select * from user_profile_seen where from_id = '$sess_id' && to_id = '$id'";
  $selectresult = mysqli_query($con,$selectqry);
  $count = mysqli_num_rows($selectresult);
  $seendate =date('Y-m-d h:i:sa');
  //echo $count;
  
  if($count< 1)
  {


     $qry = "insert into user_profile_seen (from_id,to_id, date) values ('$sess_id','$id','$seendate')";
    
    //die;
    $result = mysqli_query($con,$qry);

  }

}

$uid = $_SESSION['userid'];
$username = $_SESSION['user_username'];
$query = "select * from users_meta where user_id = $id";
$result = mysqli_query($con,$query);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsive.css">
    <title>Profile</title>
  </head>
  <?php include('../../header.php'); ?>
   <body>
       
              <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <div class="user-breadcrumb">
                        <ul class="nav breadcrumb-list">
                          <li class="active"><a href="../../index.php">Profile  &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <a href="online_user.php"><li>Users &nbsp;<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                          <li>User status</li>
                          
                        </ul>
                </div>
                   
               </div>
           </div>
       </div>
       
    <div class="user-watchmie-main-section">
    <div class="user-post-section-1">
        <div class="container">
            <div class="row">
              <div class="col-md-3">
                    <div class="header-section-user-profile-info">
                        
                        <div class="user-pick-top text-center">
                            <span>
                            <?php
                            $row= mysqli_fetch_array($result);
                            $image = $row['users_image'];

                            if($row)
                            {
                            ?>
                               <img src="data:image/png;base64,<?php echo base64_encode($image); ?>" />
                               <a href="deletefriend.php?id=<?php echo $id; ?>">Unfriend</a>
                             <?php
                            }
                            else
                            {
                            ?>
                            
                               <img src="../../images/man.png">
                             <?php
                            }?>
                            </span>
                            <?php
                            $nameqry= "select * from user_signup where user_id = '$id'";
                            $qryres = mysqli_query($con,$nameqry);
                            $resrow = mysqli_fetch_assoc($qryres);
                            $uname=$resrow['user_username'];                            
                            $querygetdata = "select count(*) as count from user_profile_seen where to_id = '$id' ";

                            $resultgetdata = mysqli_query($con,$querygetdata);
                            $countrow = mysqli_fetch_assoc($resultgetdata);
                            $count=$countrow['count']; 
                            if($count >= 1)
                            { ?>
                            <h3 class="Status-title-hero">Status (<?php echo $count; ?>)</h3>
                            <a href="deletefriend.php?id=<?php echo $id; ?>">Unfriend</a>

                            <?php }
                            else
                            {?>
                            <h3 class="Status-title-hero">Newbie</h3>
                            <a href="deletefriend.php?id=<?php echo $id; ?>">Unfriend</a>
                            <?php }

                            ?>
                            
                        </div>
                       
                       
                    </div>
                </div>
                
                <div class="col-md-9">
                    <?php
            /*==================================== particular user post============================================*/
                $querypost="select po.*,us.* from post po join user_signup us on po.user_id = us.user_id where po.user_id = '$id' && (us.post_visibility = 'friends' or us.post_visibility = 'public') order by post_id desc";
                $resultpost = mysqli_query($con,$querypost);
               // if($resultpost)
                //{
               $count =mysqli_num_rows($resultpost);
                if($count < 1)
                {
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"."No Post"."<br/><br/><br/>";
                }
                 else
                 {
                     //echo $rowpost[]
                     while($rowpost = mysqli_fetch_array($resultpost)){
                ?>
                    <div class="media-user-post-block-media1">
                        <div class="media user-post-block-media">
                            
                            <?php
        /*===================================user image =============================================================*/                    
                            $query1 = "select * from users_meta where user_id = $id";
                            $result1 = mysqli_query($con,$query1);
                            $row1= mysqli_fetch_array($result1);
                            $image1 = $row1['users_image'];
                            if($row)
                            {
                            ?>
                               <!--<img class="mr-3 Hero-user-pick" src='<?php echo "https://".$baseurl."imagesupload/".$image1."" ;?>' />-->
                               <img class="mr-3 Hero-user-pick" src="data:image/png;base64,<?php echo base64_encode($image1); ?>" />
                             <?php
                            }
                        
                            else
                            {
                            ?>
                                <img class="mr-3 Hero-user-pick" src="../../images/man.png" alt="">
                           <?php
                           }
                           ?>
                            
                           
                            
                           
                            <div class="media-body">

                                <p>
                                    <a href="../post_details.php?id=<?php echo $rowpost['post_id']; ?>"><?php echo substr($rowpost['description'],0,30);?>.....</p>
                                    <?php 
                                    /*
                                    if(!empty($rowpost['post_media']))
                                    {
                                    ?>
                                <div class="user__media__upload-post">
                                    <span>Media : </span><a href="../post_details.php?id=<?php echo $rowpost["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$rowpost['post_media'];?> </a>
                                </div>

                                <?php
                                   } */
                                   
                    if (!empty($rowpost['post_media']))
                    {
                    ?>
                  <div class="user__media__upload">
                    <!--<span>Media :</span><a href="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$getdataquery['post_media'];?> </a>-->

                    <?php
                    $vid =$rowpost['post_media'];
                            $ext = pathinfo($vid, PATHINFO_EXTENSION);
                            //echo $ext;
                            if($ext == 'wav' || $ext == 'ogg' || $ext == 'mpeg')
                            {
                            ?>
                                <a href="User/post_details.php?id=<?php echo $rowpost["post_id"];?>">
                                  <audio controls>
                                  <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="audio/<?php echo $ext; ?>">
                                  </audio>
                                  </a>
                           <?php
                              }
                              $urlimg = "https://".$baseurl."imagesupload/thumbs/";
                              if ($ext == 'png' || $ext =='jpeg' || $ext == 'jpg')
                              {
                              ?>
                                   <a href="User/post_details.php?id=<?php echo $rowpost["post_id"];?>">
                                   <img src = "<?php echo $urlimg.$rowpost['thumb_img'];?>"  width = "300">
                                   </a>
                              <?php    
                              }
                              
                              if ($ext == 'webm' || $ext == 'mp4' || $ext == 'ogg')
                              {
                              ?>
                              <a href="User/post_details.php?id=<?php echo $rowpost["post_id"];?>">
                              <video width="400" controls>
                               <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="video/<?php echo $ext; ?>">
                               </video>
                               </a>
                              <?php
                              }
                              ?>

                  </div>
                    <?php
                    }
                                                     
                                 ?>
                            </div>

                        </div>
                        
                       <?php
                      /*=======================post seen=====================================================*/ 
                       $ppid = $rowpost['post_id'];
                       //echo $ppid;
									//$queryseen = "select post_seen from post where post_id = $ppid";
					   $queryseen = "select count(distinct user_id) as seen from post_seen where post_id = $ppid";
					   $resultseen = mysqli_query($con,$queryseen);
						if($resultseen)
						$rowseen = mysqli_fetch_array($resultseen);
					/*=================================End post seen ================================*/
					
					/*===================select like count from post like table===================*/
									
					/*	$querylikes = "select count(distinct user_id) as value from post_likes where post_id = $ppid";
						$resultlikes = mysqli_query($con,$querylikes);
						$rowlikes = mysqli_fetch_array($resultlikes);
						$postid= $rowpost["post_id"];*/
					/*======================end like post============================================*/
					
					/*===================select share count from post share table===================*/
									$queryshare = "select count(post_id) as value from post_share where post_id = $ppid";
									$resultshare = mysqli_query($con,$queryshare);
									$rowshare = mysqli_fetch_array($resultshare);
									$postid= $rowpost["post_id"];
									
						/*==============================End post share============================*/
                        ?>
                        <div class="user-like-section">
                            <ul class="nav">
                                <li class="nav-item">
                                    <a href="JavaScript:Void(0);"><img src="../../images/seen-icon.png"> &nbsp;Seen(<?php echo $rowseen['seen'];?>)</a>
                                </li>
                                <li class="nav-item">
                                    <a href="../post_details.php?id=<?php echo $rowpost["post_id"];?>"><img src="../../images/say-something-icon.png"> &nbsp;Say Something</a>
                                </li>
                                <li class="nav-item">

                                    <a href="../../index.php?tid=<?php echo $rowpost["post_id"];?>"><img src="../../images/toss-icon1.png"> &nbsp;Toss</a>
                                </li>

                            </ul>
                        </div>
                    </div>
                    <?php
                }  
               }
                
                /*====================================End post ========================================================*/
                ?>
        
                  <!--=========================================	Comment Section =======================================-->		 
                    <div class="user-post-information-show1">
                        <form method='post' action="" onsubmit="return post();">
                        <textarea class="form-control" id="comment" placeholder="Write Your Comment Here....."></textarea>
                        <br>
                        <input type="hidden" id="username1" placeholder="Your Name" />
                        <input type="hidden" id="username" placeholder="Your Name"  value ="<?php echo $username; ?>"/>

                        <input type="hidden" id="proid1" placeholder="Your Name"  />
                        <input type="hidden" id="proid" placeholder="Your Name" value="<?php echo $id; ?>"  />
                        <input class="btn btn-info Post__Comment" type="submit" value="Post Comment">
                        </form>
                    </div>
                    <div id="all_comments" class="user-post-information-show2">
  <?php
    

    
  
    $comm = mysqli_query($con,"select * from userprofile_comments where user_id = $id order by post_time desc");
    while($row12=mysqli_fetch_array($comm))
    {
	  $name=$row12['name'];
	  $comment=$row12['comment'];
      $time=$row12['post_time'];
    ?>
	
	<div class="comment_div"> 
	  <p class="name">Posted By: <?php echo $name;?> <strong class="time"> <?php echo $time;?></strong></p>
      <p class="comment"><?php echo $comment;?></p>	

	</div>
  
    <?php
    }
    ?>
  </div>
<!--============================================ End commment section ===============================-->  
                                      
                    
                    
                 <!--<div class="user-Friend list-section">
                    <ul class="nav">
                        <li>
                            <a href="#">Favourite</a>
                        </li>
                
                        <li>
                            <a href="#">Favourite</a>
                        </li>
                
                        <li>
                            <a href="#">Home</a>
                        </li>
                    </ul>
                
                </div>-->
                </div>
                
            </div>
        </div>
    </div>
</div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
	<script src="../../js/custom.js"></script> 
  </body>
  <footer>
    <?php include('../../footer.php'); ?>
  </footer>
</html>
<!--===============================Comment section===================-->
<script type="text/javascript">
function post()
{
  var comment = document.getElementById("comment").value;
  var name = document.getElementById("username").value;
  
  var proid = document.getElementById("proid").value;
 // alert(proid);
  if(comment && name && proid)
  {
    $.ajax
    ({
      type: 'post',
      url: 'userprofile_comments.php',
      data: 
      {
         user_comm:comment,
	     user_name:name,
	     pro_id:proid,
      },
      success: function (response) 
      {
	    document.getElementById("all_comments").innerHTML=response+document.getElementById("all_comments").innerHTML;
	    document.getElementById("comment").value="";
        document.getElementById("username1").value="";
        document.getElementById("proid1").value="";
        
  
      }
    });
  }
  
  return false;
}
</script>
<!--=================================End comment Section===================-->
