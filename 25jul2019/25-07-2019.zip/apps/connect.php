<?php
$con=mysqli_connect("localhost","kefigrou_kefi","L2eckA]3!NNb","kefigrou_kefi");
if(!$con)
{
	die("Error while connecting db".mysqli_connect_error());
}
date_default_timezone_set('Asia/Kolkata');
?>