<?php
include('connect.php');
include('config.php');
include('image-resize/vendor/autoload.php');

use \Gumlet\ImageResize;
 ob_start();
session_start();

?>
<?php //include('header.php');


if(isset($_COOKIE['email'],$_COOKIE['password']))
	//if(!isset($_COOKIE[$cookie_name])) 
{
	$email = $_COOKIE['email'];
	$pass = $_COOKIE['password'];
	$querycookie = "select * from user_signup where user_email = '$email' && user_password = '$pass'";
	$resultcookie = mysqli_query($con,$querycookie);
	$countlogin = mysqli_num_rows($resultcookie);
	if($countlogin == 1)
	{
		$rowlogin = mysqli_fetch_assoc($resultcookie);

		$_SESSION['userid'] = $rowlogin['user_id'];
	
		$_SESSION['user_username'] = $rowlogin['user_username'];
		$_SESSION['user_type'] = $rowlogin['user_type'];
	
		$uid = $_SESSION['userid'];
		$queryonline="update user_signup set user_status='online' where user_id = '$uid'";
		$resultonline = mysqli_query($con,$queryonline);

		
	   //header('location:../index.php');
		
	}
	}

$tid = $_GET['tid'];
$type =  $_SESSION['user_type'] ;
	//echo $_SESSION['userid'];
	/*
	if(!($_SESSION['userid']))
	{ 
		?>
		<script>
		window.location.href="https://<?php echo $baseurl; ?>User/user-sign-in.php";
		</script>
		<?php
		//header('location:https://'.$baseurl.'/Kefi/User/user-sign-in.php');
	}
	*/

	$uid = $_SESSION['userid'];
	$queryusertype = "select * from user_signup where user_id = $uid";
	$resultusertype = mysqli_query($con,$queryusertype);
	$rowusertype = mysqli_fetch_array($resultusertype);
		
		//$queryonline = "update user_addfriend set user_status = 'online' where addfriend_id = '$uid'";
		//$resultonline = mysqli_query($con,$queryonline);
	
	
//echo $rowusertype['user_type'];

?>
<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" http-equiv="Content-Type">
<link rel="stylesheet" href="https://kefigroups.com/apps/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/croppie.css" />
  
   
    <?php
    if($rowusertype['user_type'] == 'user')
    {?>
    <title>User Profile</title>
   <?php 
   }
   else
   {?>
   <title>Merchant Profile</title>
   <?php
   }?>
    
  </head>
<?php
//include('connect.php');
//session_start();
$uid = $_SESSION['userid'];


/*==========================Post publish in post table================================*/


if(isset($_POST['publish']))
{
	$maneimgdb= '';
	date_default_timezone_set('Asia/Singapore');
	$date =date('Y-m-d h:i:sa');

	if($_FILES['mediaupload']['name'])
	{
		
		 $path1 = $_FILES['mediaupload']['name'];
		
		$_FILES['mediaupload']['tmp_name'];
		$ext1 = pathinfo($path1, PATHINFO_EXTENSION);
		$logo11 = time().'.'.$ext1;

	//	$logo12 = "https://kefii-dev-pankajsaini8889.c9users.io/Kefi/imagesupload/$logo11";

		/*==========image resize=========*/
		if( $ext1 == 'jpeg' || $ext1 == 'png' || $ext1 == 'jpg' )
		 {

		 $path = 'imagesupload/thumbs/';   
	     $tmpFile = $_FILES["mediaupload"]["tmp_name"];    
	     $fileName = $_FILES["mediaupload"]["name"];   
	     $file = $path."thumb_".$fileName;	
	     $maneimgdb =  "thumb_".$fileName;	
		$image = new ImageResize($tmpFile);
		$image->resizeToBestFit(300, 300);
		$image->save($file);

		}
		
		/*==========image resize=========*/

		$imagepath1 = 'imagesupload/';
		move_uploaded_file($_FILES['mediaupload']['tmp_name'],$imagepath1.$logo11);
		$description = addslashes($_POST['description']);
	//	$_SESSION['description'] = $description;
		$querypost = "insert into post(user_id,date,description,post_media,thumb_img,user_type)values('$uid','$date','$description','$logo11','$maneimgdb','$type')";
		
		$resultpost = mysqli_query($con,$querypost);
	//	unset($_SESSION['description']);
		if($resultpost)
		{
			$msg = "Data Saved Successfully ";
		}
		
	}
	else
	{
		$description = addslashes($_POST['description']);
		$querypost = "insert into post(user_id,date,description,user_type)values('$uid','$date','$description','$type')";
		$resultpost = mysqli_query($con,$querypost);
		if($resultpost)
		{
			$msg = "Data Saved Successfully ";
		}	
	}
		
	
/*	else
	{
		$description = $_POST['description'];
		$querypost = "insert into post(user_id,date,description)values('$uid','$date','$description')";
		$resultpost = mysqli_query($con,$querypost);
	
	}*/

	}

	/*=============================display latest post==========================================*/

	//$qry = "select po.* ,sign.* from post po join user_signup sign on po.user_id = sign.user_id where isgn.user_id = $uid" ;

	 //$querypost = "select po.* ,us.* , user.* from post po join user_addfriend us on po.user_id = us.addfriend_id join user_signup user on po.user_id = user.user_id where us.user_id = '$uid' && (user.post_visibility='public' || user.post_visibility='friends') order by post_id DESC";




	//$querydisplay = "select * from post where user_id = '$uid' ORDER BY post_id DESC";
	//$resultdisplay = mysqli_query($con,$querydisplay);
	//if($resultdisplay)
	//$rowdisplay = mysqli_fetch_array($resultdisplay);
	//print_r($rowdisplay);
	//die;
	/*==============================insert(update) the userid username and date in post table who shared the post=========================*/
	
	if($tid){
	$queryshare1 = "select * from post where post_id = '$tid'";
	$resultshare1 = mysqli_query($con,$queryshare1);
	$rowshare1 = mysqli_fetch_array($resultshare1);
		//echo "121";
	$userid = $rowshare1['user_id'];
	$queryusershare = "select * from user_signup where user_id = '$uid'";
	$resultusershare = mysqli_query($con,$queryusershare);
	$rowusershare = mysqli_fetch_array($resultusershare);
    $username1 = $rowusershare['user_username'];
   	$date1 =date('Y-m-d h:i:sa');
   // $queryshareup = "update post set shared_postusername = '$username1' ,share_postuserid = '$uid', shared_postdate ='$date1'  where user_id = '$userid' && post_id = '$tid'";
     $queryshareup = "insert into post_share(from_userid,to_userid,post_id,date) values('$uid','$userid','$tid','$date1')";
   // die();
  
   $resultshareup = mysqli_query($con,$queryshareup);
   if(mysqli_affected_rows($con)){?>
   	<script>alert('You have shared post')</script>
   	<script>window.location.href="https://<?php echo $baseurl; ?>index.php";</script>
   <?php
   	
   }
  /* $count11 = mysqli_num_rows($resultshareup);
   if($count11 <= 1)
   {
   	echo " No Success";
   }*/
	}
	/*==============================insert into the post table who shared the post=========================*/
/*
if($tid){
	$queryshare1 = "select * from post where post_id = '$tid'";
	$resultshare1 = mysqli_query($con,$queryshare1);
	$rowshare1 = mysqli_fetch_array($resultshare1);
		//echo "121";
	$description = $rowshare1['description'];
	$media = $rowshare1['post_media'];
	$type = $rowshare1['user_type'];
	$userid = $rowshare1['user_id'];
   	$date1 =date('Y-m-d h:i:sa');
   	$userid = $rowshare1['user_id'];
   // $queryshareup = "update post set shared_postusername = '$username1' ,share_postuserid = '$uid', shared_postdate ='$date1'  where user_id = '$userid' && post_id = '$tid'";
     echo $queryshareup = "insert into post(user_id,date,description,user_type,sharedfrom_id)values('$uid','$date1','$description','$type','$userid')";
   // die();
  //die();
   $resultshareup = mysqli_query($con,$queryshareup);
   if(mysqli_affected_rows($con)){?>
   	<script>alert('You have shared post')</script>
   	<script>window.location.href="https://<?php echo $baseurl; ?>index.php";</script>
   <?php
   	
   }
  /* $count11 = mysqli_num_rows($resultshareup);
   if($count11 <= 1)
   {
   	echo " No Success";
   }*/
	//}


	/*==============================end insert into the post table who shared the post=========================*/
?>
 <body>
<?php include('header.php');
?>

    <section id="User-profile-sec">
		<div class="container">
			<div class="Custom-container">
				<div class="row">
				<div class="col-md-3">
						<div class="user-profile-status-right Same-space">
						
							<div class="box-useR">
							
							<?php
							?>
									
								
			<!-- =========================Upload profile and preview========================== -->
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>										
				<!--<script src="dist_files/jquery.imgareaselect.js" type="text/javascript"></script>-->
				<script src='<?php echo "https://".$baseurl."profile-view-test/dist_files/jquery.imgareaselect.js" ?>' type="text/javascript"></script>
				
				<script src='<?php echo "https://".$baseurl."profile-view-test/dist_files/jquery.form.js"?>'></script>
				<link rel="stylesheet" href='<?php echo "https://".$baseurl."profile-view-test/dist_files/imgareaselect.css"?>'>
				<script src='<?php echo "https://".$baseurl."profile-view-test/functions.js"?>'></script>
				<script src='<?php echo "https://".$baseurl."js/croppie.js"?>'></script>
				<!-- =========================Auto complete========================== -->
			      
			      <!--<link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css"
			         rel = "stylesheet">
			      <script src = "https://code.jquery.com/jquery-1.10.2.js"></script>
			      <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>-->
			      <!-- ========================= end Auto complete========================== -->
				
					<?php
					$queryuploadprofile = "select * from users_meta where user_id = '$uid'";
					$resultuploadprofile = mysqli_query($con,$queryuploadprofile);
					
					$rowuploadprofile = mysqli_fetch_array($resultuploadprofile);
				
					if ($rowuploadprofile['user_id'] == $uid)
					{
					$image = $rowuploadprofile['users_image'];
					?>
					
				
				<div class="user-box-container22">				
				  <!--<img class="img-circle" id="profile_picture" height="128" data-src="default.jpg"  data-holder-rendered="true" style="width: 140px; height: 140px; " src=<?php echo "https://".$baseurl."imagesupload/". $image; ?> />-->
				  <img class="img-circle" id="profile_picture" height="128" data-src="default.jpg"  data-holder-rendered="true" style="width: 140px; height: 140px; " src="data:image/png;base64,<?php echo base64_encode($image); ?>" />
				    <div class="middle22 social-icon-camera">
				     <div class="text22 Update-btn">
						<a type="" class="btn btn-primary" id="change-profile-pic">
				     	 <img src="images/photo-camera.png" id="upfile1" style="cursor:pointer"></a>Update</div>
				     	 <input type="file"  id="insert_image" accept="image/*"  style="display: none" />
						 </div>
				    	</div>
					  <span id="uploaded_image"></span>
				<br><br>
			<?php
			}
				else
				{?>

					<div class="user-box-container22">				
				  <img class="img-circle" id="profile_picture" height="128" data-src="default.jpg"  data-holder-rendered="true" style="width: 140px; height: 140px;" src="/apps/profile-view-test/default.jpg"/>
				    <div class="middle22 social-icon-camera">
				     <div class="text22 Update-btn">
						<a type="button" class="btn btn-primary" id="change-profile-pic">
				     	 <img src="images/photo-camera.svg" id="upfile1" style="cursor:pointer"></a>Update</div>
				     	  <input type="file"  id="insert_image" accept="image/*"  style="display: none" />
						 </div>
				    	</div>
					  <span id="uploaded_image"></span>

				   <!--<img class="img-circle" id="profile_picture" height="128" data-src="default.jpg"  data-holder-rendered="true" style="width: 140px; height: 140px;" src="/apps/profile-view-test/default.jpg"/>-->
				   <br><br>	
			<?php	}
			?>
			<!--	<a type="button" class="btn btn-primary" id="change-profile-pic">Change Profile Picture</a>-->
			<!--</div>-->
				<!--<div id="profile_pic_modal" class="modal fade">
				 <div class="modal-dialog">
				  <div class="modal-content">
				   <div class="modal-header profile-pic">
				     <h3>Change Profile Picture</h3>
					 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				    </div>
				     <div class="modal-body">
				     <form id="cropimage" method="post" enctype="multipart/form-data" action='change_pic.php'>
				      <!--<form id="cropimage" method="post" enctype="multipart/form-data" action="/apps/profile-view-test/change_pic.php">-->
				       <!--<strong>Upload Image:</strong> <br><br>
					    <input type="file" name="profile-pic" id="profile-pic" />
					    <input type="hidden" name="hdn-profile-id" id="hdn-profile-id" value="<?php echo $_SESSION['userid']; ?>" />
						<input type="hidden" name="hdn-x1-axis" id="hdn-x1-axis" value="" />
						<input type="hidden" name="hdn-y1-axis" id="hdn-y1-axis" value="" />
						<input type="hidden" name="hdn-x2-axis" value="" id="hdn-x2-axis" />
						<input type="hidden" name="hdn-y2-axis" value="" id="hdn-y2-axis" />
						<input type="hidden" name="hdn-thumb-width" id="hdn-thumb-width" value="" />
						<input type="hidden" name="hdn-thumb-height" id="hdn-thumb-height" value="" />
						<input type="hidden" name="action" value="" id="action" />
						<input type="hidden" name="image_name" value="" id="image_name" />
						
						<div id='preview-profile-pic'></div>
					    <div id="thumbs" style="padding:5px; width:600p"></div>
					</form>
				  </div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" id="save_crop" class="btn btn-primary">Save</button>
				</div>
			</div>
		</div>
	</div>-->

	<!--==========================crop image=============================-->

	<!-- =========================crop image =============================-->
		
<div id="insertimageModal" class="modal" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Crop & Insert Image</h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-8 text-center">
            <div id="image_demo" style="width:350px; margin-top:30px"></div>
          </div>
          <div class="col-md-4" style="padding-top:30px;">
        <br />
        <br />
        <br/>
            <button class="btn btn-success crop_image">Crop & Insert Image</button>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

		
		<!-- =========================End crop image =============================-->

	<!--=========================end of crop image=======================-->
		
	<!--<div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="http://www.phpzag.com/image-upload-and-crop-in-modal-with-php-and-jquery/" title="">Back to Tutorial</a>			
	</div>	-->	
<!--</div>-->
<?php// include('footer.php');?>
<div class="insert-post-ads1" style="margin-top:20px;">

</div>
<!--</div>-->
		<!-- =========================End upload profile =============================-->										
			<?php ?>
								
							</div>
							<!--<div class="newbie_title Save_btn">
								<input type="submit" value="Save" name="btnupload">						
							</div>-->
							<!--<div class="newbie_title text-center mt-4">-->
							<div class=" text-center mt-4">
							<?php
							//echo $uid;
							/*
							$nameqry= "select * from user_signup where user_id = '$uid'";
							$qryres = mysqli_query($con,$nameqry);
							$resrow = mysqli_fetch_assoc($qryres);
							$uname=$resrow['user_username'];
							$querygetdata = "select count(*) as count from user_addfriend where user_id = '$uid' ";
							$resultgetdata = mysqli_query($con,$querygetdata);
							$countrow = mysqli_fetch_assoc($resultgetdata);
							 $count=$countrow['count'];

							if($count <= 100)
							{
								?>
								<!--<a><span><b><?php echo $uname;?><span></b></a><br>-->
								<b><?php echo ucfirst($uname);?></b><br>
							     <a href="JavaScript:Void(0);">Newbie (<?php echo $count;?>)</a>

							    <? 
						     }
							if($count > 100 && $count<= 500)
							{
							   ?>
							   <!--<a><span><b><?php echo $uname;?><span></b></a><br>-->
								<b><?php echo ucfirst($uname);?></b><br>
							     <a href="JavaScript:Void(0);">Host list (<?php echo $count;?>)</a>

							   <?
						    }
							if($count > 500 && $count <= 5000)
							{
								?>
								 <!--<a><span><b><?php echo $uname;?><span></b></a><br>-->
								<b><?php echo ucfirst($uname);?></b><br>
							     <a href="JavaScript:Void(0);">Charmer (<?php echo $count;?>)</a>

							    <? 

							}
							if($count > 5001 && $count <= 100000)
							{
								?>
								<!--<a><span><b><?php echo $uname;?><span></b></a><br>-->
								<b><?php echo ucfirst($uname);?></b><br>
							     <a href="JavaScript:Void(0);">Top list (<?php echo $count;?>)</a>

							    <? 

							}
							if($count > 100000 && $count <= 1000000)
							{
								?>
								 <!--<a><span><b><?php echo $uname;?><span></b></a><br>-->
								<b><?php echo ucfirst($uname);?></b><br>
							     <a href="JavaScript:Void(0);">Unstoppable (<?php echo $count;?>)</a>

							    <? 

							}
							if($count > 1000000 && $count <= 10000000)
							{
								?>
								<!--<a><span><b><?php echo $uname;?><span></b></a><br>-->
								<b><?php echo ucfirst($uname);?></b><br>
							     <a href="JavaScript:Void(0);">Artist (<?php echo $count;?>)</a>

							    <?

							}					
							*/
							?>
							<?php

							$nameqry= "select * from user_signup where user_id = '$uid'";
							$qryres = mysqli_query($con,$nameqry);
							$resrow = mysqli_fetch_assoc($qryres);
							$uname=$resrow['user_username'];
							$querygetdata = "select count(*) as count from user_profile_seen where to_id = '$uid' ";

							$resultgetdata = mysqli_query($con,$querygetdata);
							$countrow = mysqli_fetch_assoc($resultgetdata);
							$count=$countrow['count'];
							//die;
							?>

							<b><?php echo ucfirst($uname);?></b><br>
							<a href="https://<?php echo $baseurl; ?>User/nearmie/profile_seen.php">Status (<?php echo $count;?>)</a>
							</div>
						
						<!--	</form>-->
						</div>
					</div>

					
	<div class="col-md-9">

		<form action="searchpost.php" method="post">
							<div class="row no-gutters no-margin">
								<div class="input-group search_bar col mb-3 mt-5 ">
									<input type="text" class="form-control border-secondary border-right-0 rounded-0 " placeholder="Search... " name="term" id = "test">
								</div>	
									<div class="input-group-append col-auto mb-3 mt-5 search__btn">
									<button type="submit" name="search"><span class="input-group-text" id="basic-addon2"><i class="fa fa-search" aria-hidden="true"></i></span></button>
									</div>
								
							</div>	
							</form>

	
		<div class="status-box-left Same-space">
			<div class="status-box-left-Same-space-1">
				<div class="header-image-wrip mb-5">
					<ul class="nav nav-icon-top">
						<li class="nav-item">
				   	        <a href="User/watchmie/online_user.php"><img src="images/Seen.png" height="80px" width="80px"><br><span class="user-title-name">Watcmie</span></a>
								</li>
								<li class="nav-item">
								 <?php
								  if($rowusertype['user_type'] == 'user')
    								{?>
						        <a href="User/nearmie/search.php"><img src="images/Map.png" height="80px" width="80px"><br><span class="user-title-name">Nearmie</span></a>
									<?php
    									
    								}
									else
									{
									?>
										<a href="JavaScript:Void(0);"><img src="images/Map.png" height="80px" width="80px"><br><span class="user-title-name">Nearmie</span></a>
									<?php
									}
									?>
								</li>
							
								<li class="nav-item">
							   <a href="JavaScript:Void(0);"><img src="images/Newspaper.png" height="80px" width="80px"><br><span class="user-title-name">News</span></a>
								</li>
								<li class="nav-item">
					               <a href="User/flick/stories.php"><img src="images/preview.jpg" height="80px" width="80px"><br><span class="user-title-name">Flick</span></a>
								</li>
								<li class="nav-item">
									<a href="messages/messages.php"><img src="images/Say something.png" height="80px" width="80px"><br><span class="user-title-name">Chat</span></a>
								</li>
							</ul>
							</div>
							<form method="post" action="" enctype="multipart/form-data">
								<div class="form-group comment-srea" >
									
									<!--<textarea type="text" class="form-control" name="description" placeholder="Mood of the day...." required ></textarea>-->
									<textarea type="text" class="form-control" name="description" id = "mood" placeholder="Mood of the day....">
									</textarea>								
									 
								</div>
								
								<div class="row">
									<div class="col-md-6 col-sm-6">
										<div class="post-data-post_btn">
											<ul class="nav justify-content-start">
												<!--<li class="nav-item">
												<a href="User/selfie.php"><img src="images/Camera.png" height="70px" width="70px"></a>
												</li>
												<li class="nav-item">
												<a href="audiorecording.php"><img src="images/Voice recoder.png" height="70px" width="70px"></a>
												</li>
												<li class="nav-item">
												<a href="User/videorecording.php"><img src="images/Video.png" height="70px" width="70px"></a>
												</li>-->
											</ul>
										</div>
										<div id="thumb-output"></div>
									</div>
									
						<div class="col-md-6 col-sm-6  align-self-center">
										<div class="post-data-post_btn">
											<ul class="nav justify-content-end">									
												<li>
													<div class="uploadmedia">
														<!--<label for="file-upload">
															<i class="fa fa-upload" aria-hidden="true">					
															</i>  Upload Media</label>-->
															<label for="file-upload"><img src="images/fb_upload.png" alt="upload "></label>
														</div>
													</li>
													<!--<input type="button" for="file-upload" id="file-upload" name="file-upload" value="upload File"/>-->
													<input type="file" name="mediaupload" id="file-upload" style="z-index: -1;position: absolute;opacity: 0;"/>
												
												<!--<li><button type="submit" class="btn btn-info" name="publish">Publish</button></li>-->
												<!--<li><button class="publish" type="submit"  name="publish"><img src="images/INSTAGRAM.png" height="35px" width="35px"></button></li>-->
												<li><button class="publish" type="submit"  name="publish" id = "submit"><img src="images/INSTAGRAM.png" height="35px" width="35px"></button></li>

												<?php echo $msg;?>
												
											</ul>
										</div>
									</div>
									
								</div>
							</form>	
							
							</div>
							<!--<form action="searchpost.php" method="post">
							<div class="row no-gutters no-margin">
								<div class="input-group search_bar col mb-3 mt-5 ">
									<input type="text" class="form-control border-secondary border-right-0 rounded-0 " placeholder="Search... " name="term" id = "test">
								</div>	
									<div class="input-group-append col-auto mb-3 mt-5 search__btn">
									<button type="submit" name="search"><span class="input-group-text" id="basic-addon2"><i class="fa fa-search" aria-hidden="true"></i></span></button>
									</div>
								
							</div>	
							</form>-->
							
							<div class="row no-gutters no-margin">
								<div class="input-group search_bar col mb-3 mt-5 ">
									
								</div>	
									<div class="input-group-append col-auto mb-3 mt-5 search__btn">
									
									</div>
								
							</div>	
							
						
						<!--=====================display the post of add friend and user ========================-->
						<?php 
						//$qryfruserpost= "select * from post where user_id = '$uid' order by date desc";
						$qryfruserpost= "select * from post where user_id = '$uid' order by post_id desc";
						$resqry= mysqli_query($con,$qryfruserpost);
						$upid = array();
						while($upost= mysqli_fetch_assoc($resqry))
						{
						    $upid[]= $upost['post_id']; 
						}
						//print_r($upid);
						//die("hii");
						 $qryfrpostfr= "select * from user_addfriend where user_id = '$uid' ";
						
						$resqryfr = mysqli_query($con,$qryfrpostfr);
						$frpostid= array();
						while($frndpost = mysqli_fetch_assoc($resqryfr))
						{
							$frid= $frndpost['addfriend_id'];
							
							 //$frndqry = "select * from post where user_id = '$frid'";
							 //$frndqry="select po.* ,us.* , user.* from post po join user_addfriend us on po.user_id = us.user_id join
							 //user_signup user on po.user_id = user.user_id where us.user_id = '$frid'
							 //&& (user.post_visibility='public' || user.post_visibility='friends') order by po.date DESC";
							 //$frndqry="select po.* ,us.* , user.* from post po join user_addfriend us on po.user_id = us.user_id join
							 //user_signup user on po.user_id = user.user_id where us.addfriend_id = '$frid'
							 //&& (user.post_visibility='public' || user.post_visibility='friends') ";

							$frndqry ="select po.* ,us.* , user.* from post po join user_addfriend us on po.user_id = us.addfriend_id join user_signup user on po.user_id = user.user_id where us.addfriend_id = '$frid' && us.user_id = '$uid' && (user.post_visibility='public' || user.post_visibility='friends') order by post_id desc";
							$frndqryres = mysqli_query($con,$frndqry);
							while($respost = mysqli_fetch_assoc($frndqryres))
							{
								$frpostid[]= $respost['post_id'];
							}
							
							//die;
						}
						//print_r($upid);
						//echo "<br>";
						//print_r($frpostid);
						//echo "<br>";
						//die("hii");
						//echo "uiuiiuiuiu";
						//$mer = array_merge($upid,$frpostid);
						
						//$qrysshrpst= "select * from post_share where from_userid = '$uid'";
						//$runshrpst = mysqli_query($con,$qrysshrpst);
						//$resshrpst = array();
						//while($shrpst = mysqli_fetch_assoc($runshrpst))
						//{
							//$resshrpst[] = $shrpst['post_id'];
						//}
						//print_r($resshrpst);
						//die("kllk");
						//print_r($mer);
						//$sortdata = krsort($mer);
						$mer = array_merge($upid,$frpostid);
						//print_r($mer);	
						//die;		
						//$numbers = array(4, 6, 2, 22, 11);
						rsort($mer);

						 $arrlength = count($mer);
						for($x = 0; $x < $arrlength; $x++)
						 {
						    $mergeid = $mer[$x];
						     
						    //echo "<br>";
						//}
						//print_r((array_merge($a1,$a2));
						//print_r(ksort($mer,SORT_DESC));
						//die;
						//echo "<br>";
						//print_r($mer);
						//die("hhhh");
						//$merthre= array_merge($mer,$resshrpst);
						//echo "<br>";
						//print_r($merthre);
						//$sortedarray = krsort($merthre);
						//print_r($sortedarray);
						
						//echo"<br>";
						//foreach($mer as $mergeid)
						//{
							$selectqrypst= "select * from post_share where post_id = '$mergeid' && from_userid = '$uid'";
							$runqrypst = mysqli_query($con,$selectqrypst);
							$count= mysqli_num_rows($runqrypst);
							if($count >=1)
							{
								
								$row= mysqli_fetch_assoc($runqrypst);								
								$toid= $row['to_userid'];
								
								$qrygetdata = "select * from user_signup where user_id = '$toid' "; 
								$qrygetdatarun= mysqli_query($con,$qrygetdata);
								$resultqrydata= mysqli_fetch_assoc($qrygetdatarun);
								$resultqrydata['user_username'];				
								
								$querydata= "select * from post where post_id = '$mergeid' && user_id = '$toid'";								
								$runquerydata= mysqli_query($con,$querydata);
								$getdataquery=mysqli_fetch_assoc($runquerydata);
								?>
								<div class="user_post__box mb-4">
								    <div class="user_post__area">
								    <h3><?php echo $getdataquery['date']; ?></h3>
										 <!--<span class="user">You have shared <?php echo $resultqrydata['user_username']; ?>'s post</span><br/>-->
										 <h3><a href ="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>"><?php echo substr($getdataquery['description'],0,30);?>.....</a></h3>

										
										<?php
										if (!empty($getdataquery['post_media']))
										{
										?>
									<div class="user__media__upload">
 										<!--<span>Media :</span><a href="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$getdataquery['post_media'];?> </a>-->

 										<?php
 										$vid =$getdataquery['post_media'];
						                $ext = pathinfo($vid, PATHINFO_EXTENSION);
						                //echo $ext;
						                if($ext == 'wav' || $ext == 'ogg' || $ext == 'mpeg')
						                {
					                  ?>
					                  		<a href="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>">
					                        <audio controls>
					                        <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="audio/<?php echo $ext; ?>">
					                        </audio>
					                        </a>
					                 <?php
					                    }
					                    $urlimg = "https://".$baseurl."imagesupload/thumbs/";
					                    if ($ext == 'png' || $ext =='jpeg' || $ext == 'jpg')
					                    {
					                    ?>
					                      <!--  //echo '<img src= "'.$urlimg.$getdataquery['thumb_img'].'"  width="300px"/>';
					                         //'<img src="'.$vid.'" alt="HTML5 Icon"/>'-->
					                         <a href="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>">
					                         <img src = "<?php echo $urlimg.$getdataquery['thumb_img'];?>"  width = "300">
					                         </a>
					                    <?php    
					                    }
					                    
					                    if ($ext == 'webm' || $ext == 'mp4' || $ext == 'ogg')
					                    {
					                    ?>
					                    <a href="User/post_details.php?id=<?php echo $getdataquery["post_id"];?>">
					                    <video width="400" controls>
					                     <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="video/<?php echo $ext; ?>">
					                     </video>
					                     </a>
					                    <?php
					                    }
					                    ?>

									</div>
										<?php
										}
										?>
										<br><span class="user">You have shared <?php echo $resultqrydata['user_username']; ?>'s post</span>
									</div>
									<?php
									/*=======================================Select post seen from post table==============================*/
									$ppid = $getdataquery['post_id'];
									//$queryseen = "select post_seen from post where post_id = $ppid";
									$queryseen = "select count(distinct user_id) as seen from post_seen where post_id = $ppid";
									$resultseen = mysqli_query($con,$queryseen);
									if($resultseen)
									$rowseen = mysqli_fetch_array($resultseen);
								
									/*===================select share count from post share table===================*/
									$queryshare = "select count(post_id) as value from post_share where post_id = $ppid";
									$resultshare = mysqli_query($con,$queryshare);
									$rowshare = mysqli_fetch_array($resultshare);
									$postid= $getdataquery["post_id"];
									
									?>
									<ul class="nav">
								    	<li class="nav-item">
									   		<a href="JavaScript:Void(0);"><img src="images/seen-icon.png"> &nbsp;Seen(<?php echo $rowseen['seen'];?>)</a>
								       </li>
								    	<li class="nav-item">
									 		<a id= 'btn_<?php echo $mergeid; ?>'><img src="images/say-something-icon.png"> &nbsp;Say Something</a>
								     	</li>
								    	<li class="nav-item">									
								    		 <a href="index.php?tid=<?php echo $getdataquery["post_id"];?>" value="like"><img src="images/toss-icon1.png"> &nbsp;Toss</a>										
								    	 </li>							
								
							        </ul>
								</div>
								<div id="editForm1_<?php echo $mergeid; ?>" >
								<div id="all_comments_<?php echo $mergeid; ?>">
								  <?php
								    							    
								  
								    $comm = mysqli_query($con,"select * from post_comments where post_id = $mergeid order by post_time desc");
								    while($row=mysqli_fetch_array($comm))
								    {
									  $name=$row['name'];
									  $comment=$row['comment'];
								      $time=$row['post_time'];
								    ?>
									
									<div class="comment_div"> 
									  <p class="name"> <?php echo $name;?> <strong class="time"> <?php echo $time;?></strong></p>
								      <p class="comment"><?php echo $comment;?></p>	

									</div>
								  
								    <?php
								    }
								    ?>
								  </div>
									<form id="editForm_<?php echo $mergeid; ?>"  action="" method="post" name="editForm">


									<textarea class="form-control" id="comment_<?php echo $mergeid; ?>"  placeholder="Write Your Comment Here....." required></textarea><br/>
									<input type = "hidden" id="name_<?php echo $mergeid; ?>" value='<?php echo $_SESSION['user_username'];?>'>
									<input type = "hidden" id="postid_<?php echo $mergeid; ?>" value='<?php echo $mergeid;?>'>
									<input class="btn btn-info Post__Comment" type="submit" value="Post Comment" 
									id = "submit_form">
									<input class="btn btn-info Close"  value="Close" id = "close_<?php echo $mergeid; ?>">
									
									</form>

							</div>
							<script type="text/javascript">

							    $(document).ready(function(){
							        $("#editForm1_<?php echo $mergeid; ?>").hide();
							        $("#btn_<?php echo $mergeid; ?>").click(function(e) {
							            $("#editForm1_<?php echo $mergeid; ?>").show();
							            

							        });
							        $("#close_<?php echo $mergeid; ?>").click(function() {
							 		$("#editForm1_<?php echo $mergeid; ?>").hide();
							});
							    });
							</script>
								<script>							
							$( "#editForm_<?php echo $mergeid; ?>" ).submit(function( event) {
							
							  event.preventDefault();
							 
							  // Get some values from elements on the page:
							  var comment = $('#comment_<?php echo $mergeid; ?>').val();
							var name = $('#name_<?php echo $mergeid; ?>').val();
							var postid = $('#postid_<?php echo $mergeid; ?>').val();

							var form_data = 'comment='+comment+'&name='+name+'&postid='+postid;
								  //alert(form_data);
								  //die;
							$.ajax({
				
							url: "post_comment.php",
							type: "POST",       
							data: form_data, 
							 
							success: function (data) {
								//alert(data);
								$( "#all_comments_<?php echo $mergeid; ?>" ).append( data );
								$("#comment_<?php echo $mergeid; ?>").val('');
							}
							 
							 });
							  
							});
							</script>
								<?php
								
								//die("count>");
							}
							else
							{
			
								$qrypost= "select * from post where post_id = '$mergeid' ";
								$runqrypost= mysqli_query($con,$qrypost);
								$resofrow = mysqli_fetch_assoc($runqrypost);
								//print_r($resofrow);
								//echo"<br>"; 
								?>
								<div class="user_post__box mb-4">
									<div class="user_post__area">
										 <h3><?php echo $resofrow['date']; ?></h3>
											<h3><a href ="User/post_details.php?id=<?php echo $resofrow["post_id"];?>"><?php echo substr($resofrow['description'],0,30);?>.....</a></h3>
											
											<?php
											if (!empty($resofrow['post_media']))
											{
											?>
										<div class="user__media__upload">
	 										<!--<span>Media :</span><a href="User/post_details.php?id=<?php echo $resofrow["post_id"];?>"><?php echo "https://".$baseurl."imagesupload/".$resofrow['post_media'];?> </a>-->

	 										<?php
 										$vid =$resofrow['post_media'];
 										
						                $ext = pathinfo($vid, PATHINFO_EXTENSION);
						                //echo $ext;
						                if($ext == 'wav' || $ext == 'ogg' || $ext == 'mpeg')
						                {

					                  ?>

					                  		<a href="User/post_details.php?id=<?php echo $resofrow["post_id"];?>"> 
					                        <audio controls>
					                        <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="audio/<?php echo $ext; ?>">
					                        </audio>
					                        </a>

					                 <?php
					                    }
					                    $urlimg = "https://".$baseurl."imagesupload/thumbs/";
					                     if ($ext == 'png' || $ext =='jpeg' || $ext == 'jpg')
					                     	{
					                     		?>
					                     <a href="User/post_details.php?id=<?php echo $resofrow["post_id"];?>">
					                    <img src = "<?php echo $urlimg.$resofrow['thumb_img'];?>"  width = "300">
					                    </a>

					                    <?php
					                        //echo '<img src= "'.$url.$vid.'" alt="HTML5 Icon" height="300px" width="300px"/>';
					                    }
					                    
					                    if ($ext == 'webm' || $ext == 'mp4' || $ext == 'ogg')
					                    {
					                    ?>
					                    <a href="User/post_details.php?id=<?php echo $resofrow["post_id"];?>">
					                    <video width="400" controls>
					                     <source src="<?php echo "https://".$baseurl."imagesupload/$vid"?>" type="video/<?php echo $ext; ?>">
					                     </video>
					                     </a>
					                    <?php
					                    }
					                    ?>

										</div>
											<?php
											}
											?>
										</div>
										<?php
										
										/*=======================================Select post seen from post table==============================*/
										$ppid = $resofrow['post_id'];
										//$queryseen = "select post_seen from post where post_id = $ppid";
										$queryseen = "select count(distinct user_id) as seen from post_seen where post_id = $ppid";
										$resultseen = mysqli_query($con,$queryseen);
										if($resultseen)
										$rowseen = mysqli_fetch_array($resultseen);
									
										
										
										/*===================select like count from post like table===================*/
										
										/*$querylikes = "select count(distinct user_id) as value from post_likes where post_id = $ppid";
										$resultlikes = mysqli_query($con,$querylikes);
										$rowlikes = mysqli_fetch_array($resultlikes);
										$postid= $rowdis["post_id"];*/
										
											/*===================select share count from post share table===================*/
										$queryshare = "select count(post_id) as value from post_share where post_id = $ppid";
										$resultshare = mysqli_query($con,$queryshare);
										$rowshare = mysqli_fetch_array($resultshare);
										$postid= $resofrow["post_id"];
										
										?>
	
									<ul class="nav">
								    	<li class="nav-item">
											<a href="JavaScript:Void(0);"><img src="images/seen-icon.png"> &nbsp;Seen(<?php echo $rowseen['seen'];?>)</a>
										</li>
									<li class="nav-item">
										<a  id= 'btn_<?php echo $mergeid; ?>'><img src="images/say-something-icon.png"> &nbsp;Say Something</a>
									</li>
									<li class="nav-item">
									
									<a href="index.php?tid=<?php echo $resofrow["post_id"];?>" value="like"><img src="images/toss-icon1.png"> &nbsp;Toss</a>								
									</form> 									
								</li>								
							</ul>
						<!--==================================say something=================================-->	
								</div>
								<div id="editForm1_<?php echo $mergeid; ?>" >
								<div id="all_comments_<?php echo $mergeid; ?>">
								  <?php
								    							    
								  
								    $comm = mysqli_query($con,"select * from post_comments where post_id = $mergeid order by post_time desc");
								    while($row=mysqli_fetch_array($comm))
								    {
									  $name=$row['name'];
									  $comment=$row['comment'];
								      $time=$row['post_time'];
								    ?>
									
									<div class="comment_div"> 
									  <p class="name"> <?php echo $name;?> <strong class="time"> <?php echo $time;?></strong></p>
								      <p class="comment"><?php echo $comment;?></p>	

									</div>
								  
								    <?php
								    }
								    ?>
								  </div>
									<form id="editForm_<?php echo $mergeid; ?>"  action="" method="post" name="editForm">


									<textarea class="form-control" id="comment_<?php echo $mergeid; ?>"  placeholder="Write Your Comment Here....." required></textarea><br/>
									<input type = "hidden" id="name_<?php echo $mergeid; ?>" value='<?php echo $_SESSION['user_username'];?>'>
									<input type = "hidden" id="postid_<?php echo $mergeid; ?>" value='<?php echo $mergeid;?>'>
									<input class="btn btn-info Post__Comment" type="submit" value="Post Comment" 
									id = "submit_form">
									<input class="btn btn-info Close"  value="Close" id = "close_<?php echo $mergeid; ?>">

									</form>



									</div>
									<script type="text/javascript">

									    $(document).ready(function(){
									        $("#editForm1_<?php echo $mergeid; ?>").hide();
									        $("#btn_<?php echo $mergeid; ?>").click(function(e) {
									            $("#editForm1_<?php echo $mergeid; ?>").show();
									            

									        });
									        $("#close_<?php echo $mergeid; ?>").click(function() {
									 		$("#editForm1_<?php echo $mergeid; ?>").hide();
									});
									    });
									</script>
									<script>							
									$( "#editForm_<?php echo $mergeid; ?>" ).submit(function( event) {
									
									  event.preventDefault();
									 
									  // Get some values from elements on the page:
									  var comment = $('#comment_<?php echo $mergeid; ?>').val();
									var name = $('#name_<?php echo $mergeid; ?>').val();
									var postid = $('#postid_<?php echo $mergeid; ?>').val();
									var form_data = 'comment='+comment+'&name='+name+'&postid='+postid;
										  //alert(form_data);
										  //die;
									$.ajax({
						
									url: "post_comment.php",
									type: "POST",       
									data: form_data, 
									 
									success: function (data) {
										//alert(data);
										$( "#all_comments_<?php echo $mergeid; ?>" ).append( data );
										 $("#comment_<?php echo $mergeid; ?>").val('');
									}
									 
									 
									 });
									  
									});
									</script>
									<!--===========================end say something=================================-->
									<?php
								}
							}
							//print_r($merge);
							//die("hii");
							?>
							
							<!--=====================End displayed post	====================-->
							<!--	<div class="user_post__box">
									<div class="user_post__area">
										<h3>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </h3>
									</div>
									
									<ul class="nav">
								<li class="nav-item">
									<a href="JavaScript:Void(0);">Seen 1k</a>
								</li>
								<li class="nav-item">
									<a href="JavaScript:Void(0);">Say Something</a>
								</li>
								<li class="nav-item">
									<a href="JavaScript:Void(0);">Toss</a>
								</li>
								
							</ul>
									
								</div>-->
						</div>
					</div>
				</div>
			</div>
		</div>
		</div>
	</section>

	<!--=============post image with preview======-->
	<script>
		$(document).ready(function(){
	$('#file-upload').on('change', function(){ //on file input change
		if (window.File && window.FileReader && window.FileList && window.Blob) //check File API supported browser
    	{
			$('#thumb-output').html(''); //clear html of output element
			var data = $(this)[0].files; //this file data
			
			$.each(data, function(index, file){ //loop though each file
				if(/(\.|\/)(gif|jpe?g|png)$/i.test(file.type)){ //check supported file type
					var fRead = new FileReader(); //new filereader
					fRead.onload = (function(file){ //trigger function on successful read
					return function(e) {
						var img = $('<img/>').addClass('thumb').attr('src', e.target.result); //create image element 
						$('#thumb-output').append(img); //append image to output element
					};
				  	})(file);
					fRead.readAsDataURL(file); //URL representing the file's data.
				}

			});
			
		}else{
			alert("Your browser doesn't support File API!"); //if File API is absent
		}
	});
});
	</script>

	<!--============end of post image with preview===-->


<script type="text/javascript">

	$(document).ready(function() {
    $("#submit").attr('disabled', true);

     $('input[type="file"],#mood').change(function(e){
        var fileName = $('#file-upload').get(0).files.length;    
    	//alert('The file "' + fileName +  '" has been selected.');       
        var text_value = $('#mood').val();
       // alert(text_value);
        
        if(fileName == '' && text_value == '') {
             $("#submit").attr('disabled', true);
        } 
        else 
        {
            $("#submit").removeAttr('disabled');
        }
    });
    });

</script>

<!--======================================crop image ============================-->
	
		<script type="text/javascript">
	
		$(document).ready(function() {
			
       $('#upfile1').click(function(){

        $("#insert_image").trigger('click');
        
       	});
    });
    
	</script>
	<script>  
$(document).ready(function(){

 $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:200,
      height:200,
      type:'square' //circle
    },
    boundary:{
      width:300,
      height:300
    }    
  });

  $('#insert_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#insertimageModal').modal('show');
  });

  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:'insert.php',
        type:'POST',
        data:{"image":response},
        success:function(data){
          $('#insertimageModal').modal('hide');
          load_images();
          alert(data);
          
        }
      })
    });
  });

  load_images();

  function load_images()
  {
    $.ajax({
      url:"fetch_images.php",
      success:function(data)
      {
      	 //alert(data);
        $('#profile_picture').attr("src", data);
         //$('#store_image').html(data);
      }
    })
  }

});  
</script>

	
<!--=================================end crop image=================================-->

	<!--<link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel = "stylesheet">
     <!--<script src = "https://code.jquery.com/jquery-1.10.2.js"></script>-->
      <!--<script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>

<script>
  $(function() {
  	alert("hii");
            $( "#test" ).autocomplete({
            	//alert("hii");
               source: "autocomplete.php",
               minLength: 2
            });
         });
      </script> 
  </script>-->

 <!--   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script>

  </body>
</html>-->
