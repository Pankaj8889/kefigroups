<?php
include('vendor/autoload.php');

use \Gumlet\ImageResize;

//$image = new ImageResize('image.jpg');
//$image->scale(50);
//$image->save('image2.jpg');
?>
<?php

//$image = new ImageResize('image.jpg');
//$image->resizeToHeight(300);
//$image->save('image2.jpg');

?>
<?php
if (isset($_POST["submit"])) {
    
    
    
  
    $path = $_SERVER['DOCUMENT_ROOT']."/upload/";
   //die;
     $tmpFile = $_FILES["file"]["tmp_name"];
    
     $fileName = $_FILES["file"]["name"];
    
    
     $file = $path."thumb_".$fileName;
    
//$image = new ImageResize($tmpFile);
//$image->resizeToWidth(300);
//$image->save('thumb_'.$fileName);
//$image->save($fi);
$image = new ImageResize($tmpFile);
$image->resizeToBestFit(300, 300);
$image->save($file);
}

?>
<form action="" method="post" enctype="multipart/form-data">
 <label for="file">Image:</label>
 <input type="file" name="file" id="file"><br>
 <input type="submit" name="submit" value="Upload and Crop">
</form>

