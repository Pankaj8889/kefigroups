<?php
include('connect.php');
include('config.php');
session_start();
$uid = $_SESSION['userid'];
$query = "update user_signup set status='deactivate' where user_id = $uid ";
$result = mysqli_query($con,$query);
if($result)
{
    session_destroy();
?>
<script>
window.location.href="User/user-sign-in.php";
</script>
<?php
//header('Location:User/user-sign-in.php');
}

?>